[TOC]



# Command-line interface 命令行界面

When you install Streamlit, a command-line (CLI) tool gets installed as well. The purpose of this tool is to run Streamlit apps, change Streamlit configuration options, and help you diagnose and fix issues.
安装 Streamlit 时，还会安装命令行 （CLI） 工具。此工具的目的是运行 Streamlit 应用程序、更改 Streamlit 配置选项，并帮助您诊断和修复问题。

To see all of the supported commands:
要查看所有支持的命令，请执行以下操作：

```bash
streamlit --help
```

Copy



### Run Streamlit apps 运行流光应用

```bash
streamlit run your_script.py [-- script args]
```

Copy

Runs your app. At any time you can stop the server with **Ctrl+c**.
运行你的应用。您可以随时使用 Ctrl+c 停止服务器。

*push_pin*

#### Note

When passing your script some custom arguments, **they must be passed after two dashes**. Otherwise the arguments get interpreted as arguments to Streamlit itself.
在向脚本传递一些自定义参数时，必须在两个短划线后传递它们。否则，参数将被解释为 Streamlit 本身的参数。

To see the Streamlit 'Hello, World!' example app, run `streamlit hello`.
若要查看 Streamlit 'Hello， World！' 示例应用，请运行 `streamlit hello` 。



### View Streamlit version 查看流光版本

To see what version of Streamlit is installed, just type:
要查看安装了哪个版本的 Streamlit，只需键入：

```bash
streamlit version
```

Copy



### View documentation 查看文档

```bash
streamlit docs
```

Copy

Opens the Streamlit documentation (i.e. this website) in a web browser.
在 Web 浏览器中打开 Streamlit 文档（即此网站）。



### Clear cache

```bash
streamlit cache clear
```

Copy

Clears persisted files from the on-disk [Streamlit cache](https://docs.streamlit.io/library/api-reference/performance), if present.
从磁盘上的 Streamlit 缓存中清除持久文件（如果存在）。



### View all configuration options 查看所有配置选项

As described in [Configuration](https://docs.streamlit.io/library/advanced-features/configuration), Streamlit has several configuration options. To view them all, including their current values, just type:
如 配置 中所述，Streamlit 有几个配置选项。要查看所有内容，包括其当前值，只需键入：

```bash
streamlit config show
```







# Configuration

Streamlit provides four different ways to set configuration options. This list is in reverse order of precedence, i.e. command line flags take precedence over environment variables when the same configuration option is provided multiple times.
Streamlit提供了四种不同的方法来设置配置选项。此列表的优先级顺序相反，即当多次提供相同的配置选项时，命令行标志优先于环境变量。

*push_pin*

#### Note

If changes to `.streamlit/config.toml` are made *while* the app is running, the server needs to be restarted for changes to be reflected in the app.
如果在应用运行时对 `.streamlit/config.toml` 进行了更改，则需要重新启动服务器才能将更改反映在应用中。

1. In a **global config file** at `~/.streamlit/config.toml` for macOS/Linux or `%userprofile%/.streamlit/config.toml` for Windows:
   在 `~/.streamlit/config.toml` for macOS/Linux 或 `%userprofile%/.streamlit/config.toml` for Windows 的全局配置文件中：

   ```toml
   [server]
   port = 80
   ```

   Copy

2. In a **per-project config file** at `$CWD/.streamlit/config.toml`, where `$CWD` is the folder you're running Streamlit from.
   在 `$CWD/.streamlit/config.toml` 的每个项目配置文件中，其中 `$CWD` 是运行 Streamlit 的文件夹。

3. Through `STREAMLIT_*` **environment variables**, such as:
   通过 `STREAMLIT_*` 环境变量，例如：

   ```bash
   export STREAMLIT_SERVER_PORT=80
   export STREAMLIT_SERVER_COOKIE_SECRET=dontforgottochangeme
   ```

   Copy

4. As **flags on the command line** when running `streamlit run`:
   作为运行 `streamlit run` 时命令行上的标志：

   ```bash
   streamlit run your_script.py --server.port 80
   ```

   Copy

*star*

#### Tip

To set configuration options on Streamlit Community Cloud, read [Optionally, add a configuration file](https://docs.streamlit.io/streamlit-community-cloud/get-started/deploy-an-app#optionally-add-a-configuration-file) in the Streamlit Community Cloud docs.
要在 Streamlit Community Cloud 上设置配置选项，请阅读 （可选）在 Streamlit Community Cloud 文档中添加配置文件。



## Telemetry

As mentioned during the installation process, Streamlit collects usage statistics. You can find out more by reading our [Privacy Notice](https://streamlit.io/privacy-policy), but the high-level summary is that although we collect telemetry data we cannot see and do not store information contained in Streamlit apps.
如安装过程中所述，Streamlit 收集使用情况统计信息。您可以通过阅读我们的 隐私声明 ，但高级摘要是，尽管我们收集遥测数据，但我们无法看到也不会存储 Streamlit 应用程序中包含的信息。

If you'd like to opt out of usage statistics, add the following to your config file:
如果要选择退出使用情况统计信息，请将以下内容添加到配置文件中：

```toml
[browser]
gatherUsageStats = false
```

Copy



## Theming

You can change the base colors of your app using the `[theme]` section of the configuration system. To learn more, see [Theming.](https://docs.streamlit.io/library/advanced-features/theming)
您可以使用配置系统的 `[theme]` 部分更改应用的基色。若要了解详细信息，请参阅主题。



## View all configuration options 查看所有配置选项

As described in [Command-line options](https://docs.streamlit.io/library/advanced-features/cli), you can view all available configuration option using:
如 命令行选项 中所述，您可以使用以下命令查看所有可用的配置选项：

```bash
streamlit config show
```

Copy

The command above will print something like this:
上面的命令将打印如下内容：

```toml
# Streamlit version: 1.22.0

[global]

# By default, Streamlit checks if the Python watchdog module is available and, if not, prints a warning asking for you to install it. The watchdog module is not required, but highly recommended. It improves Streamlit's ability to detect changes to files in your filesystem.
# If you'd like to turn off this warning, set this to True.
# Default: false
disableWatchdogWarning = false

# If True, will show a warning when you run a Streamlit-enabled script via "python my_script.py".
# Default: true
showWarningOnDirectExecution = true

# DataFrame serialization.
# Acceptable values: - 'legacy': Serialize DataFrames using Streamlit's custom format. Slow but battle-tested. - 'arrow': Serialize DataFrames using Apache Arrow. Much faster and versatile.
# Default: "arrow"
dataFrameSerialization = "arrow"


[logger]

# Level of logging: 'error', 'warning', 'info', or 'debug'.
# Default: 'info'
level = "info"

# String format for logging messages. If logger.datetimeFormat is set, logger messages will default to `%(asctime)s.%(msecs)03d %(message)s`. See [Python's documentation](https://docs.python.org/2.6/library/logging.html#formatter-objects) for available attributes.
# Default: "%(asctime)s %(message)s"
messageFormat = "%(asctime)s %(message)s"


[client]

# Whether to enable st.cache.
# Default: true
caching = true

# If false, makes your Streamlit script not draw to a Streamlit app.
# Default: true
displayEnabled = true

# Controls whether uncaught app exceptions are displayed in the browser. By default, this is set to True and Streamlit displays app exceptions and associated tracebacks in the browser.
# If set to False, an exception will result in a generic message being shown in the browser, and exceptions and tracebacks will be printed to the console only.
# Default: true
showErrorDetails = true

# Change the visibility of items in the toolbar, options menu, and settings dialog (top right of the app).
# Allowed values:
# "auto" : Show the developer options if the app is accessed through localhost and hide them otherwise.
# "developer" : Show the developer options.
# "viewer" : Hide the developer options.
# "minimal" : Show only options set externally (e.g. through Streamlit Community Cloud) or through st.set_page_config. If there are no options left, hide the menu.
# Default: "auto"
toolbarMode = "auto"


[runner]

# Allows you to type a variable or string by itself in a single line of Python code to write it to the app.
# Default: true
magicEnabled = true

# Install a Python tracer to allow you to stop or pause your script at any point and introspect it. As a side-effect, this slows down your script's execution.
# Default: false
installTracer = false

# Sets the MPLBACKEND environment variable to Agg inside Streamlit to prevent Python crashing.
# Default: true
fixMatplotlib = true

# Run the Python Garbage Collector after each script execution. This can help avoid excess memory use in Streamlit apps, but could introduce delay in rerunning the app script for high-memory-use applications.
# Default: true
postScriptGC = true

# Handle script rerun requests immediately, rather than waiting for script execution to reach a yield point. This makes Streamlit much more responsive to user interaction, but it can lead to race conditions in apps that mutate session_state data outside of explicit session_state assignment statements.
# Default: true
fastReruns = true

# Raise an exception after adding unserializable data to Session State. Some execution environments may require serializing all data in Session State, so it may be useful to detect incompatibility during development, or when the execution environment will stop supporting it in the future.
# Default: false
enforceSerializableSessionState = false

[server]

# List of folders that should not be watched for changes. This impacts both "Run on Save" and @st.cache.
# Relative paths will be taken as relative to the current working directory.
# Example: ['/home/user1/env', 'relative/path/to/folder']
# Default: []
folderWatchBlacklist = []

# Change the type of file watcher used by Streamlit, or turn it off completely.
# Allowed values: * "auto" : Streamlit will attempt to use the watchdog module, and falls back to polling if watchdog is not available. * "watchdog" : Force Streamlit to use the watchdog module. * "poll" : Force Streamlit to always use polling. * "none" : Streamlit will not watch files.
# Default: "auto"
fileWatcherType = "auto"

# Symmetric key used to produce signed cookies. If deploying on multiple replicas, this should be set to the same value across all replicas to ensure they all share the same secret.
# Default: randomly generated secret key.
cookieSecret =

# If false, will attempt to open a browser window on start.
# Default: false unless (1) we are on a Linux box where DISPLAY is unset, or (2) we are running in the Streamlit Atom plugin.
headless = false

# Automatically rerun script when the file is modified on disk.
# Default: false
runOnSave = false

# The address where the server will listen for client and browser connections. Use this if you want to bind the server to a specific address. If set, the server will only be accessible from this address, and not from any aliases (like localhost).
# Default: (unset)
# address =

# The port where the server will listen for browser connections.
# Default: 8501
port = 8501

# The base path for the URL where Streamlit should be served from.
# Default: ""
baseUrlPath = ""

# Enables support for Cross-Origin Request Sharing (CORS) protection, for added security.
# Due to conflicts between CORS and XSRF, if `server.enableXsrfProtection` is on and `server.enableCORS` is off at the same time, we will prioritize `server.enableXsrfProtection`.
# Default: true
enableCORS = true

# Enables support for Cross-Site Request Forgery (XSRF) protection, for added security.
# Due to conflicts between CORS and XSRF, if `server.enableXsrfProtection` is on and `server.enableCORS` is off at the same time, we will prioritize `server.enableXsrfProtection`.
# Default: true
enableXsrfProtection = true

# Max size, in megabytes, for files uploaded with the file_uploader.
# Default: 200
maxUploadSize = 200

# Max size, in megabytes, of messages that can be sent via the WebSocket connection.
# Default: 200
maxMessageSize = 200

# Enables support for websocket compression.
# Default: false
enableWebsocketCompression = false

# Enable serving files from a `static` directory in the running app's directory.
# Default: false
enableStaticServing = false

# Server certificate file for connecting via HTTPS. Must be set at the same time as "server.sslKeyFile".
# ['DO NOT USE THIS OPTION IN A PRODUCTION ENVIRONMENT. It has not gone through security audits or performance tests. For the production environment, we recommend performing SSL termination by the load balancer or the reverse proxy.']
# sslCertFile =

# Cryptographic key file for connecting via HTTPS. Must be set at the same time as "server.sslCertFile".
# ['DO NOT USE THIS OPTION IN A PRODUCTION ENVIRONMENT. It has not gone through security audits or performance tests. For the production environment, we recommend performing SSL termination by the load balancer or the reverse proxy.']
# sslKeyFile =

[browser]

# Internet address where users should point their browsers in order to connect to the app. Can be IP address or DNS name and path.
# This is used to: - Set the correct URL for CORS and XSRF protection purposes. - Show the URL on the terminal - Open the browser
# Default: 'localhost'
serverAddress = "localhost"

# Whether to send usage statistics to Streamlit.
# Default: true
gatherUsageStats = true

# Port where users should point their browsers in order to connect to the app.
# This is used to: - Set the correct URL for CORS and XSRF protection purposes. - Show the URL on the terminal - Open the browser
# Default: whatever value is set in server.port.
serverPort = 8501


[mapbox]

# Configure Streamlit to use a custom Mapbox token for elements like st.pydeck_chart and st.map. To get a token for yourself, create an account at https://mapbox.com. It's free (for moderate usage levels)!
# Default: ""
token = ""


[deprecation]

# Set to false to disable the deprecation warning for the file uploader encoding.
# Default: true
showfileUploaderEncoding = true

# Set to false to disable the deprecation warning for using the global pyplot instance.
# Default: true
showPyplotGlobalUse = true


[theme]

# The preset Streamlit theme that your custom theme inherits from. One of "light" or "dark".
# base =

# Primary accent color for interactive elements.
# primaryColor =

# Background color for the main content area.
# backgroundColor =

# Background color used for the sidebar and most interactive widgets.
# secondaryBackgroundColor =

# Color used for almost all text.
# textColor =

# Font family for all text in the app, except code blocks. One of "sans serif", "serif", or "monospace".
# font =
```





# Theming

In this guide, we provide examples of how Streamlit page elements are affected by the various theme config options. For a more high-level overview of Streamlit themes, see the Themes section of the [main concepts documentation](https://docs.streamlit.io/library/get-started/main-concepts#themes).
在本指南中，我们提供了各种主题配置选项如何影响 Streamlit 页面元素的示例。有关 Streamlit 主题的更高级概述，请参阅主要概念文档的主题部分。

Streamlit themes are defined using regular config options: a theme can be set via command line flag when starting your app using `streamlit run` or by defining it in the `[theme]` section of a `.streamlit/config.toml` file. For more information on setting config options, please refer to the [Streamlit configuration documentation](https://docs.streamlit.io/library/advanced-features/configuration#set-configuration-options).
Streamlit 主题是使用常规配置选项定义的：使用 `streamlit run` 启动应用时，可以通过命令行标志设置主题，也可以在 `.streamlit/config.toml` 文件的 `[theme]` 部分中定义主题。有关设置配置选项的详细信息，请参阅 流光配置文档 。

The following config options show the default Streamlit Light theme recreated in the `[theme]` section of a `.streamlit/config.toml` file.
以下配置选项显示在 `.streamlit/config.toml` 文件的 `[theme]` 部分中重新创建的默认流光主题。

```toml
[theme]
primaryColor="#F63366"
backgroundColor="#FFFFFF"
secondaryBackgroundColor="#F0F2F6"
textColor="#262730"
font="sans serif"
```

Copy

Let's go through each of these options, providing screenshots to demonstrate what parts of a Streamlit app they affect where needed.
让我们浏览一下这些选项中的每一个，提供屏幕截图来演示它们在需要时影响 Streamlit 应用程序的哪些部分。



## primaryColor

`primaryColor` defines the accent color most often used throughout a Streamlit app. A few examples of Streamlit widgets that use `primaryColor` include `st.checkbox`, `st.slider`, and `st.text_input` (when focused).
`primaryColor` 定义在整个 Streamlit 应用中最常用的主题色。使用 `primaryColor` 的 Streamlit 小部件的一些示例包括 `st.checkbox` 、 `st.slider` 和 `st.text_input` （聚焦时）。

![Primary Color](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510232404072-301482054.png)

*star*

#### Tip

Any CSS color can be used as the value for primaryColor and the other color options below. This means that theme colors can be specified in hex or with browser-supported color names like "green", "yellow", and "chartreuse". They can even be defined in the RGB and HSL formats!
任何 CSS 颜色都可以用作 primaryColor 和下面的其他颜色选项的值。这意味着主题颜色可以用十六进制或浏览器支持的颜色名称（如“绿色”、“黄色”和“黄绿色”）指定。它们甚至可以用RGB和HSL格式定义！



## backgroundColor

Defines the background color used in the main content area of your app.
定义应用主内容区域中使用的背景色。



## secondaryBackgroundColor 次要背景颜色

This color is used where a second background color is needed for added contrast. Most notably, it is the sidebar's background color. It is also used as the background color for most interactive widgets.
此颜色用于需要第二种背景色以增加对比度的情况。最值得注意的是，它是侧边栏的背景颜色。它也被用作大多数交互式小部件的背景颜色。

![Secondary Background Color](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510232404091-204301670.png)



## textColor

This option controls the text color for most of your Streamlit app.
此选项控制大多数 Streamlit 应用的文本颜色。



## font

Selects the font used in your Streamlit app. Valid values are `"sans serif"`, `"serif"`, and `"monospace"`. This option defaults to `"sans serif"` if unset or invalid.
选择在 Streamlit 应用程序中使用的字体。有效值为 `"sans serif"` 、 `"serif"` 和 `"monospace"` 。如果未设置或无效，则此选项默认为 `"sans serif"` 。

Note that code blocks are always rendered using the monospace font regardless of the font selected here.
请注意，无论此处选择何种字体，代码块始终使用等宽字体呈现。



## base

An easy way to define custom themes that make small changes to one of the preset Streamlit themes is to use the `base` option. Using `base`, the Streamlit Light theme can be recreated as a custom theme by writing the following:
定义对预设 Streamlit 主题之一进行小幅更改的自定义主题的一种简单方法是使用 `base` 选项。使用 `base` ，可以通过编写以下内容将流光主题重新创建为自定义主题：

```toml
[theme]
base="light"
```

Copy

The `base` option allows you to specify a preset Streamlit theme that your custom theme inherits from. Any theme config options not defined in your theme settings have their values set to those of the base theme. Valid values for `base` are `"light"` and `"dark"`.
`base` 选项允许您指定自定义主题继承的预设流光主题。未在主题设置中定义的任何主题配置选项的值都设置为基本主题的值。 `base` 的有效值为 `"light"` 和 `"dark"` 。

For example, the following theme config defines a custom theme nearly identical to the Streamlit Dark theme, but with a new `primaryColor`.
例如，以下主题配置定义了一个与流光深色主题几乎相同的自定义主题，但具有新的 `primaryColor` 。

```toml
[theme]
base="dark"
primaryColor="purple"
```

Copy

If `base` itself is omitted, it defaults to `"light"`, so you can define a custom theme that changes the font of the Streamlit Light theme to serif with the following config
如果省略 `base` 本身，则默认为 `"light"` ，因此您可以使用以下配置定义一个自定义主题，将流光主题的字体更改为衬线

```toml
[theme]
font="serif"
```





# Caching

Streamlit runs your script from top to bottom at every user interaction or code change. This execution model makes development super easy. But it comes with two major challenges:
Streamlit 在每次用户交互或代码更改时从上到下运行您的脚本。这种执行模型使开发变得超级简单。但它带来了两个主要挑战：

1. Long-running functions run again and again, which slows down your app.
   长时间运行的函数会一次又一次地运行，这会降低应用的速度。
2. Objects get recreated again and again, which makes it hard to persist them across reruns or sessions.
   对象会一次又一次地重新创建，这使得很难在重新运行或会话之间保留它们。

But don’t worry! Streamlit lets you tackle both issues with its built-in caching mechanism. Caching stores the results of slow function calls, so they only need to run once. This makes your app much faster and helps with persisting objects across reruns.
但别担心！Streamlit允许您通过其内置的缓存机制解决这两个问题。缓存存储慢速函数调用的结果，因此它们只需要运行一次。这使你的应用速度更快，并有助于在重新运行之间保留对象。

Table of contents 目录*expand_more*

1. [Minimal example](https://docs.streamlit.io/library/advanced-features/caching#minimal-example)
2. [Basic usage](https://docs.streamlit.io/library/advanced-features/caching#basic-usage)
3. [Advanced usage](https://docs.streamlit.io/library/advanced-features/caching#advanced-usage)
4. [Migrating from st.cache 从 st.cache 迁移](https://docs.streamlit.io/library/advanced-features/caching#migrating-from-stcache)



## Minimal example

To cache a function in Streamlit, you must decorate it with one of two decorators (`st.cache_data` or `st.cache_resource`):
要在 Streamlit 中缓存函数，必须使用两个装饰器之一（ `st.cache_data` 或 `st.cache_resource` ）来装饰它：

```python
@st.cache_data
def long_running_function(param1, param2):
    return …
```

Copy

In this example, decorating `long_running_function` with `@st.cache_data` tells Streamlit that whenever the function is called, it checks two things:
在此示例中，使用 `@st.cache_data` 装饰 `long_running_function` 告诉 Streamlit，无论何时调用该函数，它都会检查两件事：

1. The values of the input parameters (in this case, `param1` and `param2`).
   输入参数的值（在本例中为 `param1` 和 `param2` ）。
2. The code inside the function. 函数中的代码。

If this is the first time Streamlit sees these parameter values and function code, it runs the function and stores the return value in a cache. The next time the function is called with the same parameters and code (e.g., when a user interacts with the app), Streamlit will skip executing the function altogether and return the cached value instead. During development, the cache updates automatically as the function code changes, ensuring that the latest changes are reflected in the cache.
如果这是 Streamlit 第一次看到这些参数值和函数代码，它将运行函数并将返回值存储在缓存中。下次使用相同的参数和代码调用函数时（例如，当用户与应用程序交互时），Streamlit 将完全跳过执行函数并返回缓存的值。在开发过程中，缓存会随着函数代码的更改而自动更新，从而确保最新的更改反映在缓存中。

As mentioned, there are two caching decorators:
如前所述，有两个缓存装饰器：

- `st.cache_data` is the recommended way to cache computations that return data: loading a DataFrame from CSV, transforming a NumPy array, querying an API, or any other function that returns a serializable data object (str, int, float, DataFrame, array, list, …). It creates a new copy of the data at each function call, making it safe against [mutations and race conditions](https://docs.streamlit.io/library/advanced-features/caching#mutation-and-concurrency-issues). The behavior of `st.cache_data` is what you want in most cases – so if you're unsure, start with `st.cache_data` and see if it works!
  `st.cache_data` 是缓存返回数据的计算的推荐方法：从 CSV 加载数据帧、转换 NumPy 数组、查询 API 或任何其他返回可序列化数据对象（str、int、float、DataFrame、array、list 等）的函数。它在每次函数调用时都会创建数据的新副本，使其免受突变和竞争条件的影响。在大多数情况下， `st.cache_data` 的行为是您想要的——所以如果您不确定，请从 `st.cache_data` 开始，看看它是否有效！
- `st.cache_resource` is the recommended way to cache global resources like ML models or database connections – unserializable objects that you don’t want to load multiple times. Using it, you can share these resources across all reruns and sessions of an app without copying or duplication. Note that any mutations to the cached return value directly mutate the object in the cache (more details below).
  `st.cache_resource` 是缓存全局资源（如 ML 模型或数据库连接）的推荐方法，即您不想多次加载的不可序列化对象。使用它，您可以在应用的所有重新运行和会话之间共享这些资源，而无需复制或复制。请注意，对缓存返回值的任何更改都会直接改变缓存中的对象（更多详细信息见下文）。

![Streamlit's two caching decorators and their use cases. Use st.cache_data for anything you'd store in a database. Use st.cache_resource for anything you can't store in a database, like a connection to a database or a machine learning model.](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510232537182-1989139878.png)

Streamlit's two caching decorators and their use cases.
Streamlit的两个缓存装饰器及其用例。



## Basic usage



### st.cache_data

`st.cache_data` is your go-to command for all functions that return data – whether DataFrames, NumPy arrays, str, int, float, or other serializable types. It’s the right command for almost all use cases!
`st.cache_data` 是返回数据的所有函数的首选命令 - 无论是数据帧、NumPy 数组、str、int、float 还是其他可序列化类型。这是几乎所有用例的正确命令！

#### Usage



Let's look at an example of using `st.cache_data`. Suppose your app loads the [Uber ride-sharing dataset](https://github.com/plotly/datasets/blob/master/uber-rides-data1.csv) – a CSV file of 50 MB – from the internet into a DataFrame:
让我们看一个使用 `st.cache_data` 的示例。假设您的应用将优步拼车数据集（50 MB 的 CSV 文件）从互联网加载到数据帧中：

```python
def load_data(url):
    df = pd.read_csv(url)  # 👈 Download the data
    return df

df = load_data("https://github.com/plotly/datasets/raw/master/uber-rides-data1.csv")
st.dataframe(df)

st.button("Rerun")
```

Copy

Running the `load_data` function takes 2 to 30 seconds, depending on your internet connection. (Tip: if you are on a slow connection, use [this 5 MB dataset instead](https://github.com/plotly/datasets/blob/master/26k-consumer-complaints.csv)). Without caching, the download is rerun each time the app is loaded or with user interaction. Try it yourself by clicking the button we added! Not a great experience… 😕
运行 `load_data` 函数需要 2 到 30 秒，具体取决于您的互联网连接。（提示：如果您的连接速度较慢，请改用此 5 MB 数据集）。如果没有缓存，则每次加载应用或用户交互时都会重新运行下载。点击我们添加的按钮亲自尝试一下！不是很好的体验...😕

Now let’s add the `@st.cache_data` decorator on `load_data`:
现在让我们在 `load_data` 上添加 `@st.cache_data` 装饰器：

```python
@st.cache_data  # 👈 Add the caching decorator
def load_data(url):
    df = pd.read_csv(url)
    return df

df = load_data("https://github.com/plotly/datasets/raw/master/uber-rides-data1.csv")
st.dataframe(df)

st.button("Rerun")
```

Copy

Run the app again. You'll notice that the slow download only happens on the first run. Every subsequent rerun should be almost instant! 💨
再次运行应用。您会注意到，缓慢的下载仅在第一次运行时发生。每次后续重播都应该几乎是即时的！💨

#### Behavior



How does this work? Let’s go through the behavior of `st.cache_data` step by step:
这是如何工作的？让我们逐步了解 `st.cache_data` 的行为：

- On the first run, Streamlit recognizes that it has never called the `load_data` function with the specified parameter value (the URL of the CSV file) So it runs the function and downloads the data.
  在第一次运行时，Streamlit 认识到它从未使用指定的参数值（CSV 文件的 URL）调用过 `load_data` 函数，因此它会运行该函数并下载数据。
- Now our caching mechanism becomes active: the returned DataFrame is serialized (converted to bytes) via [pickle](https://docs.python.org/3/library/pickle.html) and stored in the cache (together with the value of the `url` parameter).
  现在我们的缓存机制变得活跃：返回的数据帧通过 pickle 序列化（转换为字节）并存储在缓存中（与 `url` 参数的值一起）。
- On the next run, Streamlit checks the cache for an entry of `load_data` with the specific `url`. There is one! So it retrieves the cached object, deserializes it to a DataFrame, and returns it instead of re-running the function and downloading the data again.
  在下一次运行时，Streamlit 会检查缓存中是否有具有特定 `url` 的 `load_data` 条目。有一个！因此，它会检索缓存的对象，将其反序列化为 DataFrame，然后返回它，而不是重新运行函数并再次下载数据。

This process of serializing and deserializing the cached object creates a copy of our original DataFrame. While this copying behavior may seem unnecessary, it’s what we want when caching data objects since it effectively prevents mutation and concurrency issues. Read the section “[Mutation and concurrency issues](https://docs.streamlit.io/library/advanced-features/caching#mutation-and-concurrency-issues)” below to understand this in more detail.
序列化和反序列化缓存对象的过程将创建原始数据帧的副本。虽然这种复制行为似乎没有必要，但它是我们在缓存数据对象时想要的，因为它有效地防止了突变和并发问题。阅读下面的“突变和并发问题”部分以更详细地了解这一点。

#### Examples



**DataFrame transformations 数据帧转换**

In the example above, we already showed how to cache loading a DataFrame. It can also be useful to cache DataFrame transformations such as `df.filter`, `df.apply`, or `df.sort_values`. Especially with large DataFrames, these operations can be slow.
在上面的示例中，我们已经展示了如何缓存加载数据帧。缓存数据帧转换（如 `df.filter` 、 `df.apply` 或 `df.sort_values` ）也很有用。特别是对于大型数据帧，这些操作可能会很慢。

```python
@st.cache_data
def transform(df):
    df = df.filter(items=['one', 'three'])
    df = df.apply(np.sum, axis=0)
    return df
```

Copy

**Array computations 数组计算**

Similarly, it can make sense to cache computations on NumPy arrays:
同样，在 NumPy 数组上缓存计算也是有意义的：

```python
@st.cache_data
def add(arr1, arr2):
    return arr1 + arr2
```

Copy

**Database queries**

You usually make SQL queries to load data into your app when working with databases. Repeatedly running these queries can be slow, cost money, and degrade the performance of your database. We strongly recommend caching any database queries in your app. See also [our guides on connecting Streamlit to different databases](https://docs.streamlit.io/streamlit-community-cloud/get-started/deploy-an-app/connect-to-data-sources) for in-depth examples.
使用数据库时，通常会进行 SQL 查询以将数据加载到应用中。重复运行这些查询可能会很慢、会花费大量资金，并降低数据库的性能。强烈建议在应用中缓存任何数据库查询。另请参阅我们关于将 Streamlit 连接到不同数据库的指南，以获取深入的示例。

```python
connection = database.connect()

@st.cache_data
def query():
    return pd.read_sql_query("SELECT * from table", connection)
```

Copy

*star*

#### Tip

You should set a `ttl` (time to live) to get new results from your database. If you set `st.cache_data(ttl=3600)`, Streamlit invalidates any cached values after 1 hour (3600 seconds) and runs the cached function again. See details in [Controlling cache size and duration](https://docs.streamlit.io/library/advanced-features/caching#controlling-cache-size-and-duration).
应设置 `ttl` （生存时间）以从数据库中获取新结果。如果设置 `st.cache_data(ttl=3600)` ，Streamlit 会在 1 小时（3600 秒）后使任何缓存的值失效，并再次运行缓存函数。有关详细信息，请参阅控制缓存大小和持续时间 。

**API calls**

Similarly, it makes sense to cache API calls. Doing so also avoids rate limits.
同样，缓存 API 调用也是有意义的。这样做还可以避免速率限制。

```python
@st.cache_data
def api_call():
    response = requests.get('https://jsonplaceholder.typicode.com/posts/1')
    return response.json()
```

Copy

**Running ML models (inference) 运行 ML 模型（推理）**

Running complex machine learning models can use significant time and memory. To avoid rerunning the same computations over and over, use caching.
运行复杂的机器学习模型可能会占用大量时间和内存。若要避免一遍又一遍地重新运行相同的计算，请使用缓存。

```python
@st.cache_data
def run_model(inputs):
    return model(inputs)
```

Copy



### st.cache_resource

`st.cache_resource` is the right command to cache “resources” that should be available globally across all users, sessions, and reruns. It has more limited use cases than `st.cache_data`, especially for caching database connections and ML models.
`st.cache_resource` 是缓存应在所有用户、会话和重新运行中全局可用的“资源”的正确命令。它的用例比 `st.cache_data` 更有限，特别是对于缓存数据库连接和 ML 模型。

#### Usage

As an example for `st.cache_resource`, let’s look at a typical machine learning app. As a first step, we need to load an ML model. We do this with [Hugging Face’s transformers library](https://huggingface.co/docs/transformers/index):
以 `st.cache_resource` 为例，让我们看一个典型的机器学习应用。作为第一步，我们需要加载一个 ML 模型。我们使用拥抱脸的变压器库来做到这一点：

```python
from transformers import pipeline
model = pipeline("sentiment-analysis")  # 👈 Load the model
```

Copy

If we put this code into a Streamlit app directly, the app will load the model at each rerun or user interaction. Repeatedly loading the model poses two problems:
如果我们将此代码直接放入 Streamlit 应用中，则应用将在每次重新运行或用户交互时加载模型。重复加载模型会带来两个问题：

- Loading the model takes time and slows down the app.
  加载模型需要时间并减慢应用速度。
- Each session loads the model from scratch, which takes up a huge amount of memory.
  每个会话从头开始加载模型，这会占用大量内存。

Instead, it would make much more sense to load the model once and use that same object across all users and sessions. That’s exactly the use case for `st.cache_resource`! Let’s add it to our app and process some text the user entered:
相反，加载一次模型并在所有用户和会话中使用相同的对象会更有意义。这正是 `st.cache_resource` 的用例！让我们将其添加到我们的应用程序中并处理用户输入的一些文本：

```python
from transformers import pipeline

@st.cache_resource  # 👈 Add the caching decorator
def load_model():
    return pipeline("sentiment-analysis")

query = st.text_input("Your query", value="I love Streamlit! 🎈")
if query:
    result = model(query)[0]  # 👈 Classify the query text
    st.write(result)
```

Copy

If you run this app, you’ll see that the app calls `load_model` only once – right when the app starts. Subsequent runs will reuse that same model stored in the cache, saving time and memory!
如果运行此应用，你将看到应用仅调用 `load_model` 一次 - 就在应用启动时。后续运行将重用存储在缓存中的相同模型，从而节省时间和内存！

#### Behavior



Using `st.cache_resource` is very similar to using `st.cache_data`. But there are a few important differences in behavior:
使用 `st.cache_resource` 与使用 `st.cache_data` 非常相似。但是在行为上有一些重要的差异：

- `st.cache_resource` does **not** create a copy of the cached return value but instead stores the object itself in the cache. All mutations on the function’s return value directly affect the object in the cache, so you must ensure that mutations from multiple sessions do not cause problems. In short, the return value must be thread-safe.
  `st.cache_resource` 不会创建缓存返回值的副本，而是将对象本身存储在缓存中。函数返回值上的所有更改都会直接影响缓存中的对象，因此必须确保来自多个会话的更改不会导致问题。简而言之，返回值必须是线程安全的。

  *priority_high*

  #### Warning

  Using `st.cache_resource` on objects that are not thread-safe might lead to crashes or corrupted data. Learn more below under [Mutation and concurrency issues](https://docs.streamlit.io/library/advanced-features/caching#mutation-and-concurrency-issues).
  在非线程安全对象上使用 `st.cache_resource` 可能会导致崩溃或数据损坏。有关详细信息，请参阅下面的突变和并发问题。

- Not creating a copy means there’s just one global instance of the cached return object, which saves memory, e.g. when using a large ML model. In computer science terms, we create a [singleton](https://en.wikipedia.org/wiki/Singleton_pattern).
  不创建副本意味着缓存返回对象只有一个全局实例，这样可以节省内存，例如在使用大型 ML 模型时。在计算机科学术语中，我们创建了一个单例。

- Return values of functions do not need to be serializable. This behavior is great for types not serializable by nature, e.g., database connections, file handles, or threads. Caching these objects with `st.cache_data` is not possible.
  函数的返回值不需要可序列化。此行为非常适合本质上不可序列化的类型，例如数据库连接、文件句柄或线程。无法使用 `st.cache_data` 缓存这些对象。

#### Examples



**Database connections 数据库连接**

`st.cache_resource` is useful for connecting to databases. Usually, you’re creating a connection object that you want to reuse globally for every query. Creating a new connection object at each run would be inefficient and might lead to connection errors. That’s exactly what `st.cache_resource` can do, e.g., for a Postgres database:
`st.cache_resource` 对于连接到数据库很有用。通常，您正在创建一个要为每个查询全局重用的连接对象。在每次运行时创建新的连接对象效率低下，并可能导致连接错误。这正是 `st.cache_resource` 可以做的，例如，对于Postgres数据库：

```python
@st.cache_resource
def init_connection():
    host = "hh-pgsql-public.ebi.ac.uk"
    database = "pfmegrnargs"
    user = "reader"
    password = "NWDMCE5xdipIjRrp"
    return psycopg2.connect(host=host, database=database, user=user, password=password)

conn = init_connection()
```

Copy

Of course, you can do the same for any other database. Have a look at [our guides on how to connect Streamlit to databases](https://docs.streamlit.io/streamlit-community-cloud/get-started/deploy-an-app/connect-to-data-sources) for in-depth examples.
当然，您可以对任何其他数据库执行相同的操作。查看我们关于如何将 Streamlit 连接到数据库的指南，以获取深入的示例。

**Loading ML models 加载 ML 模型**

Your app should always cache ML models, so they are not loaded into memory again for every new session. See the [example](https://docs.streamlit.io/library/advanced-features/caching#usage-1) above for how this works with 🤗 Hugging Face models. You can do the same thing for PyTorch, TensorFlow, etc. Here’s an example for PyTorch:
您的应用应始终缓存 ML 模型，因此不会为每个新会话再次加载到内存中。请参阅上面的示例，了解如何与拥抱面部模型配合🤗使用。你可以对PyTorch，TensorFlow等做同样的事情。下面是 PyTorch 的一个例子：

```python
@st.cache_resource
def load_model():
    model = torchvision.models.resnet50(weights=ResNet50_Weights.DEFAULT)
    model.eval()
    return model

model = load_model()
```

Copy



### Deciding which caching decorator to use 决定使用哪个缓存修饰器



The sections above showed many common examples for each caching decorator. But there are edge cases for which it’s less trivial to decide which caching decorator to use. Eventually, it all comes down to the difference between “data” and “resource”:
上面的部分显示了每个缓存装饰器的许多常见示例。但在某些边缘情况下，决定使用哪个缓存装饰器就不那么简单了。最终，这一切都归结为“数据”和“资源”之间的区别：

- Data are serializable objects (objects that can be converted to bytes via [pickle](https://docs.python.org/3/library/pickle.html)) that you could easily save to disk. Imagine all the types you would usually store in a database or on a file system – basic types like str, int, and float, but also arrays, DataFrames, images, or combinations of these types (lists, tuples, dicts, and so on).
  数据是可序列化的对象（可以通过 pickle 转换为字节的对象），您可以轻松地将其保存到磁盘。想象一下您通常存储在数据库或文件系统中的所有类型 - 基本类型，如 str、int 和 float，还有数组、数据帧、图像或这些类型的组合（列表、元组、字典等）。
- Resources are unserializable objects that you usually would not save to disk or a database. They are often more complex, non-permanent objects like database connections, ML models, file handles, threads, etc.
  资源是通常不会保存到磁盘或数据库的不可序列化对象。它们通常是更复杂的非永久性对象，如数据库连接、ML 模型、文件句柄、线程等。

From the types listed above, it should be obvious that most objects in Python are “data.” That’s also why `st.cache_data` is the correct command for almost all use cases. `st.cache_resource` is a more exotic command that you should only use in specific situations.
从上面列出的类型来看，应该很明显，Python 中的大多数对象都是“数据”。这也是为什么 `st.cache_data` 是几乎所有用例的正确命令。 `st.cache_resource` 是一个更奇特的命令，您应该只在特定情况下使用。

Or if you’re lazy and don’t want to think too much, look up your use case or return type in the table below 😉:
或者，如果您很懒惰并且不想考虑太多，请在下表😉中查找您的用例或返回类型：

| Use case                                                     | Typical return types 典型返回类型                            | Caching decorator                                            |
| ------------------------------------------------------------ | ------------------------------------------------------------ | ------------------------------------------------------------ |
| Reading a CSV file with pd.read_csv 读取带有pd.read_csv的 CSV 文件 | pandas.DataFrame                                             | st.cache_data                                                |
| Reading a text file 读取文本文件                             | str, list of str str， str 列表                              | st.cache_data                                                |
| Transforming pandas dataframes 转换熊猫数据帧                | pandas.DataFrame, pandas.Series 熊猫。数据帧，熊猫。系列     | st.cache_data                                                |
| Computing with numpy arrays 使用 numpy 数组进行计算          | numpy.ndarray                                                | st.cache_data                                                |
| Simple computations with basic types 使用基本类型进行简单计算 | str, int, float, … str， int， float， ...                   | st.cache_data                                                |
| Querying a database 查询数据库                               | pandas.DataFrame                                             | st.cache_data                                                |
| Querying an API 查询接口                                     | pandas.DataFrame, str, dict 熊猫。DataFrame， str， dict     | st.cache_data                                                |
| Running an ML model (inference) 运行 ML 模型（推理）         | pandas.DataFrame, str, int, dict, list 熊猫。DataFrame， str， int， dict， list | st.cache_data                                                |
| Creating or processing images 创建或处理图像                 | PIL.Image.Image, numpy.ndarray 必。Image.Image， numpy.ndarray | st.cache_data                                                |
| Creating charts                                              | matplotlib.figure.Figure, plotly.graph_objects.Figure, altair.Chart matplotlib.figure.Figure， plotly.graph_objects.图，牵牛星。图表 | st.cache_data (but some libraries require st.cache_resource, since the chart object is not serializable – make sure not to mutate the chart after creation!) st.cache_data（但有些库需要st.cache_resource，因为图表对象不可序列化 - 确保在创建后不要改变图表！ |
| Loading ML models 加载 ML 模型                               | transformers.Pipeline, torch.nn.Module, tensorflow.keras.Model 变形金刚。Pipeline， torch.nn.Module， tensorflow.keras.Model | st.cache_resource                                            |
| Initializing database connections 初始化数据库连接           | pyodbc.Connection, sqlalchemy.engine.base.Engine, psycopg2.connection, mysql.connector.MySQLConnection, sqlite3.Connection 噗嗤。Connection， sqlalchemy.engine.base.Engine， psycopg2.connection， mysql.connector.MySQLConnection， sqlite3.连接 | st.cache_resource                                            |
| Opening persistent file handles 打开持久文件句柄             | _io.TextIOWrapper                                            | st.cache_resource                                            |
| Opening persistent threads 打开持久线程                      | threading.thread                                             | st.cache_resource                                            |



## Advanced usage



### Controlling cache size and duration 控制缓存大小和持续时间

If your app runs for a long time and constantly caches functions, you might run into two problems:
如果您的应用长时间运行并不断缓存函数，您可能会遇到两个问题：

1. The app runs out of memory because the cache is too large.
   应用内存不足，因为缓存太大。
2. Objects in the cache become stale, e.g. because you cached old data from a database.
   缓存中的对象变得过时，例如，因为您缓存了数据库中的旧数据。

You can combat these problems with the `ttl` and `max_entries` parameters, which are available for both caching decorators.
您可以使用 `ttl` 和 `max_entries` 参数解决这些问题，这些参数可用于缓存装饰器。

**The `ttl` (time-to-live) parameter `ttl` （生存时间）参数**

`ttl` sets a time to live on a cached function. If that time is up and you call the function again, the app will discard any old, cached values, and the function will be rerun. The newly computed value will then be stored in the cache. This behavior is useful for preventing stale data (problem 2) and the cache from growing too large (problem 1). Especially when pulling data from a database or API, you should always set a `ttl` so you are not using old data. Here’s an example:
`ttl` 设置在缓存函数上生存的时间。如果该时间已到，并且您再次调用该函数，则应用将丢弃任何旧的缓存值，并且该函数将重新运行。然后，新计算的值将存储在缓存中。此行为对于防止过时数据 （问题 2） 和缓存变得太大 （问题 1） 非常有用。尤其是在从数据库或 API 中提取数据时，应始终设置 `ttl` ，以便不使用旧数据。下面是一个示例：

```python
@st.cache_data(ttl=3600)  # 👈 Cache data for 1 hour (=3600 seconds)
def get_api_data():
    data = api.get(...)
    return data
```

Copy

*star*

#### Tip

You can also set `ttl` values using `timedelta`, e.g., `ttl=datetime.timedelta(hours=1)`.
您也可以使用 `timedelta` 设置 `ttl` 值，例如 `ttl=datetime.timedelta(hours=1)` 。

**The `max_entries` parameter `max_entries` 参数**

`max_entries` sets the maximum number of entries in the cache. An upper bound on the number of cache entries is useful for limiting memory (problem 1), especially when caching large objects. The oldest entry will be removed when a new entry is added to a full cache. Here’s an example:
`max_entries` 设置缓存中的最大条目数。缓存条目数的上限对于限制内存（问题 1）很有用，尤其是在缓存大型对象时。将新条目添加到完整缓存时，将删除最旧的条目。下面是一个示例：

```python
@st.cache_data(max_entries=1000)  # 👈 Maximum 1000 entries in the cache
def get_large_array(seed):
    np.random.seed(seed)
    arr = np.random.rand(100000)
    return arr
```

Copy



### Customizing the spinner 自定义微调器

By default, Streamlit shows a small loading spinner in the app when a cached function is running. You can modify it easily with the `show_spinner` parameter, which is available for both caching decorators:
默认情况下，当缓存函数正在运行时，Streamlit 会在应用中显示一个小的加载微调器。您可以使用 `show_spinner` 参数轻松修改它，该参数可用于两个缓存装饰器：

```python
@st.cache_data(show_spinner=False)  # 👈 Disable the spinner
def get_api_data():
    data = api.get(...)
    return data

@st.cache_data(show_spinner="Fetching data from API...")  # 👈 Use custom text for spinner
def get_api_data():
    data = api.get(...)
    return data
```

Copy



### Excluding input parameters 排除输入参数

In a cached function, all input parameters must be hashable. Let’s quickly explain why and what it means. When the function is called, Streamlit looks at its parameter values to determine if it was cached before. Therefore, it needs a reliable way to compare the parameter values across function calls. Trivial for a string or int – but complex for arbitrary objects! Streamlit uses [hashing](https://en.wikipedia.org/wiki/Hash_function) to solve that. It converts the parameter to a stable key and stores that key. At the next function call, it hashes the parameter again and compares it with the stored hash key.
在缓存函数中，所有输入参数都必须是可哈希的。让我们快速解释一下原因和含义。调用该函数时，Streamlit 会查看其参数值，以确定它之前是否缓存过。因此，它需要一种可靠的方法来比较函数调用之间的参数值。对于字符串或 int 来说微不足道 - 但对于任意对象来说很复杂！Streamlit使用哈希来解决这个问题。它将参数转换为稳定键并存储该键。在下一次函数调用时，它会再次对参数进行哈希处理，并将其与存储的哈希键进行比较。

Unfortunately, not all parameters are hashable! E.g., you might pass an unhashable database connection or ML model to your cached function. In this case, you can exclude input parameters from caching. Simply prepend the parameter name with an underscore (e.g., `_param1`), and it will not be used for caching. Even if it changes, Streamlit will return a cached result if all the other parameters match up.
不幸的是，并非所有参数都是可哈希的！例如，您可以将不可哈希处理的数据库连接或 ML 模型传递给缓存的函数。在这种情况下，您可以从缓存中排除输入参数。只需在参数名称前面加上下划线（例如 `_param1` ），它就不会用于缓存。即使它发生了变化，如果所有其他参数都匹配，Streamlit 也会返回缓存的结果。

Here’s an example: 下面是一个示例：

```python
@st.cache_data
def fetch_data(_db_connection, num_rows):  # 👈 Don't hash _db_connection
    data = _db_connection.fetch(num_rows)
    return data

connection = init_connection()
fetch_data(connection, 10)
```

Copy



### Using Streamlit commands in cached functions 在缓存函数中使用流光命令

#### Static elements 静态元素

Since version 1.16.0, cached functions can contain Streamlit commands! For example, you can do this:
从版本 1.16.0 开始，缓存的函数可以包含 Streamlit 命令！例如，您可以执行以下操作：

```python
@st.cache_data
def get_api_data():
    data = api.get(...)
    st.success("Fetched data from API!")  # 👈 Show a success message
    return data
```

Copy

As we know, Streamlit only runs this function if it hasn’t been cached before. On this first run, the `st.success` message will appear in the app. But what happens on subsequent runs? It still shows up! Streamlit realizes that there is an `st.` command inside the cached function, saves it during the first run, and replays it on subsequent runs. Replaying static elements works for both caching decorators.
众所周知，Streamlit仅在以前未缓存过的情况下运行此功能。首次运行时， `st.success` 消息将显示在应用中。但是在后续运行中会发生什么？它仍然出现！Streamlit 意识到缓存函数中有一个 `st.` 命令，在第一次运行时保存它，并在后续运行时重播它。重播静态元素适用于两个缓存装饰器。

You can also use this functionality to cache entire parts of your UI:
您还可以使用此功能缓存 UI 的整个部分：

```python
@st.cache_data
def show_data():
    st.header("Data analysis")
    data = api.get(...)
    st.success("Fetched data from API!")
    st.write("Here is a plot of the data:")
    st.line_chart(data)
    st.write("And here is the raw data:")
    st.dataframe(data)
```

Copy

#### Input widgets 输入小部件

You can also use [interactive input widgets](https://docs.streamlit.io/library/api-reference/widgets) like `st.slider` or `st.text_input` in cached functions. Widget replay is an experimental feature at the moment. To enable it, you need to set the `experimental_allow_widgets` parameter:
您还可以在缓存函数中使用交互式输入小部件，如 `st.slider` 或 `st.text_input` 。小部件重播目前是一项实验性功能。要启用它，您需要设置 `experimental_allow_widgets` 参数：

```python
@st.cache_data(experimental_allow_widgets=True)  # 👈 Set the parameter
def get_data():
    num_rows = st.slider("Number of rows to get")  # 👈 Add a slider
    data = api.get(..., num_rows)
    return data
```

Copy

Streamlit treats the slider like an additional input parameter to the cached function. If you change the slider position, Streamlit will see if it has already cached the function for this slider value. If yes, it will return the cached value. If not, it will rerun the function using the new slider value.
Streamlit 将滑块视为缓存函数的附加输入参数。如果更改滑块位置，Streamlit 将查看它是否已缓存此滑块值的函数。如果是，它将返回缓存的值。如果没有，它将使用新的滑块值重新运行函数。

Using widgets in cached functions is extremely powerful because it lets you cache entire parts of your app. But it can be dangerous! Since Streamlit treats the widget value as an additional input parameter, it can easily lead to excessive memory usage. Imagine your cached function has five sliders and returns a 100 MB DataFrame. Then we’ll add 100 MB to the cache for *every permutation* of these five slider values – even if the sliders do not influence the returned data! These additions can make your cache explode very quickly. Please be aware of this limitation if you use widgets in cached functions. We recommend using this feature only for isolated parts of your UI where the widgets directly influence the cached return value.
在缓存函数中使用微件非常强大，因为它允许您缓存应用程序的整个部分。但这可能很危险！由于 Streamlit 将小部件值视为额外的输入参数，因此很容易导致内存使用过多。假设缓存的函数有五个滑块，并返回一个 100 MB 的数据帧。然后，我们将为这五个滑块值的每个排列在缓存中添加 100 MB - 即使滑块不会影响返回的数据！这些添加功能会使您的缓存迅速爆炸。如果您在缓存函数中使用小部件，请注意此限制。我们建议仅将此功能用于 UI 的隔离部分，其中小组件直接影响缓存的返回值。

*priority_high*

#### Warning

Support for widgets in cached functions is experimental. We may change or remove it anytime without warning. Please use it with care!
对缓存函数中的小部件的支持是实验性的。我们可能会随时更改或删除它，恕不另行通知。请小心使用！

*push_pin*

#### Note

Two widgets are currently not supported in cached functions: `st.file_uploader` and `st.camera_input`. We may support them in the future. Feel free to [open a GitHub issue](https://github.com/streamlit/streamlit/issues) if you need them!
缓存函数中目前不支持两个小部件： `st.file_uploader` 和 `st.camera_input` 。我们将来可能会支持他们。如果需要，请随时打开 GitHub 问题！



### Dealing with large data 处理大数据

As we explained, you should cache data objects with `st.cache_data`. But this can be slow for extremely large data, e.g., DataFrames or arrays with >100 million rows. That’s because of the [copying behavior](https://docs.streamlit.io/library/advanced-features/caching#copying-behavior) of `st.cache_data`: on the first run, it serializes the return value to bytes and deserializes it on subsequent runs. Both operations take time.
正如我们所解释的，您应该使用 `st.cache_data` 缓存数据对象。但对于非常大的数据（例如，数据帧或具有 > 1 亿行的数组），这可能会很慢。这是因为 `st.cache_data` 的复制行为：在第一次运行时，它将返回值序列化为字节，并在后续运行时将其反序列化。这两种操作都需要时间。

If you’re dealing with extremely large data, it can make sense to use `st.cache_resource` instead. It does not create a copy of the return value via serialization/deserialization and is almost instant. But watch out: any mutation to the function’s return value (such as dropping a column from a DataFrame or setting a value in an array) directly manipulates the object in the cache. You must ensure this doesn’t corrupt your data or lead to crashes. See the section on [Mutation and concurrency issues](https://docs.streamlit.io/library/advanced-features/caching#mutation-and-concurrency-issues) below.
如果要处理非常大的数据，则改用 `st.cache_resource` 是有意义的。它不会通过序列化/反序列化创建返回值的副本，并且几乎是即时的。但要注意：函数返回值的任何更改（例如从数据帧中删除列或在数组中设置值）都会直接操作缓存中的对象。您必须确保这不会损坏您的数据或导致崩溃。请参阅下面有关突变和并发问题的部分。

When benchmarking `st.cache_data` on pandas DataFrames with four columns, we found that it becomes slow when going beyond 100 million rows. The table shows runtimes for both caching decorators at different numbers of rows (all with four columns):
在具有四列的熊猫数据帧上对 `st.cache_data` 进行基准测试时，我们发现当超过 1 亿行时，它会变慢。下表显示了两个缓存装饰器在不同行数（所有行数均为四列）下的运行时：

|                   |                 | 10M rows | 50M rows | 100M rows | 200M rows |
| ----------------- | --------------- | -------- | -------- | --------- | --------- |
| st.cache_data     | First run*      | 0.4 s    | 3 s      | 14 s      | 28 s      |
|                   | Subsequent runs | 0.2 s    | 1 s      | 2 s       | 7 s       |
| st.cache_resource | First run*      | 0.01 s   | 0.1 s    | 0.2 s     | 1 s       |
|                   | Subsequent runs | 0 s      | 0 s      | 0 s       | 0 s       |

|                                                              |
| ------------------------------------------------------------ |
| **For the first run, the table only shows the overhead time of using the caching decorator. It does not include the runtime of the cached function itself. \*对于第一次运行，该表仅显示使用缓存装饰器的开销时间。它不包括缓存函数本身的运行时。* |



### Mutation and concurrency issues 突变和并发问题

In the sections above, we talked a lot about issues when mutating return objects of cached functions. This topic is complicated! But it’s central to understanding the behavior differences between `st.cache_data` and `st.cache_resource`. So let’s dive in a bit deeper.
在上面的部分中，我们讨论了很多关于改变缓存函数的返回对象时的问题。这个话题很复杂！但它是理解 `st.cache_data` 和 `st.cache_resource` 之间行为差异的核心。因此，让我们更深入地了解一下。

First, we should clearly define what we mean by mutations and concurrency:
首先，我们应该明确定义突变和并发的含义：

- By **mutations**, we mean any changes made to a cached function’s return value *after* that function has been called. I.e. something like this:
  突变是指在调用缓存函数后对该函数的返回值所做的任何更改。即像这样：

  ```python
  @st.cache_data
  def create_list():
      l = [1, 2, 3]
  
  l = create_list()  # 👈 Call the function
  l[0] = 2  # 👈 Mutate its return value
  ```

  Copy

- By **concurrency**, we mean that multiple sessions can cause these mutations at the same time. Streamlit is a web framework that needs to handle many users and sessions connecting to an app. If two people view an app at the same time, they will both cause the Python script to rerun, which may manipulate cached return objects at the same time – concurrently.
  通过并发，我们的意思是多个会话可以同时导致这些突变。Streamlit是一个Web框架，需要处理连接到应用程序的许多用户和会话。如果两个人同时查看一个应用程序，他们都会导致 Python 脚本重新运行，这可能会同时操作缓存的返回对象 - 同时。

Mutating cached return objects can be dangerous. It can lead to exceptions in your app and even corrupt your data (which can be worse than a crashed app!). Below, we’ll first explain the copying behavior of `st.cache_data` and show how it can avoid mutation issues. Then, we’ll show how concurrent mutations can lead to data corruption and how to prevent it.
更改缓存的返回对象可能很危险。它可能会导致您的应用程序中出现异常，甚至损坏您的数据（这可能比崩溃的应用程序更糟糕！下面，我们将首先解释 `st.cache_data` 的复制行为，并展示它如何避免突变问题。然后，我们将展示并发突变如何导致数据损坏以及如何防止它。

#### Copying behavior 复制行为

`st.cache_data` creates a copy of the cached return value each time the function is called. This avoids most mutations and concurrency issues. To understand it in detail, let’s go back to the [Uber ridesharing example](https://docs.streamlit.io/library/advanced-features/caching#usage) from the section on `st.cache_data` above. We are making two modifications to it:
`st.cache_data` 在每次调用函数时创建缓存返回值的副本。这样可以避免大多数突变和并发问题。为了详细理解它，让我们回到上面 `st.cache_data` 部分中的优步拼车示例。我们正在对其进行两项修改：

1. We are using `st.cache_resource` instead of `st.cache_data`. `st.cache_resource` does **not** create a copy of the cached object, so we can see what happens without the copying behavior.
   我们使用 `st.cache_resource` 而不是 `st.cache_data` 。 `st.cache_resource` 不会创建缓存对象的副本，因此我们可以看到在没有复制行为的情况下会发生什么。
2. After loading the data, we manipulate the returned DataFrame (in place!) by dropping the column `"Lat"`.
   加载数据后，我们通过删除列 `"Lat"` 来操作返回的数据帧（就地！

Here’s the code: 代码如下：

```python
@st.cache_resource   # 👈 Turn off copying behavior
def load_data(url):
    df = pd.read_csv(url)
    return df

df = load_data("https://raw.githubusercontent.com/plotly/datasets/master/uber-rides-data1.csv")
st.dataframe(df)

df.drop(columns=['Lat'], inplace=True)  # 👈 Mutate the dataframe inplace

st.button("Rerun")
```

Copy

Let’s run it and see what happens! The first run should work fine. But in the second run, you see an exception: `KeyError: "['Lat'] not found in axis"`. Why is that happening? Let’s go step by step:
让我们运行它，看看会发生什么！第一次运行应该工作正常。但在第二次运行中，您会看到一个异常： `KeyError: "['Lat'] not found in axis"` 。为什么会这样？让我们一步一步来：

- On the first run, Streamlit runs `load_data` and stores the resulting DataFrame in the cache. Since we’re using `st.cache_resource`, it does **not** create a copy but stores the original DataFrame.
  在第一次运行时，Streamlit 运行 `load_data` 并将生成的数据帧存储在缓存中。由于我们使用的是 `st.cache_resource` ，它不会创建副本，而是存储原始数据帧。
- Then we drop the column `"Lat"` from the DataFrame. Note that this is dropping the column from the *original* DataFrame stored in the cache. We are manipulating it!
  然后，我们从数据帧中删除 `"Lat"` 列。请注意，这会从缓存中存储的原始数据帧中删除列。我们正在操纵它！
- On the second run, Streamlit returns that exact same manipulated DataFrame from the cache. It does not have the column `"Lat"` anymore! So our call to `df.drop` results in an exception. Pandas cannot drop a column that doesn’t exist.
  在第二次运行时，Streamlit 从缓存中返回完全相同的操作数据帧。它不再有 `"Lat"` 列！因此，我们对 `df.drop` 的调用会导致异常。熊猫不能删除不存在的列。

The copying behavior of `st.cache_data` prevents this kind of mutation error. Mutations can only affect a specific copy and not the underlying object in the cache. The next rerun will get its own, unmutated copy of the DataFrame. You can try it yourself, just replace `st.cache_resource` with `st.cache_data` above, and you’ll see that everything works.
`st.cache_data` 的复制行为可防止此类突变错误。突变只能影响特定副本，而不会影响缓存中的基础对象。下一次重新运行将获得其自己的未突变的数据帧副本。您可以自己尝试，只需将 `st.cache_resource` 替换为上面的 `st.cache_data` ，您就会看到一切正常。

Because of this copying behavior, `st.cache_data` is the recommended way to cache data transforms and computations – anything that returns a serializable object.
由于这种复制行为， `st.cache_data` 是缓存数据转换和计算的推荐方法 - 任何返回可序列化对象的内容。

#### Concurrency issues 并发问题

Now let’s look at what can happen when multiple users concurrently mutate an object in the cache. Let's say you have a function that returns a list. Again, we are using `st.cache_resource` to cache it so that we are not creating a copy:
现在让我们看看当多个用户同时改变缓存中的对象时会发生什么。假设您有一个返回列表的函数。同样，我们使用 `st.cache_resource` 来缓存它，这样我们就不会创建副本：

```python
@st.cache_resource
def create_list():
    l = [1, 2, 3]
    return l

l = create_list()
first_list_value = l[0]
l[0] = first_list_value + 1

st.write("l[0] is:", l[0])
```

Copy

Let's say user A runs the app. They will see the following output:
假设用户 A 运行应用。他们将看到以下输出：

```python
l[0] is: 2
```

Copy

Let's say another user, B, visits the app right after. In contrast to user A, they will see the following output:
假设另一个用户 B 紧接着访问了该应用程序。与用户 A 相反，他们将看到以下输出：

```python
l[0] is: 3
```

Copy

Now, user A reruns the app immediately after user B. They will see the following output:
现在，用户 A 在用户 B 之后立即重新运行应用。他们将看到以下输出：

```python
l[0] is: 4
```

Copy

What is happening here? Why are all outputs different?
这是怎么回事？为什么所有输出都不同？

- When user A visits the app, `create_list()` is called, and the list `[1, 2, 3]` is stored in the cache. This list is then returned to user A. The first value of the list, `1`, is assigned to `first_list_value` , and `l[0]` is changed to `2`.
  当用户 A 访问应用时，将调用 `create_list()` ，并将列表 `[1, 2, 3]` 存储在缓存中。然后将此列表返回给用户 A。列表的第一个值 `1` 分配给 `first_list_value` ， `l[0]` 更改为 `2` 。
- When user B visits the app, `create_list()` returns the mutated list from the cache: `[2, 2, 3]`. The first value of the list, `2`, is assigned to `first_list_value` and `l[0]` is changed to `3`.
  当用户 B 访问应用时， `create_list()` 从缓存中返回突变列表： `[2, 2, 3]` 。列表的第一个值 `2` 分配给 `first_list_value` ， `l[0]` 更改为 `3` 。
- When user A reruns the app, `create_list()` returns the mutated list again: `[3, 2, 3]`. The first value of the list, `3`, is assigned to `first_list_value,` and `l[0]` is changed to 4.
  当用户 A 重新运行应用时， `create_list()` 再次返回突变列表： `[3, 2, 3]` 。列表的第一个值 `3` 分配给 `first_list_value,` ， `l[0]` 更改为 4。

If you think about it, this makes sense. Users A and B use the same list object (the one stored in the cache). And since the list object is mutated, user A's change to the list object is also reflected in user B's app.
如果你仔细想想，这是有道理的。用户 A 和 B 使用相同的列表对象（存储在缓存中的对象）。并且由于列表对象发生了变异，用户 A 对列表对象的更改也会反映在用户 B 的应用程序中。

This is why you must be careful about mutating objects cached with `st.cache_resource`, especially when multiple users access the app concurrently. If we had used `st.cache_data` instead of `st.cache_resource`, the app would have copied the list object for each user, and the above example would have worked as expected – users A and B would have both seen:
这就是为什么您必须小心改变使用 `st.cache_resource` 缓存的对象，尤其是当多个用户同时访问应用程序时。如果我们使用 `st.cache_data` 而不是 `st.cache_resource` ，应用程序将为每个用户复制列表对象，并且上面的示例将按预期工作——用户 A 和 B 都会看到：

```python
l[0] is: 2
```

Copy

*push_pin*

#### Note

This toy example might seem benign. But data corruption can be extremely dangerous! Imagine we had worked with the financial records of a large bank here. You surely don’t want to wake up with less money on your account just because someone used the wrong caching decorator 😉
这个玩具的例子可能看起来是良性的。但是数据损坏可能非常危险！想象一下，我们在这里处理了一家大银行的财务记录。您肯定不想仅仅因为有人使用了错误的缓存装饰器😉而醒来时您的帐户上的钱更少



## Migrating from st.cache 从 st.cache 迁移

We introduced the caching commands described above in Streamlit 1.18.0. Before that, we had one catch-all command `st.cache`. Using it was often confusing, resulted in weird exceptions, and was slow. That’s why we replaced `st.cache` with the new commands in 1.18.0 (read more in this [blog post](https://blog.streamlit.io/introducing-two-new-caching-commands-to-replace-st-cache/)). The new commands provide a more intuitive and efficient way to cache your data and resources and are intended to replace `st.cache` in all new development.
我们在 Streamlit 1.18.0 中引入了上述缓存命令。在此之前，我们有一个包罗万象的命令 `st.cache` 。使用它经常令人困惑，导致奇怪的异常，并且速度很慢。这就是为什么我们将 `st.cache` 替换为1.18.0中的新命令的原因（在此博客文章中阅读更多内容）。新命令提供了一种更直观、更高效的方式来缓存数据和资源，旨在取代所有新开发中的 `st.cache` 。

If your app is still using `st.cache`, don’t despair! Here are a few notes on migrating:
如果您的应用程序仍在使用 `st.cache` ，请不要绝望！以下是有关迁移的一些注意事项：

- `st.cache` is deprecated. • New versions of Streamlit will show a deprecation warning if your app uses it.
  `st.cache` 已弃用。• 如果您的应用使用它，新版本的 Streamlit 将显示弃用警告。

- We will not remove `st.cache` soon, so you don’t need to worry about your 2-year-old app breaking. But we encourage you to try the new commands going forward – they will be way less annoying!
  我们不会很快删除 `st.cache` ，因此您无需担心2年前的应用程序会损坏。但是我们鼓励您尝试新的命令 - 它们不会那么烦人！

- Switching code to the new commands should be easy in most cases. To decide whether to use `st.cache_data` or `st.cache_resource`, read [Deciding which caching decorator to use](https://docs.streamlit.io/library/advanced-features/caching#deciding-which-caching-decorator-to-use). Streamlit will also recognize common use cases and show hints right in the deprecation warnings.
  在大多数情况下，将代码切换到新命令应该很容易。要决定是使用 `st.cache_data` 还是 `st.cache_resource` ，请阅读决定使用哪个缓存修饰器 。Streamlit还将识别常见用例，并在弃用警告中显示提示。

- Most parameters from 

  ```
  st.cache
  ```

   are also present in the new commands, with a few exceptions:

  
  `st.cache` 中的大多数参数也存在于新命令中，但有一些例外：

  - `allow_output_mutation` does not exist anymore. You can safely delete it. Just make sure you use the right caching command for your use case.
    `allow_output_mutation` 不再存在。您可以安全地删除它。只需确保为您的用例使用正确的缓存命令即可。
  - `suppress_st_warning` does not exist anymore. You can safely delete it. Cached functions can now contain Streamlit commands and will replay them. If you want to use widgets inside cached functions, set `experimental_allow_widgets=True`. See [here](https://docs.streamlit.io/library/advanced-features/caching#using-streamlit-commands-in-cached-functions).
    `suppress_st_warning` 不再存在。您可以安全地删除它。缓存的函数现在可以包含 Streamlit 命令，并将重播它们。如果要在缓存函数中使用小部件，请设置 `experimental_allow_widgets=True` 。看这里 .
  - `hash_funcs` does not exist anymore. You can exclude parameters from caching (and being hashed) by prepending them with an underscore: `_excluded_param`. See [here](https://docs.streamlit.io/library/advanced-features/caching#excluding-input-parameters).
    `hash_funcs` 不再存在。您可以通过在参数前面加上下划线来从缓存（和哈希）中排除参数： `_excluded_param` 。看这里 .

If you have any questions or issues during the migration process, please contact us on the [forum](https://discuss.streamlit.io/), and we will be happy to assist you. 🎈
如果您在迁移过程中有任何疑问或问题，请在论坛上与我们联系，我们将很乐意为您提供帮助。🎈





# Optimize performance with st.cache 使用 st.cache 优化性能

Streamlit provides a caching mechanism that allows your app to stay performant even when loading data from the web, manipulating large datasets, or performing expensive computations. This is done with the [`@st.cache`](https://docs.streamlit.io/library/api-reference/performance/st.cache) decorator.
Streamlit 提供了一种缓存机制，即使在从 Web 加载数据、操作大型数据集或执行昂贵的计算时，您的应用也能保持性能。这是使用 `@st.cache` 装饰器完成的。

When you mark a function with the [`@st.cache`](https://docs.streamlit.io/library/api-reference/performance/st.cache) decorator, it tells Streamlit that whenever the function is called it needs to check a few things:
当您使用 `@st.cache` 装饰器标记函数时，它会告诉 Streamlit，无论何时调用该函数，它都需要检查一些事项：

1. The input parameters that you called the function with
   用于调用函数的输入参数
2. The value of any external variable used in the function
   函数中使用的任何外部变量的值
3. The body of the function 函数的主体
4. The body of any function used inside the cached function
   缓存函数内使用的任何函数的主体

If this is the first time Streamlit has seen these four components with these exact values and in this exact combination and order, it runs the function and stores the result in a local cache. Then, next time the cached function is called, if none of these components changed, Streamlit will just skip executing the function altogether and, instead, return the output previously stored in the cache.
如果这是 Streamlit 第一次看到这四个组件具有这些精确的值，并且以这种精确的组合和顺序，它将运行该函数并将结果存储在本地缓存中。然后，下次调用缓存函数时，如果这些组件都没有更改，Streamlit 将完全跳过执行该函数，而是返回以前存储在缓存中的输出。

The way Streamlit keeps track of changes in these components is through hashing. Think of the cache as an in-memory key-value store, where the key is a hash of all of the above and the value is the actual output object passed by reference.
Streamlit跟踪这些组件中的变化的方式是通过哈希。将缓存视为内存中的键值存储，其中键是上述所有内容的哈希，值是通过引用传递的实际输出对象。

Finally, [`@st.cache`](https://docs.streamlit.io/library/api-reference/performance/st.cache) supports arguments to configure the cache's behavior. You can find more information on those in our [API reference](https://docs.streamlit.io/library/api-reference).
最后， `@st.cache` 支持用于配置缓存行为的参数。您可以在我们的 API 参考中找到有关这些内容的更多信息。

Let's take a look at a few examples that illustrate how caching works in a Streamlit app.
让我们看几个示例，这些示例说明了缓存在 Streamlit 应用中的工作原理。



## Example 1: Basic usage 示例 1：基本用法

For starters, let's take a look at a sample app that has a function that performs an expensive, long-running computation. Without caching, this function is rerun each time the app is refreshed, leading to a poor user experience. Copy this code into a new app and try it out yourself:
首先，让我们看一个示例应用，该应用具有执行昂贵、长时间运行的计算的函数。如果没有缓存，则每次刷新应用时都会重新运行此函数，从而导致用户体验不佳。将此代码复制到新应用中并亲自试用：

```python
import streamlit as st
import time

def expensive_computation(a, b):
    time.sleep(2)  # 👈 This makes the function take 2s to run
    return a * b

a = 2
b = 21
res = expensive_computation(a, b)

st.write("Result:", res)
```

Copy

Try pressing **R** to rerun the app, and notice how long it takes for the result to show up. This is because `expensive_computation(a, b)` is being re-executed every time the app runs. This isn't a great experience.
尝试按 R 重新运行应用，并注意显示结果需要多长时间。这是因为每次应用运行时都会重新执行 `expensive_computation(a, b)` 。这不是一个很棒的体验。

Let's add the [`@st.cache`](https://docs.streamlit.io/library/api-reference/performance/st.cache) decorator:
让我们添加 `@st.cache` 装饰器：

```python
import streamlit as st
import time

@st.cache  # 👈 Added this
def expensive_computation(a, b):
    time.sleep(2)  # This makes the function take 2s to run
    return a * b

a = 2
b = 21
res = expensive_computation(a, b)

st.write("Result:", res)
```

Copy

Now run the app again and you'll notice that it is much faster every time you press R to rerun. To understand what is happening, let's add an st.write inside the function:
现在再次运行该应用程序，您会注意到每次按 R 重新运行时它都会快得多。为了理解发生了什么，让我们在函数中添加一个 st.write：

```python
import streamlit as st
import time

@st.cache(suppress_st_warning=True)  # 👈 Changed this
def expensive_computation(a, b):
    # 👇 Added this
    st.write("Cache miss: expensive_computation(", a, ",", b, ") ran")
    time.sleep(2)  # This makes the function take 2s to run
    return a * b

a = 2
b = 21
res = expensive_computation(a, b)

st.write("Result:", res)
```

Copy

Now when you rerun the app the text "Cache miss" appears on the first run, but not on any subsequent runs. That's because the cached function is only being executed once, and every time after that you're actually hitting the cache.
现在，当您重新运行应用时，文本“缓存未命中”在第一次运行时显示，但不在任何后续运行中显示。这是因为缓存函数只执行一次，之后每次您实际上都在命中缓存。

*push_pin*

#### Note

You may have noticed that we've added the `suppress_st_warning` keyword to the `@st.cache` decorators. That's because the cached function above uses a Streamlit command itself (`st.write` in this case), and when Streamlit sees that, it shows a warning that your command will only execute when you get a cache miss. More often than not, when you see that warning it's because there's a bug in your code. However, in our case we're using the `st.write` command to demonstrate when the cache is being missed, so the behavior Streamlit is warning us about is exactly what we want. As a result, we are passing in `suppress_st_warning=True` to turn that warning off.
您可能已经注意到，我们已将 `suppress_st_warning` 关键字添加到 `@st.cache` 装饰器中。这是因为上面的缓存函数使用Streamlit命令本身（在本例中为 `st.write` ），当Streamlit看到该命令时，它会显示一条警告，指出您的命令仅在您获得缓存未命中时执行。通常情况下，当您看到该警告时，这是因为您的代码中存在错误。但是，在我们的例子中，我们使用 `st.write` 命令来演示何时丢失缓存，因此Streamlit警告我们的行为正是我们想要的。因此，我们正在传入 `suppress_st_warning=True` 以关闭该警告。



## Example 2: When the function arguments change 示例 2：当函数参数更改时

Without stopping the previous app server, let's change one of the arguments to our cached function:
在不停止上一个应用服务器的情况下，让我们将其中一个参数更改为缓存函数：

```python
import streamlit as st
import time

@st.cache(suppress_st_warning=True)
def expensive_computation(a, b):
    st.write("Cache miss: expensive_computation(", a, ",", b, ") ran")
    time.sleep(2)  # This makes the function take 2s to run
    return a * b

a = 2
b = 210  # 👈 Changed this
res = expensive_computation(a, b)

st.write("Result:", res)
```

Copy

Now the first time you rerun the app it's a cache miss. This is evidenced by the "Cache miss" text showing up and the app taking 2s to finish running. After that, if you press **R** to rerun, it's always a cache hit. That is, no such text shows up and the app is fast again.
现在，第一次重新运行应用程序时，它是缓存未命中。显示“缓存未命中”文本和应用程序需要 2 秒才能完成运行就证明了这一点。之后，如果按 R 重新运行，则始终是缓存命中。也就是说，没有显示此类文本，并且应用程序再次快速。

This is because Streamlit notices whenever the arguments **a** and **b** change and determines whether the function should be re-executed and re-cached.
这是因为每当参数 a 和 b 发生变化时，Streamlit 都会注意到，并确定是否应重新执行和重新缓存函数。



## Example 3: When the function body changes 示例 3：当函数体更改时

Without stopping and restarting your Streamlit server, let's remove the widget from our app and modify the function's code by adding a `+ 1` to the return value.
在不停止和重新启动 Streamlit 服务器的情况下，让我们从应用程序中删除小部件，并通过向返回值添加 `+ 1` 来修改函数的代码。

```python
import streamlit as st
import time

@st.cache(suppress_st_warning=True)
def expensive_computation(a, b):
    st.write("Cache miss: expensive_computation(", a, ",", b, ") ran")
    time.sleep(2)  # This makes the function take 2s to run
    return a * b + 1  # 👈 Added a +1 at the end here

a = 2
b = 210
res = expensive_computation(a, b)

st.write("Result:", res)
```

Copy

The first run is a "Cache miss", but when you press **R** each subsequent run is a cache hit. This is because on first run, Streamlit detected that the function body changed, reran the function, and put the result in the cache.
第一次运行是“缓存未命中”，但当您按 R 时，每次后续运行都是缓存命中。这是因为在首次运行时，Streamlit 检测到函数体已更改，重新运行函数，并将结果放入缓存中。

*star*

#### Tip

If you change the function back the result will already be in the Streamlit cache from a previous run. Try it out!
如果将函数更改回来，则结果将已在上次运行的 Streamlight 缓存中。试试吧！



## Example 4: When an inner function changes 示例 4：当内部函数更改时

Let's make our cached function depend on another function internally:
让我们在内部使缓存的函数依赖于另一个函数：

```python
import streamlit as st
import time

def inner_func(a, b):
    st.write("inner_func(", a, ",", b, ") ran")
    return a * b

@st.cache(suppress_st_warning=True)
def expensive_computation(a, b):
    st.write("Cache miss: expensive_computation(", a, ",", b, ") ran")
    time.sleep(2)  # This makes the function take 2s to run
    return inner_func(a, b) + 1

a = 2
b = 210
res = expensive_computation(a, b)

st.write("Result:", res)
```

Copy

What you see is the usual:
你看到的是平常：

1. The first run results in a cache miss.
   第一次运行会导致缓存未命中。
2. Every subsequent rerun results in a cache hit.
   每次后续重新运行都会导致缓存命中。

But now let's try modifying the `inner_func()`:
但是现在让我们尝试修改 `inner_func()` ：

```python
import streamlit as st
import time

def inner_func(a, b):
    st.write("inner_func(", a, ",", b, ") ran")
    return a ** b  # 👈 Changed the * to ** here

@st.cache(suppress_st_warning=True)
def expensive_computation(a, b):
    st.write("Cache miss: expensive_computation(", a, ",", b, ") ran")
    time.sleep(2)  # This makes the function take 2s to run
    return inner_func(a, b) + 1

a = 2
b = 21
res = expensive_computation(a, b)

st.write("Result:", res)
```

Copy

Even though `inner_func()` is not annotated with [`@st.cache`](https://docs.streamlit.io/library/api-reference/performance/st.cache), when we edit its body we cause a "Cache miss" in the outer `expensive_computation()`.
即使 `inner_func()` 没有用 `@st.cache` 注释，当我们编辑它的主体时，我们会导致外部 `expensive_computation()` 中的“缓存未命中”。

That's because Streamlit always traverses your code and its dependencies to verify that the cached values are still valid. This means that while developing your app you can edit your code freely without worrying about the cache. Any change you make to your app, Streamlit should do the right thing!
这是因为 Streamlit 始终遍历您的代码及其依赖项，以验证缓存的值是否仍然有效。这意味着在开发应用程序时，您可以自由编辑代码，而无需担心缓存。您对应用程序所做的任何更改，Streamlit都应该做正确的事情！

Streamlit is also smart enough to only traverse dependencies that belong to your app, and skip over any dependency that comes from an installed Python library.
Streamlit 也足够智能，可以只遍历属于你的应用的依赖项，并跳过来自已安装的 Python 库的任何依赖项。



## Example 5: Use caching to speed up your app across users

Going back to our original function, let's add a widget to control the value of `b`:
回到我们原来的函数，我们添加一个小部件来控制 `b` 的值：

```python
import streamlit as st
import time

@st.cache(suppress_st_warning=True)
def expensive_computation(a, b):
    st.write("Cache miss: expensive_computation(", a, ",", b, ") ran")
    time.sleep(2)  # This makes the function take 2s to run
    return a * b

a = 2
b = st.slider("Pick a number", 0, 10)  # 👈 Changed this
res = expensive_computation(a, b)

st.write("Result:", res)
```

Copy

What you'll see: 您将看到的内容：

- If you move the slider to a number Streamlit hasn't seen before, you'll have a cache miss again. And every subsequent rerun with the same number will be a cache hit, of course.
  如果将滑块移动到 Streamlit 以前从未见过的数字，您将再次出现缓存未命中。当然，每次以相同数字的后续重新运行都将是缓存命中。
- If you move the slider back to a number Streamlit has seen before, the cache is hit and the app is fast as expected.
  如果将滑块移回 Streamlit 之前看到的数字，则会命中缓存，并且应用程序会按预期快速运行。

In computer science terms, what is happening here is that [`@st.cache`](https://docs.streamlit.io/library/api-reference/performance/st.cache) is [memoizing](https://en.wikipedia.org/wiki/Memoization) `expensive_computation(a, b)`.
用计算机科学术语来说，这里发生的事情是 `@st.cache` 正在记忆 `expensive_computation(a, b)` 。

But now let's go one step further! Try the following:
但现在让我们更进一步！请尝试以下操作：

1. Move the slider to a number you haven't tried before, such as 9.
   将滑块移动到您以前从未尝试过的数字，例如 9。
2. Pretend you're another user by opening another browser tab pointing to your Streamlit app (usually at http://localhost:8501)
   通过打开另一个指向您的 Streamlit 应用程序的浏览器选项卡来假装您是另一个用户（通常在 http://localhost:8501 处）
3. In the new tab, move the slider to 9.
   在新选项卡中，将滑块移动到 9。

Notice how this is actually a cache hit! That is, you don't actually see the "Cache miss" text on the second tab even though that second user never moved the slider to 9 at any point prior to this.
请注意，这实际上是缓存命中！也就是说，您实际上不会在第二个选项卡上看到“缓存未命中”文本，即使第二个用户在此之前的任何时候都从未将滑块移动到 9。

This happens because the Streamlit cache is global to all users. So everyone contributes to everyone else's performance.
发生这种情况是因为 Streamlit 缓存对所有用户都是全局的。因此，每个人都为其他人的表现做出贡献。



## Example 6: Mutating cached values 示例 6：更改缓存值

As mentioned in the [overview](https://docs.streamlit.io/library/advanced-features/st.cache#optimize-performance-with-stcache) section, the Streamlit cache stores items by reference. This allows the Streamlit cache to support structures that aren't memory-managed by Python, such as TensorFlow objects. However, it can also lead to unexpected behavior — which is why Streamlit has a few checks to guide developers in the right direction. Let's look into those checks now.
如概述部分所述，Streamlit 缓存按引用存储项目。这允许 Streamlit 缓存支持不受 Python 内存管理的结构，例如 TensorFlow 对象。但是，它也可能导致意外行为 - 这就是为什么Streamlit有一些检查来指导开发人员朝着正确的方向前进。现在让我们看看这些检查。

Let's write an app that has a cached function which returns a mutable object, and then let's follow up by mutating that object:
让我们编写一个具有返回可变对象的缓存函数的应用程序，然后让我们通过更改该对象来跟进：

```python
import streamlit as st
import time

@st.cache(suppress_st_warning=True)
def expensive_computation(a, b):
    st.write("Cache miss: expensive_computation(", a, ",", b, ") ran")
    time.sleep(2)  # This makes the function take 2s to run
    return {"output": a * b}  # 👈 Mutable object

a = 2
b = 21
res = expensive_computation(a, b)

st.write("Result:", res)

res["output"] = "result was manually mutated"  # 👈 Mutated cached value

st.write("Mutated result:", res)
```

Copy

When you run this app for the first time, you should see three messages on the screen:
首次运行此应用时，应在屏幕上看到三条消息：

- Cache miss (...) 缓存未命中 （...
- Result: {output: 42} 结果：{输出：42}
- Mutated result: {output: "result was manually mutated"}
  突变结果：{输出：“结果被手动变异”}

No surprises here. But now notice what happens when you rerun you app (i.e. press **R**):
这里没有惊喜。但是现在请注意重新运行应用程序时会发生什么（即按 R）：

- Result: {output: "result was manually mutated"}
  结果：{输出：“结果被手动改变”}
- Mutated result: {output: "result was manually mutated"}
  突变结果：{输出：“结果被手动变异”}
- Cached object mutated. (...) 缓存对象已更改。(...)

So what's up? 这是怎么回事呢？

What's going on here is that Streamlit caches the output `res` by reference. When you mutated `res["output"]` outside the cached function you ended up inadvertently modifying the cache. This means every subsequent call to `expensive_computation(2, 21)` will return the wrong value!
这里发生的事情是 Streamlit 通过引用缓存输出 `res` 。当您在缓存函数之外更改 `res["output"]` 时，您最终无意中修改了缓存。这意味着每次后续调用 `expensive_computation(2, 21)` 都会返回错误的值！

Since this behavior is usually not what you'd expect, Streamlit tries to be helpful and show you a warning, along with some ideas about how to fix your code.
由于此行为通常不是您所期望的，因此 Streamlit 会尽力提供帮助并向您显示警告，以及有关如何修复代码的一些想法。

In this specific case, the fix is just to not mutate `res["output"]` outside the cached function. There was no good reason for us to do that anyway! Another solution would be to clone the result value with `res = deepcopy(expensive_computation(2, 21))`. Check out the section entitled [Fixing caching issues](https://docs.streamlit.io/knowledge-base/using-streamlit/caching-issues) for more information on these approaches and more.
在这种特定情况下，修复只是不要在缓存函数之外改变 `res["output"]` 。无论如何，我们没有充分的理由这样做！另一种解决方案是使用 `res = deepcopy(expensive_computation(2, 21))` 克隆结果值。查看标题为修复缓存问题的部分，了解有关这些方法的更多信息以及更多信息。



## Advanced caching

In [caching](https://docs.streamlit.io/library/advanced-features/caching), you learned about the Streamlit cache, which is accessed with the [`@st.cache`](https://docs.streamlit.io/library/api-reference/performance/st.cache) decorator. In this article you'll see how Streamlit's caching functionality is implemented, so that you can use it to improve the performance of your Streamlit apps.
在 缓存 中，您了解了 Streamlit 缓存，该缓存可通过 `@st.cache` 装饰器进行访问。在本文中，您将了解如何实现 Streamlit 的缓存功能，以便您可以使用它来提高 Streamlit 应用程序的性能。

The cache is a key-value store, where the key is a hash of:
缓存是一个键值存储，其中键是以下哈希：

1. The input parameters that you called the function with
   用于调用函数的输入参数
2. The value of any external variable used in the function
   函数中使用的任何外部变量的值
3. The body of the function 函数的主体
4. The body of any function used inside the cached function
   缓存函数内使用的任何函数的主体

And the value is a tuple of:
该值是以下元组：

- The cached output 缓存的输出
- A hash of the cached output (you'll see why soon)
  缓存输出的哈希值（您很快就会明白原因）

For both the key and the output hash, Streamlit uses a specialized hash function that knows how to traverse code, hash special objects, and can have its [behavior customized by the user](https://docs.streamlit.io/library/advanced-features/st.cache#the-hash_funcs-parameter).
对于键和输出哈希，Streamlit使用专门的哈希函数，该函数知道如何遍历代码，哈希特殊对象，并且可以由用户自定义其行为。

For example, when the function `expensive_computation(a, b)`, decorated with [`@st.cache`](https://docs.streamlit.io/library/api-reference/performance/st.cache), is executed with `a=2` and `b=21`, Streamlit does the following:
例如，当用 `@st.cache` 装饰的函数 `expensive_computation(a, b)` 使用 `a=2` 和 `b=21` 执行时，Streamlit 执行以下操作：

1. Computes the cache key 计算缓存键

2. If the key is found in the cache, then:
   如果在缓存中找到该密钥，则：

   - Extracts the previously-cached (output, output_hash) tuple.
     提取以前缓存的（输出、output_hash）元组。

   - Performs an 

     Output Mutation Check

     , where a fresh hash of the output is computed and compared to the stored 

     ```
     output_hash
     ```

     .

     
     执行输出突变检查，其中计算输出的新哈希值并将其与存储的 `output_hash` 进行比较。

     - If the two hashes are different, shows a **Cached Object Mutated** warning. (Note: Setting `allow_output_mutation=True` disables this step).
       如果两个哈希不同，则显示“缓存对象突变”警告。（注意：设置 `allow_output_mutation=True` 将禁用此步骤）。

3. If the input key is not found in the cache, then:
   如果在缓存中找不到输入键，则：

   - Executes the cached function (i.e. `output = expensive_computation(2, 21)`).
     执行缓存的函数（即 `output = expensive_computation(2, 21)` ).
   - Calculates the `output_hash` from the function's `output`.
     从函数的 `output` 计算 `output_hash` 。
   - Stores `key → (output, output_hash)` in the cache.
     在缓存中存储 `key → (output, output_hash)` 。

4. Returns the output. 返回输出。

If an error is encountered an exception is raised. If the error occurs while hashing either the key or the output an `UnhashableTypeError` error is thrown. If you run into any issues, see [fixing caching issues](https://docs.streamlit.io/knowledge-base/using-streamlit/caching-issues).
如果遇到错误，则会引发异常。如果在对密钥或输出进行哈希处理时发生错误，则会引发 `UnhashableTypeError` 错误。如果遇到任何问题，请参阅修复缓存问题 。



### The hash_funcs parameter hash_funcs参数

As described above, Streamlit's caching functionality relies on hashing to calculate the key for cached objects, and to detect unexpected mutations in the cached result.
如上所述，Streamlit的缓存功能依赖于哈希来计算缓存对象的键，并检测缓存结果中的意外突变。

For added expressive power, Streamlit lets you override this hashing process using the `hash_funcs` argument. Suppose you define a type called `FileReference` which points to a file in the filesystem:
为了增加表达能力，Streamlit 允许您使用 `hash_funcs` 参数覆盖此哈希过程。假设您定义了一个名为 `FileReference` 的类型，该类型指向文件系统中的文件：

```python
class FileReference:
    def __init__(self, filename):
        self.filename = filename


@st.cache
def func(file_reference):
    ...
```

Copy

By default, Streamlit hashes custom classes like `FileReference` by recursively navigating their structure. In this case, its hash is the hash of the filename property. As long as the file name doesn't change, the hash will remain constant.
默认情况下，Streamlit 通过递归导航自定义类（如 `FileReference` ）的结构来哈希这些类。在这种情况下，其哈希是文件名属性的哈希。只要文件名不更改，哈希将保持不变。

However, what if you wanted to have the hasher check for changes to the file's modification time, not just its name? This is possible with [`@st.cache`](https://docs.streamlit.io/library/api-reference/performance/st.cache)'s `hash_funcs` parameter:
但是，如果您想让哈希器检查文件的修改时间（而不仅仅是其名称）的更改，该怎么办？这可以通过 `@st.cache` 的 `hash_funcs` 参数来实现：

```python
class FileReference:
    def __init__(self, filename):
        self.filename = filename

def hash_file_reference(file_reference):
    filename = file_reference.filename
    return (filename, os.path.getmtime(filename))

@st.cache(hash_funcs={FileReference: hash_file_reference})
def func(file_reference):
    ...
```

Copy

Additionally, you can hash `FileReference` objects by the file's contents:
此外，还可以按文件内容对 `FileReference` 对象进行哈希处理：

```python
class FileReference:
    def __init__(self, filename):
        self.filename = filename

def hash_file_reference(file_reference):
    with open(file_reference.filename) as f:
      return f.read()

@st.cache(hash_funcs={FileReference: hash_file_reference})
def func(file_reference):
    ...
```

Copy

*push_pin*

#### Note

Because Streamlit's hash function works recursively, you don't have to hash the contents inside `hash_file_reference` Instead, you can return a primitive type, in this case the contents of the file, and Streamlit's internal hasher will compute the actual hash from it.
由于 Streamlit 的哈希函数以递归方式工作，因此您不必对 `hash_file_reference` 中的内容进行哈希处理 相反，您可以返回一个基元类型，在本例中是文件的内容，Streamlit 的内部哈希器将从中计算实际哈希。



### Typical hash functions 典型的哈希函数

While it's possible to write custom hash functions, let's take a look at some of the tools that Python provides out of the box. Here's a list of some hash functions and when it makes sense to use them.
虽然可以编写自定义哈希函数，但让我们来看看 Python 提供的一些开箱即用的工具。以下是一些哈希函数的列表，以及何时使用它们有意义。

Python's [`id`](https://docs.python.org/3/library/functions.html#id) function | [Example](https://docs.streamlit.io/library/advanced-features/st.cache#example-1-pass-a-database-connection-around)
Python 的 `id` 函数 | 例

- Speed: Fast
- Use case: If you're hashing a singleton object, like an open database connection or a TensorFlow session. These are objects that will only be instantiated once, no matter how many times your script reruns.
  用例：如果您正在对单例对象进行哈希处理，例如打开的数据库连接或 TensorFlow 会话。这些对象只会实例化一次，无论脚本重新运行多少次。

`lambda _: None` | [Example](https://docs.streamlit.io/library/advanced-features/st.cache#example-2-turn-off-hashing-for-a-specific-type)
`lambda _: None` | 例

- Speed: Fast
- Use case: If you want to turn off hashing of this type. This is useful if you know the object is not going to change.
  用例：如果要关闭此类型的哈希。如果您知道对象不会更改，这将非常有用。

Python's [`hash()`](https://docs.python.org/3/library/functions.html#hash) function | [Example](https://docs.streamlit.io/library/advanced-features/st.cache#example-3-use-pythons-hash-function)
Python 的 `hash()` 函数 | 例

- Speed: Can be slow based the size of the object being cached
  速度：根据要缓存的对象的大小，速度可能很慢
- Use case: If Python already knows how to hash this type correctly.
  用例：如果 Python 已经知道如何正确散列此类型。

Custom hash function | [Example](https://docs.streamlit.io/library/advanced-features/st.cache#the-hash_funcs-parameter)
自定义哈希函数 | 例

- Speed: N/a
- Use case: If you'd like to override how Streamlit hashes a particular type.
  用例：如果您想覆盖 Streamlit 对特定类型的哈希处理方式。



### Example 1: Pass a database connection around 示例 1：传递数据库连接

Suppose we want to open a database connection that can be reused across multiple runs of a Streamlit app. For this you can make use of the fact that cached objects are stored by reference to automatically initialize and reuse the connection:
假设我们要打开一个数据库连接，该连接可以在 Streamlit 应用程序的多个运行中重复使用。为此，您可以利用缓存对象通过引用存储的事实来自动初始化和重用连接：

```python
@st.cache(allow_output_mutation=True)
def get_database_connection():
    return db.get_connection()
```

Copy

With just 3 lines of code, the database connection is created once and stored in the cache. Then, every subsequent time `get_database_connection` is called, the already-created connection object is reused automatically. In other words, it becomes a singleton.
只需 3 行代码，数据库连接只需创建一次并存储在缓存中。然后，每次调用 `get_database_connection` 时，都会自动重用已创建的连接对象。换句话说，它变成了一个单例。

*star*

#### Tip

Use the `allow_output_mutation=True` flag to suppress the immutability check. This prevents Streamlit from trying to hash the output connection, and also turns off Streamlit's mutation warning in the process.
使用 `allow_output_mutation=True` 标志禁止显示不可变性检查。这可以防止 Streamlit 尝试对输出连接进行哈希处理，并且还会在此过程中关闭 Streamlit 的突变警告。

What if you want to write a function that receives a database connection as input? For that, you'll use `hash_funcs`:
如果要编写一个接收数据库连接作为输入的函数，该怎么办？为此，您将使用 `hash_funcs` ：

```python
@st.cache(hash_funcs={DBConnection: id})
def get_users(connection):
    # Note: We assume that connection is of type DBConnection.
    return connection.execute_sql('SELECT * from Users')
```

Copy

Here, we use Python's built-in `id` function, because the connection object is coming from the Streamlit cache via the `get_database_connection` function. This means that the same connection instance is passed around every time, and therefore it always has the same id. However, if you happened to have a second connection object around that pointed to an entirely different database, it would still be safe to pass it to `get_users` because its id is guaranteed to be different than the first id.
在这里，我们使用 Python 的内置 `id` 函数，因为连接对象是通过 `get_database_connection` 函数来自 Streamlit 缓存的。这意味着每次都会传递相同的连接实例，因此它始终具有相同的 id。但是，如果您碰巧周围有第二个指向完全不同的数据库的连接对象，则将其传递给 `get_users` 仍然是安全的，因为它的id保证与第一个id不同。

These design patterns apply any time you have an object that points to an external resource, such as a database connection or Tensorflow session.
只要您有指向外部资源（例如数据库连接或 Tensorflow 会话）的对象，这些设计模式就适用。



### Example 2: Turn off hashing for a specific type 示例 2：关闭特定类型的哈希

You can turn off hashing entirely for a particular type by giving it a custom hash function that returns a constant. One reason that you might do this is to avoid hashing large, slow-to-hash objects that you know are not going to change. For example:
您可以通过为特定类型提供返回常量的自定义哈希函数来完全关闭该类型的哈希。您可能这样做的一个原因是避免散列您知道不会更改的大型、散列速度慢的对象。例如：

```python
@st.cache(hash_funcs={pd.DataFrame: lambda _: None})
def func(huge_constant_dataframe):
    ...
```

Copy

When Streamlit encounters an object of this type, it always converts the object into `None`, no matter which instance of `FooType` its looking at. This means all instances are hash to the same value, which effectively cancels out the hashing mechanism.
当 Streamlit 遇到这种类型的对象时，它总是将对象转换为 `None` ，无论它查看 `FooType` 的哪个实例。这意味着所有实例都哈希为相同的值，这有效地抵消了哈希机制。



### Example 3: Use Python's hash() function 示例 3：使用 Python 的 hash（） 函数

Sometimes, you might want to use Python’s default hashing instead of Streamlit's. For example, maybe you've encountered a type that Streamlit is unable to hash, but it's hashable with Python's built-in `hash()` function:
有时，你可能想使用Python的默认哈希而不是Streamlit的哈希。例如，也许您遇到了 Streamlit 无法哈希的类型，但它可以使用 Python 的内置 `hash()` 函数进行哈希处理：

```python
@st.cache(hash_funcs={FooType: hash})
def func(...):
    ...
```





# Experimental cache primitives 实验性缓存基元



## Overview

Streamlit's unique execution model is a part of what makes it a joy to use: your code executes from top to bottom like a simple script for every interaction. There's no need to think about models, views, controllers, or anything of the sort.
Streamlit独特的执行模型是使其易于使用的一部分：您的代码从上到下执行，就像每次交互的简单脚本一样。无需考虑模型、视图、控制器或类似的东西。

Whenever your code re-executes, a decorator called [`@st.cache`](https://docs.streamlit.io/library/api-reference/performance/st.cache)—which is a powerful primitive for memoization and state storage capabilities—provides a caching mechanism that allows your app to stay performant even when loading data from the web, manipulating large datasets, or performing expensive computations.
每当重新执行代码时，名为 `@st.cache` 的装饰器（它是记忆和状态存储功能的强大基元）都会提供一种缓存机制，使应用即使在从 Web 加载数据、操作大型数据集或执行昂贵的计算时也能保持性能。

However, we've found that [`@st.cache`](https://docs.streamlit.io/library/advanced-features/caching) is hard to use and not fast. You're either faced with cryptic errors like `InternalHashError` or `UnhashableTypeError`. Or you need to understand concepts like [`hash_funcs`](https://docs.streamlit.io/library/advanced-features/caching#the-hash_funcs-parameter) and [`allow_output_mutation`](https://docs.streamlit.io/library/advanced-features/caching#example-1-pass-a-database-connection-around).
但是，我们发现 `@st.cache` 很难使用，也不快。您要么面临诸如 `InternalHashError` 或 `UnhashableTypeError` 之类的神秘错误。或者您需要了解 `hash_funcs` 和 `allow_output_mutation` 等概念。

Our solutions include two new primitives: [**`st.experimental_memo`**](https://docs.streamlit.io/library/api-reference/performance/st.experimental_memo) and [**`st.experimental_singleton`**](https://docs.streamlit.io/library/api-reference/performance/st.experimental_singleton). They're conceptually simpler and much, much faster. In some of our internal tests on caching large dataframes, `@st.experimental_memo` has outperformed `@st.cache` by an order of magnitude. That's over 10X faster! 🚀
我们的解决方案包括两个新的原语： `st.experimental_memo` 和 `st.experimental_singleton` 。它们在概念上更简单，而且速度要快得多。在我们关于缓存大型数据帧的一些内部测试中， `@st.experimental_memo` 的性能比 `@st.cache` 高出一个数量级。速度提高了 10 倍以上！🚀

Let's take a look at the use-cases these *two* experimental APIs serve, and how they're a significant improvement over `@st.cache`.
让我们来看看这两个实验性 API 服务的用例，以及它们如何比 `@st.cache` 有显著改进。



## Problem

`@st.cache` was serving the following use-cases:
`@st.cache` 正在提供以下用例：

1. Storing computation results given different kinds of inputs. In Computer Science literature, this is called [**memoization**](https://en.wikipedia.org/wiki/Memoization).
   存储给定不同类型输入的计算结果。在计算机科学文献中，这被称为记忆。
2. Initializing an object exactly once, and reusing that same instance on each rerun for the Streamlit server's lifetime. This is called the [**singleton pattern**](https://en.wikipedia.org/wiki/Singleton_pattern).
   只初始化一次对象，并在 Streamlit 服务器的生存期内每次重新运行时重用同一实例。这称为 单例模式 。
3. Storing global state to be shared and modified across multiple Streamlit sessions (and, since Streamlit is threaded, you need to pay special attention to thread-safety).
   存储要在多个 Streamlit 会话之间共享和修改的全局状态（并且，由于 Streamlit 是线程化的，因此您需要特别注意线程安全）。

As a result of `@st.cache` trying to cover too many use-cases under a single unified API, it's both slow and complex.
由于 `@st.cache` 试图在单个统一的API下涵盖太多用例，它既慢又复杂。



## Solution

While `@st.cache` tries to solve two very different problems simultaneously (caching data and sharing global singleton objects), these new primitives simplify things by dividing the problem across two different APIs. As a result, they are faster and simpler.
虽然 `@st.cache` 尝试同时解决两个非常不同的问题（缓存数据和共享全局单例对象），但这些新原语通过将问题划分到两个不同的 API 来简化事情。因此，它们更快、更简单。



### `@st.experimental_memo`

Use [`@st.experimental_memo`](https://docs.streamlit.io/library/api-reference/performance/st.experimental_memo) to store expensive computation which can be "cached" or "memoized" in the traditional sense. It has almost the exact same API as the existing `@st.cache`, so you can often blindly replace one for the other:
使用 `@st.experimental_memo` 存储昂贵的计算，这些计算可以在传统意义上“缓存”或“记忆”。它具有与现有 `@st.cache` 几乎完全相同的API，因此您通常可以盲目地将一个替换为另一个：

```python
import streamlit as st

@st.experimental_memo
def factorial(n):
    if n < 1:
        return 1
    return n * factorial(n - 1)

f10 = factorial(10)
f9 = factorial(9)  # Returns instantly!
```

Copy

#### Properties

- Unlike `@st.cache`, this returns cached items by value, not by reference. This means that you no longer have to worry about accidentally mutating the items stored in the cache. Behind the scenes, this is done by using Python's `pickle()` function to serialize/deserialize cached values.
  与 `@st.cache` 不同，它按值而不是按引用返回缓存项。这意味着您不再需要担心意外更改存储在缓存中的项目。在后台，这是通过使用 Python 的 `pickle()` 函数来序列化/反序列化缓存值来完成的。
- Although this uses a custom hashing solution for generating cache keys (like `@st.cache`), it does ***not\*** use `hash_funcs` as an escape hatch for unhashable parameters. Instead, we allow you to ignore unhashable parameters (e.g. database connections) by prefixing them with an underscore.
  尽管这使用自定义哈希解决方案来生成缓存键（如 `@st.cache` ），但它不使用 `hash_funcs` 作为不可哈希参数的转义舱口。相反，我们允许您忽略不可哈希的参数（例如数据库连接），方法是在它们前面加上下划线。

For example:

```python
import streamlit as st
import pandas as pd
from sqlalchemy.orm import sessionmaker

@st.experimental_memo
def get_page(_sessionmaker, page_size, page):
    """Retrieve rows from the RNA database, and cache them.

    Parameters
    ----------
    _sessionmaker : a SQLAlchemy session factory. Because this arg name is
                    prefixed with "_", it won't be hashed.
    page_size : the number of rows in a page of result
    page : the page number to retrieve

    Returns
    -------
    pandas.DataFrame
    A DataFrame containing the retrieved rows. Mutating it won't affect
    the cache.
    """
    with _sessionmaker() as session:
        query = (
            session
                .query(RNA.id, RNA.seq_short, RNA.seq_long, RNA.len, RNA.upi)
                .order_by(RNA.id)
                .offset(page_size * page)
                .limit(page_size)
        )

        return pd.read_sql(query.statement, query.session.bind)
```

Copy



### `@st.experimental_singleton`

[`@st.experimental_singleton`](https://docs.streamlit.io/library/api-reference/performance/st.experimental_singleton) is a key-value store that's shared across all sessions of a Streamlit app. It's great for storing heavyweight singleton objects across sessions (like TensorFlow/Torch/Keras sessions and/or database connections).
`@st.experimental_singleton` 是一个键值存储，在 Streamlit 应用的所有会话之间共享。它非常适合跨会话（如 TensorFlow/Torch/Keras 会话和/或数据库连接）存储重量级单例对象。

Example usage:

```python
import streamlit as st
from sqlalchemy.orm import sessionmaker

@st.experimental_singleton
def get_db_sessionmaker():
    # This is for illustration purposes only
    DB_URL = "your-db-url"
    engine = create_engine(DB_URL)
    return sessionmaker(engine)

dbsm = get_db_sessionmaker()
```

Copy

#### How this compares to `@st.cache`: 这与 `@st.cache` 相比如何：

- Like `@st.cache`, **this returns items by reference.**
  与 `@st.cache` 一样，这通过引用返回项目。
- You can return any object type, including objects that are not serializable.
  可以返回任何对象类型，包括不可序列化的对象。
- Unlike `@st.cache`, this decorator does not have additional logic to check whether you are unexpectedly mutating the cached object. That logic was slow and produced confusing error messages. So, instead, we're hoping that by calling this decorator "singleton," we're nudging you to the correct behavior.
  与 `@st.cache` 不同，此装饰器没有额外的逻辑来检查您是否意外更改了缓存的对象。该逻辑很慢，并产生了令人困惑的错误消息。因此，相反，我们希望通过称此装饰器为“单例”，我们是在推动您采取正确的行为。
- This does not follow the computation graph.
  这不遵循计算图。
- You don't have to worry about `hash_funcs`! Just prefix your arguments with an underscore to ignore them.
  您不必担心 `hash_funcs` ！只需在参数前面加上下划线即可忽略它们。

*priority_high*

#### Warning

Singleton objects can be used concurrently by every user connected to your app, and *you are responsible for ensuring that `@st.singleton` objects are thread-safe*. (Most objects you'd want to stick inside an `@st.singleton` annotation are probably already safe—but you should verify this.)
连接到你的应用的每个用户都可以同时使用单一实例对象，你负责确保 `@st.singleton` 对象是线程安全的。（您希望保留在 `@st.singleton` 注释中的大多数对象可能已经安全，但您应该验证这一点。



### Which to use: memo or singleton? 使用哪个：备忘录还是单例？

Decide between `@st.experimental_memo` and `@st.experimental_singleton` based on your function's *return type*. Functions that return *data* should use `memo`. Functions that return *non-data objects* should use `singleton`.
根据函数的返回类型在 `@st.experimental_memo` 和 `@st.experimental_singleton` 之间做出决定。返回数据的函数应使用 `memo` 。返回非数据对象的函数应使用 `singleton` 。

For example:

- Dataframe computation (pandas, numpy, etc): this is *data—*use `memo`
  数据帧计算（熊猫、numpy 等）：这是数据 - 使用 `memo`
- Storing downloaded data: `memo`
  存储下载的数据： `memo`
- Calculating pi to n digits: `memo`
  计算 pi 到 n 位数字： `memo`
- Tensorflow session: this is a *non-data object—*use `singleton`
  Tensorflow 会话：这是一个非数据对象 — 使用 `singleton`
- Database connection: `singleton` 数据库连接： `singleton`



### Clear memo and singleton caches procedurally 按程序清除备忘录和单一实例缓存

You can clear caches of functions decorated with `@st.experimental_memo` and `@st.experimental_singleton` *in code*. For example, you can do the following:
可以在代码中清除使用 `@st.experimental_memo` 和 `@st.experimental_singleton` 修饰的函数的缓存。例如，您可以执行以下操作：

```python
@st.experimental_memo
def square(x):
    return x**2

if st.button("Clear Square"):
    # Clear square's memoized values:
    square.clear()

if st.button("Clear All"):
    # Clear values from *all* memoized functions:
    st.experimental_memo.clear()
```

Copy

Pressing the "Clear Square" button will clear `square()`'s memoized values. Pressing the "Clear All" button will clear memoized values from all functions decorated with `@st.experimental_memo`.
按“清除方块”按钮将清除 `square()` 的记忆值。按“全部清除”按钮将从所有用 `@st.experimental_memo` 装饰的函数中清除记忆值。

In summary:

- Any function annotated with `@st.experimental_memo` or `@st.experimental_singleton` gets its own `clear()` function automatically.
  任何用 `@st.experimental_memo` 或 `@st.experimental_singleton` 注释的函数都会自动获得自己的 `clear()` 函数。
- Additionally, you can use [`st.experimental_memo.clear()`](https://docs.streamlit.io/library/api-reference/performance/st.experimental_memo.clear) and [`st.experimental_singleton.clear()`](https://docs.streamlit.io/library/api-reference/performance/st.experimental_singleton.clear) to clear *all* memo and singleton caches, respectively.
  此外，您可以使用 `st.experimental_memo.clear()` 和 `st.experimental_singleton.clear()` 分别清除所有备忘录和单例缓存。

*push_pin*

#### Note

The commands are **experimental**, so they're governed by our [experimental API process](https://docs.streamlit.io/library/advanced-features/prerelease#experimental).
这些命令是实验性的，因此它们由我们的实验性 API 进程控制。

These specialized **memoization** and **singleton** commands represent a big step in Streamlit's evolution, with the potential to *entirely replace* `@st.cache` at some point in 2022.
这些专门的记忆和单例命令代表了 Streamlit 发展中的一大步，有可能在 2022 年的某个时候完全取代 `@st.cache` 。

Yes, today you may use `@st.cache` for storing data you pulled in from a database connection (for a Tensorflow session, for caching the results of a long computation like changing the datetime values on a pandas dataframe, etc.). But these are very different things, so we made two new functions that will make it much faster! 💨
是的，今天您可以使用 `@st.cache` 来存储从数据库连接中提取的数据（对于Tensorflow会话，用于缓存长时间计算的结果，例如更改pandas数据帧上的日期时间值等）。但是这些都是非常不同的东西，所以我们做了两个新功能，这将使它更快！💨

Please help us out by testing these commands in real apps and leaving comments in [the Streamlit forums](https://discuss.streamlit.io/).
请通过在实际应用程序中测试这些命令并在 Streamlit论坛 .





# Add statefulness to apps 向应用添加有状态



## What is State? 什么是国家？

We define access to a Streamlit app in a browser tab as a **session**. For each browser tab that connects to the Streamlit server, a new session is created. Streamlit reruns your script from top to bottom every time you interact with your app. Each reruns takes place in a blank slate: no variables are shared between runs.
我们将浏览器选项卡中对 Streamlit 应用程序的访问定义为会话。对于连接到 Streamlit 服务器的每个浏览器选项卡，将创建一个新会话。每次与应用交互时，Streamlit 都会从上到下重新运行脚本。每次重新运行都发生在一张白纸上：运行之间不共享任何变量。

Session State is a way to share variables between reruns, for each user session. In addition to the ability to store and persist state, Streamlit also exposes the ability to manipulate state using Callbacks. Session state also persists across apps inside a [multipage app](https://docs.streamlit.io/library/get-started/multipage-apps).
会话状态是一种在每个用户会话的重新运行之间共享变量的方法。除了存储和持久化状态的功能外，Streamlit 还公开了使用回调操作状态的功能。会话状态也会在多页应用程序内的应用程序之间持续存在。

In this guide, we will illustrate the usage of **Session State** and **Callbacks** as we build a stateful Counter app.
在本指南中，我们将说明在构建有状态计数器应用时会话状态和回调的用法。

For details on the Session State and Callbacks API, please refer to our [Session State API Reference Guide](https://docs.streamlit.io/library/api-reference/session-state).
有关会话状态和回调 API 的详细信息，请参阅我们的会话状态 API 参考指南。

Also, check out this Session State basics tutorial video by Streamlit Developer Advocate Dr. Marisa Smith to get started:
另外，请查看 Streamlit 开发人员倡导者 Marisa Smith 博士的此会话状态基础知识教程视频以开始使用：

<iframe src="https://www.youtube-nocookie.com/embed/92jUAXBmZyU?rel=0&amp;start=undefined&amp;end=undefined" class="youtube_Iframe__9MUXM" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" data-immersive-translate-effect="1" data-immersive-translate-inline-mark="1" data-immersive-translate-mark="1" style="box-sizing: border-box; border: 0px none; display: inline-block; vertical-align: middle; aspect-ratio: 16 / 9; width: 798.4px; max-width: 100%; border-radius: 0.375rem;"></iframe>



## Build a Counter 构建计数器

Let's call our script `counter.py`. It initializes a `count` variable and has a button to increment the value stored in the `count` variable:
我们调用我们的脚本 `counter.py` 。它初始化一个 `count` 变量，并有一个按钮来递增存储在 `count` 变量中的值：

```python
import streamlit as st

st.title('Counter Example')
count = 0

increment = st.button('Increment')
if increment:
    count += 1

st.write('Count = ', count)
```

Copy

No matter how many times we press the ***Increment\*** button in the above app, the `count` remains at 1. Let's understand why:
无论我们在上面的应用程序中按多少次增量按钮， `count` 都保持在1。让我们了解一下原因：

- Each time we press the ***Increment\*** button, Streamlit reruns `counter.py` from top to bottom, and with every run, `count` gets initialized to `0` .
  每次我们按下增量按钮时，Streamlit 都会从上到下重新运行 `counter.py` ，每次运行时， `count` 都会初始化为 `0` 。
- Pressing ***Increment\*** subsequently adds 1 to 0, thus `count=1` no matter how many times we press ***Increment\***.
  按增量随后将 1 添加到 0，因此无论我们按多少次增量， `count=1` 。

As we'll see later, we can avoid this issue by storing `count` as a Session State variable. By doing so, we're indicating to Streamlit that it should maintain the value stored inside a Session State variable across app reruns.
正如我们稍后将看到的，我们可以通过将 `count` 存储为会话状态变量来避免此问题。通过这样做，我们向 Streamlit 指示它应该在应用重新运行期间维护存储在会话状态变量中的值。

Let's learn more about the API to use Session State.
让我们详细了解使用会话状态的 API。



### Initialization

The Session State API follows a field-based API, which is very similar to Python dictionaries:
会话状态 API 遵循基于字段的 API，它与 Python 字典非常相似：

```python
import streamlit as st

# Check if 'key' already exists in session_state
# If not, then initialize it
if 'key' not in st.session_state:
    st.session_state['key'] = 'value'

# Session State also supports the attribute based syntax
if 'key' not in st.session_state:
    st.session_state.key = 'value'
```

Copy



### Reads and updates 读取和更新

Read the value of an item in Session State by passing the item to `st.write` :
通过将项目传递给 `st.write` 来读取会话状态中项目的值：

```python
import streamlit as st

if 'key' not in st.session_state:
    st.session_state['key'] = 'value'

# Reads
st.write(st.session_state.key)

# Outputs: value
```

Copy

Update an item in Session State by assigning it a value:
通过为项目分配值来更新会话状态中的项目：

```python
import streamlit as st

if 'key' not in st.session_state:
    st.session_state['key'] = 'value'

# Updates
st.session_state.key = 'value2'     # Attribute API
st.session_state['key'] = 'value2'  # Dictionary like API
```

Copy

Streamlit throws an exception if an uninitialized variable is accessed:
如果访问未初始化的变量，Streamlit 会引发异常：

```python
import streamlit as st

st.write(st.session_state['value'])

# Throws an exception!
```

Copy

![state-uninitialized-exception](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510232825436-2023452353.png)

Let's now take a look at a few examples that illustrate how to add Session State to our Counter app.
现在让我们看几个示例，这些示例说明了如何将会话状态添加到我们的计数器应用程序。



### Example 1: Add Session State 示例 1：添加会话状态

Now that we've got a hang of the Session State API, let's update our Counter app to use Session State:
现在我们已经掌握了会话状态 API，让我们更新计数器应用以使用会话状态：

```python
import streamlit as st

st.title('Counter Example')
if 'count' not in st.session_state:
    st.session_state.count = 0

increment = st.button('Increment')
if increment:
    st.session_state.count += 1

st.write('Count = ', st.session_state.count)
```

Copy

As you can see in the above example, pressing the ***Increment\*** button updates the `count` each time.
如上例所示，每次按增量按钮都会更新 `count` 。



### Example 2: Session State and Callbacks 示例 2：会话状态和回调

Now that we've built a basic Counter app using Session State, let's move on to something a little more complex. The next example uses Callbacks with Session State.
现在我们已经使用会话状态构建了一个基本的计数器应用，让我们继续讨论更复杂的内容。下一个示例使用具有会话状态的回调。

**Callbacks**: A callback is a Python function which gets called when an input widget changes. Callbacks can be used with widgets using the parameters `on_change` (or `on_click`), `args`, and `kwargs`. The full Callbacks API can be found in our [Session State API Reference Guide](https://docs.streamlit.io/library/api-reference/session-state#use-callbacks-to-update-session-state).
回调：回调是一个 Python 函数，当输入小部件更改时会调用它。回调可以使用参数 `on_change` （或 `on_click` ）、 `args` 和 `kwargs` 与小部件一起使用。完整的回调 API 可以在我们的会话状态 API 参考指南中找到。

```python
import streamlit as st

st.title('Counter Example using Callbacks')
if 'count' not in st.session_state:
    st.session_state.count = 0

def increment_counter():
    st.session_state.count += 1

st.button('Increment', on_click=increment_counter)

st.write('Count = ', st.session_state.count)
```

Copy

Now, pressing the ***Increment\*** button updates the count each time by calling the `increment_counter()` function.
现在，按增量按钮每次通过调用 `increment_counter()` 函数更新计数。



### Example 3: Use args and kwargs in Callbacks 示例 3：在回调中使用参数和 kwargs

Callbacks also support passing arguments using the `args` parameter in a widget:
回调还支持在小部件中使用 `args` 参数传递参数：

```python
import streamlit as st

st.title('Counter Example using Callbacks with args')
if 'count' not in st.session_state:
    st.session_state.count = 0

increment_value = st.number_input('Enter a value', value=0, step=1)

def increment_counter(increment_value):
    st.session_state.count += increment_value

increment = st.button('Increment', on_click=increment_counter,
    args=(increment_value, ))

st.write('Count = ', st.session_state.count)
```

Copy

Additionally, we can also use the `kwargs` parameter in a widget to pass named arguments to the callback function as shown below:
此外，我们还可以在小部件中使用 `kwargs` 参数将命名参数传递给回调函数，如下所示：

```python
import streamlit as st

st.title('Counter Example using Callbacks with kwargs')
if 'count' not in st.session_state:
    st.session_state.count = 0

def increment_counter(increment_value=0):
    st.session_state.count += increment_value

def decrement_counter(decrement_value=0):
    st.session_state.count -= decrement_value

st.button('Increment', on_click=increment_counter,
    kwargs=dict(increment_value=5))

st.button('Decrement', on_click=decrement_counter,
    kwargs=dict(decrement_value=1))

st.write('Count = ', st.session_state.count)
```

Copy



### Example 4: Forms and Callbacks 示例 4：表单和回调

Say we now want to not only increment the `count`, but also store when it was last updated. We illustrate doing this using Callbacks and `st.form`:
假设我们现在不仅要增加 `count` ，还要存储上次更新的时间。我们使用回调和 `st.form` 来说明这样做：

```python
import streamlit as st
import datetime

st.title('Counter Example')
if 'count' not in st.session_state:
    st.session_state.count = 0
    st.session_state.last_updated = datetime.time(0,0)

def update_counter():
    st.session_state.count += st.session_state.increment_value
    st.session_state.last_updated = st.session_state.update_time

with st.form(key='my_form'):
    st.time_input(label='Enter the time', value=datetime.datetime.now().time(), key='update_time')
    st.number_input('Enter a value', value=0, step=1, key='increment_value')
    submit = st.form_submit_button(label='Update', on_click=update_counter)

st.write('Current Count = ', st.session_state.count)
st.write('Last Updated = ', st.session_state.last_updated)
```

Copy



## Advanced concepts



### Session State and Widget State association 会话状态和小组件状态关联

Session State provides the functionality to store variables across reruns. Widget state (i.e. the value of a widget) is also stored in a session.
会话状态提供跨重新运行存储变量的功能。小部件状态（即小部件的值）也存储在会话中。

For simplicity, we have *unified* this information in one place. i.e. the Session State. This convenience feature makes it super easy to read or write to the widget's state anywhere in the app's code. Session State variables mirror the widget value using the `key` argument.
为简单起见，我们将此信息统一在一个地方。即会话状态。这种便利的功能使得在应用程序代码中的任何位置读取或写入小部件的状态变得非常容易。会话状态变量使用 `key` 参数镜像小组件值。

We illustrate this with the following example. Let's say we have an app with a slider to represent temperature in Celsius. We can **set** and **get** the value of the temperature widget by using the Session State API, as follows:
我们用下面的例子来说明这一点。假设我们有一个带有滑块的应用程序，用于表示以摄氏度为单位的温度。我们可以通过使用会话状态 API 设置和获取温度小部件的值，如下所示：

```python
import streamlit as st

if "celsius" not in st.session_state:
    # set the initial default value of the slider widget
    st.session_state.celsius = 50.0

st.slider(
    "Temperature in Celsius",
    min_value=-100.0,
    max_value=100.0,
    key="celsius"
)

# This will get the value of the slider widget
st.write(st.session_state.celsius)
```

Copy

There is a limitation to setting widget values using the Session State API.
使用会话状态 API 设置小组件值存在限制。

*priority_high*

#### Important

Streamlit **does not allow** setting widget values via the Session State API for `st.button` and `st.file_uploader`.
Streamlit 不允许通过会话状态 API 为 `st.button` 和 `st.file_uploader` 设置小部件值。

The following example will raise a `StreamlitAPIException` on trying to set the state of `st.button` via the Session State API:
以下示例将在尝试通过会话状态 API 设置 `st.button` 的状态时引发 `StreamlitAPIException` ：

```python
import streamlit as st

if 'my_button' not in st.session_state:
    st.session_state.my_button = True
    # Streamlit will raise an Exception on trying to set the state of button

st.button('Submit', key='my_button')
```

Copy

![state-button-exception](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510232825254-2026365282.png)



### Serializable Session State 可序列化会话状态

Serialization refers to the process of converting an object or data structure into a format that can be persisted and shared, and allowing you to recover the data’s original structure. Python’s built-in [pickle](https://docs.python.org/3/library/pickle.html) module serializes Python objects to a byte stream ("pickling") and deserializes the stream into an object ("unpickling").
序列化是指将对象或数据结构转换为可持久保存和共享的格式并允许您恢复数据的原始结构的过程。Python 的内置 pickle 模块将 Python 对象序列化为字节流（“pickling”），并将流反序列化为对象（“unpickling”）。

By default, Streamlit’s [Session State](https://docs.streamlit.io/library/advanced-features/session-state) allows you to persist any Python object for the duration of the session, irrespective of the object’s pickle-serializability. This property lets you store Python primitives such as integers, floating-point numbers, complex numbers and booleans, dataframes, and even [lambdas](https://docs.python.org/3/reference/expressions.html#lambda) returned by functions. However, some execution environments may require serializing all data in Session State, so it may be useful to detect incompatibility during development, or when the execution environment will stop supporting it in the future.
默认情况下，Streamlit的会话状态允许您在会话期间保留任何Python对象，而不管该对象的可序列化性如何。此属性允许您存储 Python 基元，例如整数、浮点数、复数和布尔值、数据帧，甚至函数返回的 lambda。但是，某些执行环境可能需要序列化会话状态中的所有数据，因此在开发期间或执行环境将来何时停止支持它时检测不兼容性可能很有用。

To that end, Streamlit provides a `runner.enforceSerializableSessionState` [configuration option](https://docs.streamlit.io/library/advanced-features/configuration) that, when set to `true`, only allows pickle-serializable objects in Session State. To enable the option, either create a global or project config file with the following or use it as a command-line flag:
为此，Streamlit 提供了一个 `runner.enforceSerializableSessionState` 配置选项，当设置为 `true` 时，只允许会话状态中的可序列化对象。若要启用该选项，请使用以下内容创建全局或项目配置文件，或将其用作命令行标志：

```toml
# .streamlit/config.toml
[runner]
enforceSerializableSessionState = true
```

Copy

By "*pickle-serializable*", we mean calling `pickle.dumps(obj)` should not raise a [`PicklingError`](https://docs.python.org/3/library/pickle.html#pickle.PicklingError) exception. When the config option is enabled, adding unserializable data to session state should result in an exception. E.g.,
通过“pickle-serializable”，我们的意思是调用 `pickle.dumps(obj)` 不应该引发 `PicklingError` 异常。启用配置选项后，将不可序列化的数据添加到会话状态应会导致异常。例如，

```python
import streamlit as st

def unserializable_data():
        return lambda x: x

#👇 results in an exception when enforceSerializableSessionState is on
st.session_state.unserializable = unserializable_data()
```

Copy

![UnserializableSessionStateError](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510232825276-1758388231.png)



### Caveats and limitations 注意事项和限制

Here are some limitations to keep in mind when using Session State:
以下是使用会话状态时要记住的一些限制：

- Session State exists for as long as the tab is open and connected to the Streamlit server. As soon as you close the tab, everything stored in Session State is lost.
  只要选项卡处于打开状态并连接到 Streamlit 服务器，会话状态就存在。关闭选项卡后，存储在“会话状态”中的所有内容都将丢失。
- Session State is not persisted. If the Streamlit server crashes, then everything stored in Session State gets wiped
  会话状态不持久。如果 Streamlit 服务器崩溃，则存储在会话状态中的所有内容都会被擦除
- For caveats and limitations with the Session State API, please see the [API limitations](https://docs.streamlit.io/library/api-reference/session-state#caveats-and-limitations).
  有关会话状态 API 的注意事项和限制，请参阅 API 限制 。







# Dataframes

Dataframes are a great way to display and edit data in a tabular format. Working with Pandas DataFrames and other tabular data structures is key to data science workflows. If developers and data scientists want to display this data in Streamlit, they have multiple options: `st.dataframe` and `st.experimental_data_editor`. If you want to solely display data in a table-like UI, [st.dataframe](https://docs.streamlit.io/library/api-reference/data/st.dataframe) is the way to go. If you want to interactively edit data, use [st.experimental_data_editor](https://docs.streamlit.io/library/api-reference/widgets/st.experimental_data_editor). We explore the use cases and advantages of each option in the following sections.
数据帧是以表格格式显示和编辑数据的好方法。使用 Pandas 数据帧和其他表格数据结构是数据科学工作流的关键。如果开发人员和数据科学家想要在 Streamlit 中显示此数据，他们有多个选项： `st.dataframe` 和 `st.experimental_data_editor` 。如果您只想在类似表格的 UI 中显示数据，st.dataframe 是要走的路。如果要以交互方式编辑数据，请使用 st.experimental_data_editor 。我们将在以下部分中探讨每个选项的用例和优势。



## Display dataframes with st.dataframe 使用st.数据帧显示数据框

Streamlit can display dataframes in a table-like UI via `st.dataframe` :
Streamlit 可以通过 `st.dataframe` 在类似表格的 UI 中显示数据帧：

```python
import streamlit as st
import pandas as pd

df = pd.DataFrame(
    [
        {"command": "st.selectbox", "rating": 4, "is_widget": True},
        {"command": "st.balloons", "rating": 5, "is_widget": False},
        {"command": "st.time_input", "rating": 3, "is_widget": True},
    ]
)

st.dataframe(df, use_container_width=True)
```

Copy

<iframe loading="lazy" src="https://doc-dataframe-basic.streamlit.app/?embed=true" height="300px" class="cloud_Iframe__xSBvF" allow="camera;clipboard-read;clipboard-write;" data-immersive-translate-effect="1" data-immersive-translate-inline-mark="1" data-immersive-translate-mark="1" data-immersive-translate-paragraph-id="1144" style="box-sizing: border-box; border: 1px rgb(213 218 229/var(--tw-border-opacity)); display: inline-block; vertical-align: middle; width: 800px; max-width: 100%; border-radius: 0.375rem; --tw-border-opacity: 1;"></iframe>

[(view standalone Streamlit app)](https://doc-dataframe-basic.streamlit.app/?embed=true)
 （查看独立的流光应用程序）



## Additional UI features 其他用户界面功能

`st.dataframe` also provides some additional functionality by using [glide-data-grid](https://github.com/glideapps/glide-data-grid) under the hood:
`st.dataframe` 还通过在后台使用滑翔数据网格提供了一些额外的功能：

- **Column sorting**: sort columns by clicking on their headers.
  列排序：通过单击标题对列进行排序。
- **Column resizing**: resize columns by dragging and dropping column header borders.
  列大小调整：通过拖放列标题边框来调整列的大小。
- **Table resizing**: resize tables by dragging and dropping the bottom right corner.
  调整表格大小：通过拖放右下角来调整表格大小。
- **Search**: search through data by clicking a table, using hotkeys (`⌘ Cmd + F` or `Ctrl + F`) to bring up the search bar, and using the search bar to filter data.
  搜索：通过单击表格，使用热键（ `⌘ Cmd + F` 或 `Ctrl + F` ）调出搜索栏，使用搜索栏过滤数据来搜索数据。
- **Copy to clipboard**: select one or multiple cells, copy them to the clipboard and paste them into your favorite spreadsheet software.
  复制到剪贴板：选择一个或多个单元格，将它们复制到剪贴板并粘贴到您喜欢的电子表格软件中。

![dataframe-ui.gif](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510233136835-1502377016.gif)

Try out all the addition UI features using the embedded app from the prior section.
使用上一节中的嵌入式应用试用所有附加 UI 功能。

In addition to Pandas DataFrames, `st.dataframe` also supports other common Python types, e.g., list, dict, or numpy array. It also supports [Snowpark](https://docs.snowflake.com/en/developer-guide/snowpark/index) and [PySpark](https://spark.apache.org/docs/latest/api/python/) DataFrames, which allow you to lazily evaluate and pull data from databases. This can be useful for working with large datasets.
除了 Pandas DataFrames， `st.dataframe` 还支持其他常见的 Python 类型，例如 list、dict 或 numpy array。它还支持 Snowpark 和 PySpark DataFrames，允许您延迟评估和从数据库中提取数据。这对于处理大型数据集非常有用。



## Edit data with st.experimental_data_editor 使用st.experimental_data_editor编辑数据

Streamlit supports editable dataframes via the `st.experimental_data_editor` command. Check out its API in [st.experimental_data_editor](https://docs.streamlit.io/library/api-reference/widgets/st.experimental_data_editor). It shows the dataframe in a table, similar to `st.dataframe`. But in contrast to `st.dataframe`, this table isn't static! The user can click on cells and edit them. The edited data is then returned on the Python side. Here's an example:
Streamlit 支持通过 `st.experimental_data_editor` 命令编辑的数据帧。在 st.experimental_data_editor 中查看其 API。它在表中显示数据帧，类似于 `st.dataframe` 。但与 `st.dataframe` 相反，此表不是静态的！用户可以单击单元格并对其进行编辑。然后，编辑后的数据将在 Python 端返回。下面是一个示例：

```python
df = pd.DataFrame(
    [
        {"command": "st.selectbox", "rating": 4, "is_widget": True},
        {"command": "st.balloons", "rating": 5, "is_widget": False},
        {"command": "st.time_input", "rating": 3, "is_widget": True},
    ]
)

df = load_data()
edited_df = st.experimental_data_editor(df) # 👈 An editable dataframe

favorite_command = edited_df.loc[edited_df["rating"].idxmax()]["command"]
st.markdown(f"Your favorite command is **{favorite_command}** 🎈")
```

Copy

View interactive app 查看交互式应用*expand_more*

Try it out by double-clicking on any cell. You'll notice you can edit all cell values. Try editing the values in the rating column and observe how the text output at the bottom changes:
通过双击任何单元格来尝试一下。您会注意到您可以编辑所有单元格值。尝试编辑评级列中的值，并观察底部的文本输出如何变化：

![data-editor-editing.gif](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510233108802-1162693028.gif)

`st.experimental_data_editor` also supports a few additional things:
`st.experimental_data_editor` 还支持一些其他功能：

- [Copy and paste support](https://docs.streamlit.io/library/advanced-features/dataframes#copy-and-paste-support) from and to Excel and Google Sheets.
  从 Excel 和 Google 表格复制和粘贴支持。
- [Add and delete rows](https://docs.streamlit.io/library/advanced-features/dataframes#add-and-delete-rows). You can do this by setting `num_rows= "dynamic"` when calling `st.experimental_data_editor`. This will allow users to add and delete rows as needed.
  添加和删除行 。您可以通过在调用 `st.experimental_data_editor` 时设置 `num_rows= "dynamic"` 来执行此操作。这将允许用户根据需要添加和删除行。
- [Access edited data](https://docs.streamlit.io/library/advanced-features/dataframes#access-edited-data). 访问编辑后的数据。
- [Bulk edits](https://docs.streamlit.io/library/advanced-features/dataframes#bulk-edits) (similar to Excel, just drag a handle to edit neighboring cells).
  批量编辑（类似于 Excel，只需拖动手柄即可编辑相邻单元格）。
- [Automatic input validation](https://docs.streamlit.io/library/advanced-features/dataframes#automatic-input-validation), e.g. no way to enter letters into a number cell.
  自动输入验证，例如无法在数字单元格中输入字母。
- [Edit common data structures](https://docs.streamlit.io/library/advanced-features/dataframes#edit-common-data-structures) such as lists, dicts, NumPy ndarray, etc.
  编辑常见的数据结构，如列表、字典、NumPy ndarray 等。



### Copy and paste support 复制和粘贴支持

The data editor supports pasting in tabular data from Google Sheets, Excel, Notion, and many other similar tools. You can also copy-paste data between `st.experimental_data_editor` instances. This can be a huge time saver for users who need to work with data across multiple platforms. To try it out:
数据编辑器支持粘贴来自Google表格，Excel，Nottion和许多其他类似工具的表格数据。您还可以在 `st.experimental_data_editor` 实例之间复制粘贴数据。对于需要跨多个平台处理数据的用户来说，这可以节省大量时间。要试用一下：

1. Copy data from [this Google Sheets document](https://docs.google.com/spreadsheets/d/1Z0zd-5dF_HfqUaDDq4BWAOnsdlGCjkbTNwDZMBQ1dOY/edit?usp=sharing) to clipboard
   将此 Google 表格文档中的数据复制到剪贴板
2. Select any cell in the `name` column of the table below and paste it in (via `ctrl/cmd + v`).
   选择下表的 `name` 列中的任何单元格并将其粘贴到（通过 `ctrl/cmd + v` ）。

View interactive app 查看交互式应用*expand_more*

![data-editor-clipboard.gif](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510233127134-2117125416.gif)

*push_pin*

#### Note

Every cell of the pasted data will be evaluated individually and inserted into the cells if the data is compatible with the column type. E.g., pasting in non-numerical text data into a number column will be ignored.
如果数据与列类型兼容，则将单独评估粘贴数据的每个单元格并将其插入到单元格中。例如，将非数字文本数据粘贴到数字列中将被忽略。

Did you notice that although the initial dataframe had just five rows, pasting all those rows from the spreadsheet added additional rows to the dataframe? 👀 Let's find out how that works in the next section.
您是否注意到，尽管初始数据帧只有五行，但粘贴电子表格中的所有这些行会向数据帧添加其他行？👀 让我们在下一节中了解它是如何工作的。



### Add and delete rows 添加和删除行

With `st.experimental_data_editor`, viewers can add or delete rows via the table UI. This mode can be activated by setting the `num_rows` parameter to `"dynamic"`. E.g.
使用 `st.experimental_data_editor` ，查看者可以通过表 UI 添加或删除行。可以通过将 `num_rows` 参数设置为 `"dynamic"` 来激活此模式。例如

```python
edited_df = st.experimental_data_editor(df, num_rows=”dynamic”)
```

Copy

- To add new rows, scroll to the bottom-most row and click on the “+” sign in any cell.
  要添加新行，请滚动到最底部的行，然后单击任何单元格中的“+”号。
- To delete rows, select one or more rows and press the `delete` key on your keyboard.
  要删除行，请选择一行或多行，然后按键盘上的 `delete` 键。

View interactive app 查看交互式应用*expand_more*

![data-editor-add-delete.gif](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510233103418-1521764786.gif)



### Access edited data 访问编辑的数据

Sometimes, it is more convenient to know which cells have been changed rather than getting the entire edited dataframe back. Streamlit makes this easy through the use of [session state](https://docs.streamlit.io/library/advanced-features/session-state). If a `key` parameter is set, Streamlit will store any changes made to the dataframe in the session state.
有时，知道哪些单元格已更改比取回整个编辑的数据帧更方便。Streamlit通过使用会话状态使这变得容易。如果设置了 `key` 参数，Streamlit 将在会话状态中存储对数据帧所做的任何更改。

This snippet shows how you can access changed data using session state:
此代码段显示了如何使用会话状态访问更改的数据：

```python
st.experimental_data_editor(df, key="data_editor") # 👈 Set a key
st.write("Here's the session state:")
st.write(st.session_state["data_editor"]) # 👈 Access the edited data
```

Copy

In this code snippet, the `key` parameter is set to `"data_editor"`. Any changes made to the data in the `st.experimental_data_editor` instance will be tracked by Streamlit and stored in session state under the key `"data_editor"`.
在此代码段中， `key` 参数设置为 `"data_editor"` 。对 `st.experimental_data_editor` 实例中的数据所做的任何更改都将由 Streamlit 跟踪，并存储在会话状态中的键 `"data_editor"` 下。

After the data editor is created, the contents of the `"data_editor"` key in session state are printed to the screen using `st.write(st.session_state["data_editor"])`. This allows you to see the changes made to the original dataframe without having to return the entire dataframe from the data editor.
创建数据编辑器后，会话状态中 `"data_editor"` 键的内容将使用 `st.write(st.session_state["data_editor"])` 打印到屏幕上。这允许您查看对原始数据帧所做的更改，而无需从数据编辑器返回整个数据帧。

This can be useful when working with large dataframes and you only need to know which cells have changed, rather than the entire edited dataframe.
这在处理大型数据帧时非常有用，并且您只需要知道哪些单元格已更改，而不是整个编辑的数据帧。

View interactive app 查看交互式应用*expand_more*

Use all we've learned so far and apply them to the above embedded app. Try editing cells, adding new rows, and deleting rows.
使用我们到目前为止学到的所有内容，并将它们应用于上述嵌入式应用程序。尝试编辑单元格、添加新行和删除行。

![data-editor-session-state.gif](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510233113980-1149695952.gif)

Notice how edits to the table are reflected in session state: when you make any edits, a rerun is triggered which sends the edits to the backend via `st.experimental_data_editor`'s keyed widget state. Its widget state is a JSON object containing three properties: **edited_cells**, **added_rows**, and **deleted rows:**.
请注意对表的编辑如何反映在会话状态中：当您进行任何编辑时，将触发重新运行，通过 `st.experimental_data_editor` 的键控小部件状态将编辑发送到后端。其小部件状态是一个包含三个属性的 JSON 对象：edited_cells、added_rows 和已删除的行：。

- `edited_cells` maps a cell position to the edited value: `row:column` → `value` .
  `edited_cells` 将单元格位置映射到编辑的值： `row:column` → `value` 。
- `added_rows` is a list of newly added rows to the table. Each row is a dictionary where the keys are the column indices and the values are the corresponding cell values.
  `added_rows` 是表中新添加的行的列表。每一行都是一个字典，其中键是列索引，值是相应的单元格值。
- `deleted_rows` is a list of row indices that have been deleted from the table.
  `deleted_rows` 是已从表中删除的行索引的列表。



### Bulk edits

The data editor includes a feature that allows for bulk editing of cells. Similar to Excel, you can drag a handle across a selection of cells to edit their values in bulk. You can even apply commonly used [keyboard shortcuts](https://github.com/glideapps/glide-data-grid/blob/main/packages/core/API.md#keybindings) in spreadsheet software. This is useful when you need to make the same change across multiple cells, rather than editing each cell individually:
数据编辑器包含允许批量编辑单元格的功能。与 Excel 类似，您可以在所选单元格上拖动手柄以批量编辑其值。您甚至可以在电子表格软件中应用常用的键盘快捷键。当您需要跨多个单元格进行相同的更改而不是单独编辑每个单元格时，这很有用：

![data-editor-bulk-editing.gif](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510233110446-589639036.gif)



### Automatic input validation 自动输入验证

The data editor includes automatic input validation to help prevent errors when editing cells. For example, if you have a column that contains numerical data, the input field will automatically restrict the user to only entering numerical data. This helps to prevent errors that could occur if the user were to accidentally enter a non-numerical value.
数据编辑器包括自动输入验证，以帮助防止编辑单元格时出错。例如，如果您有一个包含数值数据的列，则输入字段将自动限制用户仅输入数值数据。这有助于防止在用户意外输入非数值时可能发生的错误。



### Edit common data structures 编辑常用数据结构

Editing doesn't just work for Pandas DataFrames! You can also edit lists, tuples, sets, dictionaries, NumPy arrays, or Snowpark & PySpark DataFrames. Most data types will be returned in their original format. But some types (e.g. Snowpark and PySpark) are converted to Pandas DataFrames. To learn about all the supported types, read the [st.experimental_data_editor](https://docs.streamlit.io/library/api-reference/widgets/st.experimental_data_editor) API.
编辑不仅适用于熊猫数据帧！您还可以编辑列表、元组、集合、字典、NumPy 数组或 Snowpark 和 PySpark DataFrames。大多数数据类型将以其原始格式返回。但是某些类型（例如Snowpark和PySpark）会转换为Pandas DataFrames。若要了解所有受支持的类型，请阅读st.experimental_data_editor API。

E.g. you can easily let the user add items to a list:
例如，您可以轻松地让用户将项目添加到列表中：

```python
edited_list = st.experimental_data_editor(["red", "green", "blue"], num_rows= "dynamic")
st.write("Here are all the colors you entered:")
st.write(edited_list)
```

Copy

Or numpy arrays: 或数字数组：

```python
import numpy as np

st.experimental_data_editor(np.array([
    ["st.text_area", "widget", 4.92],
    ["st.markdown", "element", 47.22]
]))
```

Copy

Or lists of records: 或记录列表：

```python
st.experimental_data_editor([
    {"name": "st.text_area", "type": "widget"},
    {"name": "st.markdown", "type": "element"},
])
```

Copy

Or dictionaries and many more types!
或者字典和更多类型！

```python
st.experimental_data_editor({
    "st.text_area": "widget",
    "st.markdown": "element"
})
```

Copy



## Configuring columns 配置列

You will be able configure the display and editing behavior of columns via `st.dataframe` and `st.experimental_data_editor` in to-be-announced future releases. We are developing an API to let you add images, charts, and clickable URLs in dataframe columns. Additionally, you will be able to make individual columns editable, set columns as categorical and specify which options they can take, hide the index of the dataframe, and much more.
您将能够在即将宣布的未来版本中通过 `st.dataframe` 和 `st.experimental_data_editor` 配置列的显示和编辑行为。我们正在开发一个 API，允许您在数据帧列中添加图像、图表和可点击的 URL。此外，您将能够使单个列可编辑，将列设置为分类列并指定它们可以采用的选项，隐藏数据帧的索引等等。

*priority_high*

#### Important

We will release the ability to configure columns in a future version of Streamlit. Keep at an eye out for updates on this page and the [Streamlit roadmap](https://roadmap.streamlit.app/).
我们将在未来版本的 Streamlit 中发布配置列的功能。请留意此页面上的更新和 流光路线图 .

While the ability to configure columns has yet to be released, there are techniques you can use with Pandas today to render columns as checkboxes, selectboxes, and change the type of columns.
虽然配置列的功能尚未发布，但目前您可以使用一些技术与 Pandas 一起使用，将列呈现为复选框、选择框和更改列的类型。



### Boolean columns (checkboxes) 布尔列（复选框）

To render columns as checkboxes and clickable checkboxes in `st.dataframe` and `st.experimental_data_editor`, respectively, set the type of the Pandas column as `bool`.
要将列分别呈现为 `st.dataframe` 和 `st.experimental_data_editor` 中的复选框和可单击的复选框，请将 Pandas 列的类型设置为 `bool` 。

Here’s an example of creating a Pandas DataFrame with column `A` containing boolean values. When we display it using `st.dataframe`, the boolean values are rendered as checkboxes, where `True` and `False` values are checked and unchecked, respectively.
下面是创建 Pandas 数据帧的示例，其中列 `A` 包含布尔值。当我们使用 `st.dataframe` 显示它时，布尔值呈现为复选框，其中 `True` 和 `False` 值分别被选中和取消选中。

```python
import pandas as pd

# create a dataframe with a boolean column
df = pd.DataFrame({"A": [True, False, True, False]})

# show the dataframe with checkboxes
st.dataframe(df)
```

Copy

![data-editor-dataframe-boolean.gif](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510233042854-378775091.gif)

Notice you cannot change their values from the frontend. To let users check and uncheck values, we display the dataframe with `st.experimental_data_editor` instead:
请注意，您无法从前端更改其值。为了让用户选中和取消选中值，我们改为使用 `st.experimental_data_editor` 显示数据帧：

```python
import pandas as pd

# create a dataframe with a boolean column
df = pd.DataFrame({"A": [True, False, True, False]})

# show the data editor with checkboxes
st.experimental_data_editor(df)
```

Copy

![data-editor-boolean.gif](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510233054182-744334134.gif)



### Categorical columns (selectboxes) 分类列（选择框）

To render columns as selectboxes with `st.experimental_data_editor`, set the type of the Pandas column as `category`:
要使用 `st.experimental_data_editor` 将列呈现为选择框，请将 Pandas 列的类型设置为 `category` ：

```python
import pandas as pd

df = pd.DataFrame(
    {"command": ["st.selectbox", "st.slider", "st.balloons", "st.time_input"]}
)
df["command"] = df["command"].astype("category")

edited_df = st.experimental_data_editor(df)
```

Copy

In some cases, you may want users to select categories that aren’t in the original Pandas DataFrame. Let’s say we use `df` from above. Currently, the `command` column can take on four unique values. What should we do if we want users to see additional options such as `st.button` and `st.radio`?
在某些情况下，您可能希望用户选择不在原始 Pandas 数据帧中的类别。假设我们使用上面的 `df` 。目前， `command` 列可以采用四个唯一值。如果我们希望用户看到其他选项，例如 `st.button` 和 `st.radio` ，我们应该怎么做？

To add additional categories to the selection, use [pandas.Series.cat.add_categories](https://pandas.pydata.org/docs/reference/api/pandas.Series.cat.add_categories.html):
要向选择添加其他类别，请使用熊猫。Series.cat.add_categories ：

```python
import pandas as pd

df = pd.DataFrame(
    {"command": ["st.selectbox", "st.slider", "st.balloons", "st.time_input"]}
)
df["command"] = (
    df["command"].astype("category").cat.add_categories(["st.button", "st.radio"])
)

edited_df = st.experimental_data_editor(df)
```

Copy

![data-editor-categorical.gif](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510233056552-1617152801.gif)



### Change column type 更改列类型

To change the type of a column, you can change the type of the underlying Pandas DataFrame column. E.g., say you have a column with only integers but want users to be able to add numbers with decimals. To do so, simply change the Pandas DataFrame column type to `float`, like so:
若要更改列的类型，可以更改基础 Pandas 数据帧列的类型。例如，假设您有一列只有整数，但希望用户能够用小数将数字相加。为此，只需将 Pandas 数据帧列类型更改为 `float` ，如下所示：

```python
import pandas as pd

import streamlit as st

# create a dataframe with an integer column
df = pd.DataFrame({"A": [1, 2, 3, 4]})

# unable to add float values to the column
edited_df = st.experimental_data_editor(df)

# cast the column to float
df["A"] = df["A"].astype("float")

# able to add float values to the column
edited_df = st.experimental_data_editor(df)
```

Copy

In the first data editor instance, you cannot add decimal values to any entries. But after casting column `A` to type `float`, we’re able to edit the values as floating point numbers:
在第一个数据编辑器实例中，不能向任何条目添加十进制值。但是在将列 `A` 转换为类型 `float` 后，我们可以将值编辑为浮点数：

![data-editor-change-type.gif](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510233121206-849724147.gif)



## Handling large datasets 处理大型数据集

`st.dataframe` and `st.experimental_data_editor` have been designed to theoretically handle tables with millions of rows thanks to their highly performant implementation using the glide-data-grid library and HTML canvas. However, the maximum amount of data that an app can realistically handle will depend on several other factors, including:
`st.dataframe` 和 `st.experimental_data_editor` 被设计为理论上处理具有数百万行的表，这要归功于它们使用 glide-data-grid 库和 HTML 画布的高性能实现。但是，应用实际可以处理的最大数据量将取决于其他几个因素，包括：

1. The maximum size of WebSocket messages: Streamlit's WebSocket messages are configurable via the `server.maxMessageSize` [config option](https://docs.streamlit.io/library/advanced-features/configuration#view-all-configuration-options), which limits the amount of data that can be transferred via the WebSocket connection at once.
   WebSocket消息的最大大小：Streamlit的WebSocket消息可以通过 `server.maxMessageSize` 配置选项进行配置，该选项限制了一次可以通过WebSocket连接传输的数据量。
2. The server memory: The amount of data that your app can handle will also depend on the amount of memory available on your server. If the server's memory is exceeded, the app may become slow or unresponsive.
   服务器内存：应用可以处理的数据量还取决于服务器上可用的内存量。如果超出服务器的内存，应用程序可能会变慢或无响应。
3. The user's browser memory: Since all the data needs to be transferred to the user's browser for rendering, the amount of memory available on the user's device can also affect the app's performance. If the browser's memory is exceeded, it may crash or become unresponsive.
   用户的浏览器内存：由于所有数据都需要传输到用户的浏览器进行渲染，因此用户设备上的可用内存量也会影响应用的性能。如果超出浏览器的内存，它可能会崩溃或无响应。

In addition to these factors, a slow network connection can also significantly slow down apps that handle large datasets.
除了这些因素之外，网络连接速度较慢还会显著降低处理大型数据集的应用速度。

When handling large datasets with more than 150,000 rows, Streamlit applies additional optimizations and disables column sorting. This can help to reduce the amount of data that needs to be processed at once and improve the app's performance.
在处理超过 150，000 行的大型数据集时，Streamlit 会应用其他优化并禁用列排序。这有助于减少需要一次处理的数据量并提高应用的性能。



## Limitations

While Streamlit's data editing capabilities offer a lot of functionality, there are some limitations to be aware of:
虽然 Streamlit 的数据编辑功能提供了许多功能，但需要注意一些限制：

- The editing functionalities are not yet optimized for mobile devices.
  编辑功能尚未针对移动设备进行优化。
- Editing is enabled only for a limited set of types (e.g. string, numbers, boolean). We are actively working on supporting more types soon, such as date, time, and datetime.
  仅对有限的一组类型（例如字符串、数字、布尔值）启用编辑。我们正在积极努力支持更多类型，例如日期、时间和日期时间。
- Editing of Pandas DataFrames only supports the following index types: `RangeIndex`, (string) `Index`, `Float64Index`, `Int64Index`, and `UInt64Index`.
  编辑 Pandas 数据帧仅支持以下索引类型： `RangeIndex` 、（字符串） `Index` 、 `Float64Index` 、 `Int64Index` 和 `UInt64Index` 。
- The column type is inferred from the underlying data and cannot be configured yet.
  列类型是从基础数据推断出来的，尚无法配置。
- Some actions like deleting rows or searching data can only be triggered via keyboard hotkeys.
  删除行或搜索数据等某些操作只能通过键盘热键触发。

We are working to fix the above limitations in future releases, so keep an eye out for updates.
我们正在努力在未来版本中修复上述限制，因此请留意更新。





# Advanced notes on widget behavior 有关小部件行为的高级说明

Widgets are magical and often work how you want. But they can have surprising behavior in some situations. Here is a high-level, abstract description of widget behavior, including some common edge-cases:
小部件很神奇，通常可以随心所欲地工作。但在某些情况下，他们可能会有令人惊讶的行为。以下是对小部件行为的高级抽象描述，包括一些常见的边缘情况：

1. If you call a widget function before the widget state exists, the widget state defaults to a value. This value depends on the widget and its arguments.
   如果在小组件状态存在之前调用小组件函数，则小组件状态默认为一个值。此值取决于小组件及其参数。
2. A widget function call returns the current widget state value. The return value is a simple Python type, and the exact type depends on the widget and its arguments.
   小部件函数调用返回当前小部件状态值。返回值是一个简单的 Python 类型，确切的类型取决于小部件及其参数。
3. Widget states depend on a particular session (browser connection). The actions of one user do not affect the widgets of any other user.
   小组件状态取决于特定会话（浏览器连接）。一个用户的操作不会影响任何其他用户的小部件。
4. A widget's identity depends on the arguments passed to the widget function. If those change, the call will create a new widget (with a default value, per 1).
   小部件的标识取决于传递给小部件函数的参数。如果这些更改，调用将创建一个新的小部件（默认值为每 1 个）。
5. If you don't call a widget function in a script run, we neither store the widget state nor render the widget. If you call a widget function with the same arguments later, Streamlit treats it as a new widget.
   如果不在脚本运行中调用 widget 函数，我们既不会存储 widget 状态，也不会呈现 widget。如果您稍后使用相同的参数调用小部件函数，Streamlit 会将其视为新的小部件。

4 and 5 are the most likely to be surprising and may pose a problem for some application designs. When you want to persist widget state for recreating a widget, use [Session State](https://docs.streamlit.io/library/api-reference/session-state) to work around 5.
4 和 5 最有可能令人惊讶，并且可能会给某些应用程序设计带来问题。如果要保留小组件状态以重新创建小组件，请使用会话状态来解决 5。





# 预发布功能

在 Streamlit，我们喜欢在保持稳定的同时快速行动。在我们最新的努力中，在不牺牲稳定性的情况下更快地移动，我们为大胆和无所畏惧的用户提供两种方式来尝试 Streamlit 的前沿功能：

1. [实验功能](https://docs.streamlit.io/library/advanced-features/prerelease#experimental-features)
2. [每晚发布](https://docs.streamlit.io/library/advanced-features/prerelease#nightly-releases)



## 实验功能

不太稳定的 Streamlit 功能具有一种命名约定：`st.experimental_`. 这种区别是我们附加到命令名称的前缀，以确保每个人都清楚它们的状态。

以下是您从每个命名约定中获得的简要说明：

- **st** ：这是我们的核心功能喜欢`st.write`和`st.dataframe`存在的地方。如果我们对这些做出向后不兼容的更改，它们将逐渐发生，并伴随数月的公告和警告。
- **experimental** ：这是我们将所有可能会或可能不会进入 Streamlit 核心的新功能的地方。这让您有机会在我们准备好稳定其 API 之前，尝试我们在数周或数月内准备的下一件大事。我们不知道这些功能是否有未来，但我们希望您能够访问我们正在尝试的所有内容，并与我们一起解决这些问题。

具有`experimental_`命名约定的功能是我们仍在努力或试图理解的东西。如果这些功能成功，在某个时候它们将成为 Streamlit 核心的一部分。如果不成功，这些功能将被删除，恕不另行通知。在实验阶段，功能的 API 和行为可能不稳定，并且它们可能会以不向后兼容的方式发生变化。

*优先级高*

#### 警告

实验性功能及其 API 可能随时更改或删除。



### 实验性功能的生命周期

1. 添加带有前缀的特征`experimental_`。

2. 该功能可能会随着时间的推移进行调整，可能会导致 API/行为中断。

3. 如果成功，我们将该功能提升到 Streamlit 核心并将其从

   ```
   experimental_
   ```

   ：

   - A。该功能的 API 稳定下来，并且该功能在没有前缀的情况下被*克隆*，因此它同时存在和。此时，用户在使用带有前缀的功能版本时会看到警告——但该功能仍然有效。`experimental_``st``experimental_``experimental_`
   - b. *在某些时候，删除了*`experimental_`带有 -prefixed 功能的代码，但仍然会有一个带有前缀的函数存根，它会显示带有适当指令的错误。`experimental_`
   - C。最后，稍后`experimental_`删除该版本。

4. 如果不成功，该功能将被删除，恕不另行通知，我们会在其中留下一个存根，`experimental_`显示指令错误。



## 每晚发布

除了实验性功能之外，我们还提供了另一种方式来试用 Streamlit 的最新功能：夜间发布。

在每天结束时（晚上 🌛），我们的机器人会针对最新的 Streamlit 代码运行自动化测试，如果一切正常，它会将它们作为包发布`streamlit-nightly`。这意味着每晚构建包括我们所有的最新功能、错误修复和其他增强功能，它们会在它们登陆我们的代码库的同一天进行。

**这与官方发布有何不同？**

官方 Streamlit 版本不仅要经过自动化测试，还要经过严格的手动测试，而夜间版本只有自动化测试。重要的是要记住，夜间发布中引入的新功能通常缺乏润色。在我们的官方版本中，我们始终确保所有新功能都已准备好迎接黄金时段。

**我如何使用夜间发布？**

您需要做的就是安装`streamlit-nightly`软件包：

```bash
pip uninstall streamlit
pip install streamlit-nightly --upgrade
```

复制

*优先级高*

#### 警告

你永远不应该在同一个环境中同时安装`streamlit`这两者！`streamlit-nightly`

**我为什么要使用每晚发布的版本？**

因为你等不及正式发布了，你想帮助我们早点发现错误！

**为什么我不应该使用每晚发布的版本？**

虽然我们的自动化测试覆盖率很高，但夜间代码中仍有很大可能存在一些错误。

**我可以选择要安装的夜间版本吗？**

如果您想使用特定版本，可以在我们的[发布历史记录中找到版本号](https://pypi.org/project/streamlit-nightly/#history)。`pip`像往常一样使用指定所需的版本： `pip install streamlit-nightly==x.yy.zz-123456`。

**我可以比较版本之间的变化吗？**

如果您想查看每晚发布的更改，可以使用[GitHub 上的比较工具](https://github.com/streamlit/streamlit/compare/0.57.3...0.57.4.dev20200412)。





# 使用时区

通常，使用时区可能很棘手。您的 Streamlit 应用程序用户不一定与运行您的应用程序的服务器处于同一时区。对于公共应用程序尤其如此，世界上任何人（在任何时区）都可以访问您的应用程序。因此，了解 Streamlit 如何处理时区至关重要，这样您就可以在显示`datetime`信息时避免意外行为。



## Streamlit 如何处理时区

Streamlit 始终在前端显示信息，其信息与其在后端`datetime`的相应实例相同。`datetime`即，日期或时间信息不会自动调整到用户的时区。我们区分以下两种情况：



### **`datetime`没有时区的实例（天真）**

*当您在不指定时区的情况*下提供`datetime`实例时，前端会显示没有时区信息的实例。例如（这也适用于其他小部件，如）：`datetime`[`st.dataframe`](https://docs.streamlit.io/library/api-reference/data/st.dataframe)

```python
import streamlit as st
from datetime import datetime

st.write(datetime(2020, 1, 10, 10, 30))
# Outputs: 2020-01-10 10:30:00
```

复制

上述应用程序的用户总是看到输出为`2020-01-10 10:30:00`.



### **`datetime`带时区的实例**

当您提供`datetime`实例*并指定时区*时，前端会`datetime`在同一时区显示该实例。例如（这也适用于其他小部件，如[`st.dataframe`](https://docs.streamlit.io/library/api-reference/data/st.dataframe)）：

```python
import streamlit as st
from datetime import datetime
import pytz

st.write(datetime(2020, 1, 10, 10, 30, tzinfo=pytz.timezone("EST")))
# Outputs: 2020-01-10 10:30:00-05:00
```

复制

上述应用程序的用户总是看到输出为`2020-01-10 10:30:00-05:00`.

在这两种情况下，日期和时间信息都不会自动调整到前端的用户时区。用户看到的和`datetime`后台对应的实例是一样的。目前无法将日期或时间信息自动调整为查看应用程序的用户的时区。

*图钉*

#### 笔记

的旧版本`st.dataframe`存在时区问题。我们不打算为遗留数据框推出额外的修复或增强功能。[如果您需要稳定的时区支持，请考虑通过更改配置设置](https://docs.streamlit.io/library/advanced-features/configuration#set-configuration-options)*config.dataFrameSerialization = "arrow"*来切换到箭头序列化。





# Static file serving 静态文件服务

Streamlit apps can host and serve small, static media files to support media embedding use cases that won't work with the normal [media elements](https://docs.streamlit.io/library/api-reference/media).
Streamlit 应用程序可以托管和提供小型静态媒体文件，以支持不适用于普通媒体元素的媒体嵌入用例。

To enable this feature, set `enableStaticServing = true` under `[server]` in your config file, or environment variable `STREAMLIT_SERVER_ENABLE_STATIC_SERVING=true`.
要启用此功能，请在配置文件中的 `[server]` 下设置 `enableStaticServing = true` ，或环境变量 `STREAMLIT_SERVER_ENABLE_STATIC_SERVING=true` 。

Media stored in the folder `./static/` relative to the running app file is served at path `app/static/[filename]`, such as `http://localhost:8501/app/static/cat.png`.
存储在文件夹 `./static/` 中相对于正在运行的应用程序文件的媒体以路径 `app/static/[filename]` 提供，例如 `http://localhost:8501/app/static/cat.png` 。



## Details on usage 有关使用的详细信息

- Files with the following extensions will be served normally: `".jpg", ".jpeg", ".png", ".gif"`. Any other file will be sent with header `Content-Type:text/plain` which will cause browsers to render in plain text. This is included for security - other file types that need to render should be hosted outside the app.
  具有以下扩展名的文件将正常提供： `".jpg", ".jpeg", ".png", ".gif"` 。任何其他文件都将以标题 `Content-Type:text/plain` 发送，这将导致浏览器以纯文本形式呈现。这是为了安全起见 - 需要呈现的其他文件类型应托管在应用外部。
- Streamlit also sets `X-Content-Type-Options:nosniff` for all files rendered from the static directory.
  Streamlit 还为从静态目录呈现的所有文件设置 `X-Content-Type-Options:nosniff` 。
- For apps running on Streamlit Community Cloud:
  对于在 Streamlit Community Cloud 上运行的应用：
  - Files available in the Github repo will always be served. Any files generated while the app is running, such as based on user interaction (file upload, etc), are not guaranteed to persist across user sessions.
    将始终提供 Github 存储库中可用的文件。应用运行时生成的任何文件（例如基于用户交互（文件上传等）的文件）不保证在用户会话中持续存在。
  - Apps which store and serve many files, or large files, may run into resource limits and be shut down.
    存储和提供多个文件或大文件的应用可能会遇到资源限制并被关闭。



## Example usage

- Put an image `cat.png` in the folder `./static/`
  将图像 `cat.png` 放入文件夹 `./static/`
- Add `enableStaticServing = true` under `[server]` in your `.streamlit/config.toml`
  在 `.streamlit/config.toml` 中的 `[server]` 下添加 `enableStaticServing = true`
- Any media in the `./static/` folder is served at the relative URL like `app/static/cat.png`
  `./static/` 文件夹中的任何媒体都以相对 URL 提供，如 `app/static/cat.png`

```toml
# .streamlit/config.toml

[server]
enableStaticServing = true
```

Copy

```python
# app.py
import streamlit as st

with st.echo():
    st.title("CAT")

    st.markdown("[![Click me](app/static/cat.png)](https://streamlit.io)")
```

Copy

Additional resources: 其他资源：

- https://docs.streamlit.io/library/advanced-features/configuration
- https://static-file-serving.streamlit.app/

<iframe loading="lazy" src="https://static-file-serving.streamlit.app/?embedded=true" height="1000" class="cloud_Iframe__xSBvF" allow="camera;clipboard-read;clipboard-write;" data-immersive-translate-effect="1" data-immersive-translate-inline-mark="1" data-immersive-translate-mark="1" data-immersive-translate-paragraph-id="178" style="box-sizing: border-box; border: 1px rgb(213 218 229/var(--tw-border-opacity)); display: inline-block; vertical-align: middle; width: 800px; max-width: 100%; border-radius: 0.375rem; --tw-border-opacity: 1;"></iframe>

[(view standalone Streamlit app)](https://static-file-serving.streamlit.app/?embedded=true)
 （查看独立的流光应用程序）





# HTTPS support

Many apps need to be accessed with SSL / [TLS](https://en.wikipedia.org/wiki/Transport_Layer_Security) protocol or `https://`.
许多应用程序需要使用SSL / TLS协议或 `https://` 进行访问。

We recommend performing SSL termination in a reverse proxy or load balancer for self-hosted and production use cases, not directly in the app. [Streamlit Community Cloud](https://docs.streamlit.io/streamlit-community-cloud) uses this approach, and every major cloud and app hosting platform should allow you to configure it and provide extensive documentation. You can find some of these platforms in our [Deployment tutorials](https://docs.streamlit.io/knowledge-base/tutorials/deploy).
我们建议在反向代理或负载均衡器中对自托管和生产用例执行 SSL 终止，而不是直接在应用中执行。 Streamlit社区云使用这种方法，每个主要的云和应用程序托管平台都应该允许您配置它并提供广泛的文档。您可以在我们的部署教程中找到其中一些平台。

To terminate SSL in your Streamlit app, you must configure `server.sslCertFile` and `server.sslKeyFile`. Learn how to set config options in [Configuration](https://docs.streamlit.io/library/advanced-features/configuration).
要在 Streamlit 应用中终止 SSL，您必须配置 `server.sslCertFile` 和 `server.sslKeyFile` 。了解如何在“配置”中设置配置选项。



## Details on usage 有关使用的详细信息

- The configuration value should be a local file path to a cert file and key file. These must be available at the time the app starts.
  配置值应为证书文件和密钥文件的本地文件路径。这些必须在应用启动时可用。
- Both `server.sslCertFile` and `server.sslKeyFile` must be specified. If only one is specified, your app will exit with an error.
  必须同时指定 `server.sslCertFile` 和 `server.sslKeyFile` 。如果仅指定了一个，则应用将退出并显示错误。
- This feature will not work in Community Cloud. Community Cloud already serves your app with TLS.
  此功能在社区云中不起作用。社区云已通过 TLS 为您的应用提供服务。

*priority_high*

#### Warning

In a production environment, we recommend performing SSL termination by the load balancer or the reverse proxy, not using this option. The use of this option in Streamlit has not gone through extensive security audits or performance tests.
在生产环境中，我们建议通过负载均衡器或反向代理执行 SSL 终止，而不是使用此选项。在 Streamlit 中使用此选项尚未经过广泛的安全审核或性能测试。



## Example usage

```toml
# .streamlit/config.toml

[server]
sslCertFile = '/path/to/certchain.pem'
sslKeyFile = '/path/to/private.key'
```





# Secrets management 机密管理

Storing unencrypted secrets in a git repository is a bad practice. For applications that require access to sensitive credentials, the recommended solution is to store those credentials outside the repository - such as using a credentials file not committed to the repository or passing them as environment variables.
将未加密的机密存储在 git 存储库中是一种不好的做法。对于需要访问敏感凭据的应用程序，建议的解决方案是将这些凭据存储在存储库之外 - 例如使用未提交到存储库的凭据文件或将它们作为环境变量传递。

Streamlit provides native file-based secrets management to easily store and securely access your secrets in your Streamlit app.
Streamlit 提供基于本机文件的机密管理，可在 Streamlit 应用程序中轻松存储和安全访问您的机密。

*push_pin*

#### Note

Existing secrets management tools, such as [dotenv files](https://pypi.org/project/python-dotenv/), [AWS credentials files](https://boto3.amazonaws.com/v1/documentation/api/latest/guide/credentials.html#configuring-credentials), [Google Cloud Secret Manager](https://pypi.org/project/google-cloud-secret-manager/), or [Hashicorp Vault](https://www.vaultproject.io/use-cases/secrets-management), will work fine in Streamlit. We just add native secrets management for times when it's useful.
现有的密钥管理工具，如dotenv文件，AWS凭证文件，Google Cloud Secret Manager或Hashicorp Vault，可以在Streamlit中正常工作。我们只是在有用的时候添加本机机密管理。



## How to use secrets management 如何使用机密管理



### Develop locally and set up secrets 在本地开发并设置机密

Streamlit provides two ways to set up secrets locally using [TOML](https://toml.io/en/latest) format:
Streamlit 提供了两种使用 TOML 格式在本地设置机密的方法：

1. In a **global secrets file** at `~/.streamlit/secrets.toml` for macOS/Linux or `%userprofile%/.streamlit/secrets.toml` for Windows:
   在 `~/.streamlit/secrets.toml` for macOS/Linux 或 `%userprofile%/.streamlit/secrets.toml` for Windows 的全局机密文件中：

   ```toml
   # Everything in this section will be available as an environment variable
   db_username = "Jane"
   db_password = "mypassword"
   
   # You can also add other sections if you like.
   # The contents of sections as shown below will not become environment variables,
   # but they'll be easily accessible from within Streamlit anyway as we show
   # later in this doc.
   [my_other_secrets]
   things_i_like = ["Streamlit", "Python"]
   ```

   Copy

   If you use the global secrets file, you don't have to duplicate secrets across several project-level files if multiple Streamlit apps share the same secrets.
   如果使用全局机密文件，则在多个 Streamlit 应用共享相同的机密时，不必跨多个项目级文件复制机密。

2. In a **per-project secrets file** at `$CWD/.streamlit/secrets.toml`, where `$CWD` is the folder you're running Streamlit from. If both a global secrets file and a per-project secrets file exist, *secrets in the per-project file overwrite those defined in the global file*.
   在 `$CWD/.streamlit/secrets.toml` 的每个项目的机密文件中，其中 `$CWD` 是运行 Streamlit 的文件夹。如果全局机密文件和每个项目的机密文件都存在，则每个项目文件中的机密将覆盖全局文件中定义的机密。

*priority_high*

#### Important

Add this file to your `.gitignore` so you don't commit your secrets!
将此文件添加到您的 `.gitignore` 中，这样您就不会提交您的机密！



### Use secrets in your app 在应用中使用机密

Access your secrets by querying the `st.secrets` dict, or as environment variables. For example, if you enter the secrets from the section above, the code below shows you how to access them within your Streamlit app.
通过查询 `st.secrets` 字典或作为环境变量来访问机密。例如，如果您输入上述部分中的机密，下面的代码将向您展示如何在 Streamlit 应用中访问它们。

```python
import streamlit as st

# Everything is accessible via the st.secrets dict:

st.write("DB username:", st.secrets["db_username"])
st.write("DB password:", st.secrets["db_password"])

# And the root-level secrets are also accessible as environment variables:

import os

st.write(
    "Has environment variables been set:",
    os.environ["db_username"] == st.secrets["db_username"],
)
```

Copy

*star*

#### Tip

You can access `st.secrets` via attribute notation (e.g. `st.secrets.key`), in addition to key notation (e.g. `st.secrets["key"]`) — like [st.session_state](https://docs.streamlit.io/library/api-reference/session-state).
您可以通过属性表示法访问 `st.secrets` （例如 `st.secrets.key` ），除了键表示法（例如 `st.secrets["key"]` ） — 像st.session_state .

You can even compactly use TOML sections to pass multiple secrets as a single attribute. Consider the following secrets:
您甚至可以紧凑地使用 TOML 部分将多个机密作为单个属性传递。请考虑以下机密：

```toml
[db_credentials]
username = "my_username"
password = "my_password"
```

Copy

Rather than passing each secret as attributes in a function, you can more compactly pass the section to achieve the same result. See the notional code below, which uses the secrets above:
与其将每个密钥作为函数中的属性传递，不如更紧凑地传递该部分以实现相同的结果。请参阅下面的名义代码，它使用了上面的机密：

```python
# Verbose version
my_db.connect(username=st.secrets.db_credentials.username, password=st.secrets.db_credentials.password)

# Far more compact version!
my_db.connect(**st.secrets.db_credentials)
```

Copy



### Error handling

Here are some common errors you might encounter when using secrets management.
下面是使用机密管理时可能遇到的一些常见错误。

- If a `.streamlit/secrets.toml` is created *while* the app is running, the server needs to be restarted for changes to be reflected in the app.
  如果在应用运行时创建了 `.streamlit/secrets.toml` ，则需要重新启动服务器才能在应用中反映更改。

- If you try accessing a secret, but no `secrets.toml` file exists, Streamlit will raise a `FileNotFoundError` exception:
  如果您尝试访问机密，但不存在 `secrets.toml` 文件，Streamlit 将引发 `FileNotFoundError` 异常：

  ![Secrets management FileNotFoundError](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510233434691-939106224.png)

- If you try accessing a secret that doesn't exist, Streamlit will raise a `KeyError` exception:
  如果您尝试访问不存在的机密，Streamlit 将引发 `KeyError` 异常：

  ```python
  import streamlit as st
  
  st.write(st.secrets["nonexistent_key"])
  ```

  Copy

  ![Secrets management KeyError](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510233434916-1998569102.png)



### Use secrets on Streamlit Community Cloud 在 Streamlit 社区云上使用机密

When you deploy your app to [Streamlit Community Cloud](https://streamlit.io/cloud), you can use the same secrets management workflow as you would locally. However, you'll need to also set up your secrets in the Community Cloud Secrets Management console. Learn how to do so via the Cloud-specific [Secrets management](https://docs.streamlit.io/streamlit-community-cloud/get-started/deploy-an-app/connect-to-data-sources/secrets-management) documentation.
将应用程序部署到 Streamlit 社区云 时，可以使用与本地相同的机密管理工作流。但是，您还需要在社区云机密管理控制台中设置机密。了解如何通过特定于云的机密管理文档执行此操作。