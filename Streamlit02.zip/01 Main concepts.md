[TOC]

# Main concepts

## Streamlit的运行

使用 Streamlit 很简单。首先，将一些 Streamlit 命令添加到普通的 Python 脚本中，然后使用 `streamlit run` 运行它：`streamlit run your_script.py [-- script args]`

只要您按上面所示运行脚本，本地 Streamlit 服务器就会启动，您的应用程序将在默认 Web 浏览器的新选项卡中打开。该应用程序是您的画布，您可以在其中绘制图表、文本、小部件、表格等。

另一种运行 Streamlit 的方法是将其作为 Python 模块运行。这在配置像 PyCharm 这样的 IDE 以使用 Streamlit 时非常有用：

```python
# Running
python -m streamlit run your_script.py

# is equivalent to:
streamlit run your_script.py
```



## Development flow

每次你想更新你的应用程序时，保存源文件。当您这样做时，Streamlit 会检测是否有更改并询问您是否要重新运行您的应用程序。选择屏幕右上角的“始终重新运行”，以便在您每次更改其源代码时自动更新您的应用程序。

这允许您在一个快速的交互式循环中工作：您输入一些代码，保存它，实时试用它，然后再输入一些代码，保存它，试用它，等等，直到您对结果满意为止。编码和实时查看结果之间的这种紧密循环是 Streamlit 让您的生活更轻松的方式之一。

从 Streamlit 版本 1.10.0 及更高版本开始，Streamlit 应用程序无法从 Linux 发行版的根目录运行。如果您尝试从根目录运行 Streamlit 应用程序，Streamlit 将抛出 `FileNotFoundError: [Errno 2] No such file or directory` 错误。

如果您使用的是 Streamlit 版本 1.10.0 或更高版本，您的主脚本应该位于根目录以外的目录中。



## Data flow

Streamlit 的架构允许您像编写普通 Python 脚本一样编写应用程序。为了解决这个问题，Streamlit 应用程序具有独特的数据流：任何时候必须在屏幕上更新某些内容时，Streamlit 都会从上到下重新运行整个 Python 脚本。

这可能发生在两种情况下：

- 每当您修改应用程序的源代码时。

- 每当用户与应用程序中的小部件交互时。例如，拖动滑块、在输入框中输入文本或单击按钮时。

每当通过 `on_change` （或 `on_click` ）参数将回调传递给小部件时，回调将始终在脚本的其余部分之前运行。



## Display and style data

在 Streamlit 应用程序中有几种显示数据（表、数组、数据框）的方法。下面，将向您介绍 magic 和 `st.write()` ，它们可用于编写从文本到表格的任何内容。



## Use magic

您还可以在不调用任何 Streamlit 方法的情况下写入您的应用程序。 Streamlit 支持“魔法命令”，这意味着您根本不必使用 `st.write()` ！要查看实际效果，请尝试以下代码片段：

```python
"""
# My first app
Here's our first attempt at using data to create a table:
"""

import streamlit as st
import pandas as pd
df = pd.DataFrame({
  'first column': [1, 2, 3, 4],
  'second column': [10, 20, 30, 40]
})

df
```

运行结果：

![image-20230509201756513](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509201811459-956763986.png)

每当 Streamlit 在自己的行上看到变量或文字值时，它会自动使用 `st.write()` 将其写入您的应用程序。



## Write a data frame

与魔法命令一起， `st.write()` 是 Streamlit 的“瑞士军刀”。您几乎可以将任何内容传递给 `st.write()` ：文本、数据、Matplotlib 图形、Altair 图表等。

```python
import streamlit as st
import pandas as pd

st.write("Here's our first attempt at using data to create a table:")
st.write(pd.DataFrame({
    'first column': [1, 2, 3, 4],
    'second column': [10, 20, 30, 40]
}))
```

运行结果：

![image-20230509201957622](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509201959570-922081528.png)

还有其他特定于数据的函数，如 `st.dataframe()` 和 `st.table()` ，您也可以使用它们来显示数据。

您可能会问自己，“为什么我不总是使用 `st.write()` ？”有几个原因：

1. Magic 和 `st.write()` 检查您传入的数据类型，然后决定如何在应用程序中最好地呈现它。有时您想以另一种方式绘制它。例如，您可能不想将数据框绘制为交互式表格，而是使用 `st.table(df)` 将其绘制为静态表格。
2. 第二个原因是其他方法返回一个可以使用和修改的对象，可以通过向它添加数据或替换它来进行。
3. 最后，如果您使用更具体的 Streamlit 方法，您可以传递额外的参数来自定义其行为。

例如，让我们创建一个数据框并使用 Pandas `Styler` 对象更改其格式。在此示例中，您将使用 Numpy 生成随机样本，并使用 `st.dataframe()` 方法绘制交互式表格。

```python
import streamlit as st
import numpy as np

dataframe = np.random.randn(10, 20)
st.dataframe(dataframe)
```

运行结果：

![image-20230509202239342](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509202241450-870124427.png)

让我们扩展第一个示例，使用 Pandas `Styler` 对象突出显示交互式表格中的一些元素。

```python
import streamlit as st
import numpy as np
import pandas as pd

dataframe = pd.DataFrame(
    np.random.randn(10, 20),
    columns=('col %d' % i for i in range(20)))

st.dataframe(dataframe.style.highlight_max(axis=0))
```

运行结果：

![image-20230509202418424](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509202420585-34229624.png)

Streamlit 还有一个静态表生成方法： `st.table()` 。

```python
import streamlit as st
import numpy as np
import pandas as pd

dataframe = pd.DataFrame(
    np.random.randn(10, 20),
    columns=('col %d' % i for i in range(20)))
st.table(dataframe)
```

运行结果：

![image-20230509202546934](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509202548866-1999069504.png)

可能看到这里有些同学还是不太明白 `st.dataframe` 和 `st.table` 的区别，这里做一下简答的总结：

1. 首先，`st.table`和`st.dataframe`都是用于展示表格数据的函数

2. `st.table`是用于展示简单表格数据的函数，它会自动调整表格大小和列宽度以适应屏幕大小。此外，它还支持对表格数据进行排序和搜索。`st.table`函数不需要传入DataFrame对象，可以直接传入二维的列表或元组作为参数。

3. `st.dataframe`也用于展示表格数据，但它是专门用于展示Pandas DataFrame对象的函数。相比于`st.table`，`st.dataframe`提供了更多的功能和选项，比如可以通过设置参数来控制表格的样式、列的格式、排序、筛选等。此外，`st.dataframe`还支持对数据进行交互式的操作，比如单击列名进行排序、单击单元格进行筛选等。如果你需要展示复杂的数据表格，并且需要对表格进行更多的交互式操作，那么建议使用`st.dataframe`函数。

4. 总之，`st.table`适用于简单的表格数据展示，而`st.dataframe`适用于更复杂、更具交互性的数据表格展示。



## Draw charts and maps

Streamlit 支持多种流行的数据图表库，如 Matplotlib、Altair、deck.gl 等。



## Draw a line chart

您可以使用 `st.line_chart()` 轻松地将折线图添加到您的应用程序。我们将使用 Numpy 生成随机样本，然后绘制图表。

```python
import streamlit as st
import numpy as np
import pandas as pd

chart_data = pd.DataFrame(
     np.random.randn(20, 3),
     columns=['a', 'b', 'c'])

st.line_chart(chart_data)
```

运行结果：

![image-20230509203354374](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509203356562-499425619.png)



## Draw a map

使用 `st.map()` ，您可以在地图上显示数据点。让我们使用 Numpy 生成一些示例数据并将其绘制在旧金山地图上。

```python
import streamlit as st
import numpy as np
import pandas as pd

map_data = pd.DataFrame(
    np.random.randn(1000, 2) / [50, 50] + [37.76, -122.4],
    columns=['lat', 'lon'])

st.map(map_data)
```

运行结果：

![image-20230509203511183](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509203513423-1966612066.png)



## Widgets

当您将数据或模型置于您想要探索的状态时，您可以添加 `st.slider()` 、 `st.button()` 或 `st.selectbox()` 等小部件。这真的很简单——将小部件视为变量：

```python
import streamlit as st
x = st.slider('x')  # 👈 this is a widget
st.write(x, 'squared is', x * x)
```

运行结果：

![image-20230509203659570](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509203701408-714986527.png)

第一次运行时，上面的应用程序应该输出文本“0 squared is 0”。然后，每次用户与小部件交互时，Streamlit 只需从上到下重新运行您的脚本，将小部件的当前状态分配给您在此过程中的变量。

例如，如果用户将滑块移动到位置 `10` ，Streamlit 将重新运行上面的代码并将 `x` 相应地设置为 `10` 。所以现在你应该看到文本“10 squared is 100”。

如果您选择指定一个字符串用作小部件的唯一键，也可以通过键访问小部件：

```python
import streamlit as st
st.text_input("Your name", key="name")

# You can access the value at any point with:
st.session_state.name
```

每个带有键的小部件都会自动添加到会话状态。



## Use checkboxes to show/hide data

复选框的一个用例是隐藏或显示应用程序中的特定图表或部分。 `st.checkbox()` 接受一个参数，即小部件标签。在此示例中，复选框用于切换条件语句。

```python
import streamlit as st
import numpy as np
import pandas as pd

if st.checkbox('Show dataframe'):
    chart_data = pd.DataFrame(
       np.random.randn(20, 3),
       columns=['a', 'b', 'c'])

    chart_data
```

运行结果：

![image-20230509204421024](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509204423052-72227245.png)

## Use a selectbox for options

使用 `st.selectbox` 从系列中进行选择。您可以写入所需的选项，或传递数组或数据框列。

让我们使用之前创建的 `df` 数据框。

```python
import streamlit as st
import pandas as pd

df = pd.DataFrame({
    'first column': [1, 2, 3, 4],
    'second column': [10, 20, 30, 40]
    })

option = st.selectbox(
    'Which number do you like best?',
     df['first column'])

'You selected: ', option
```

运行结果：

![image-20230509205055466](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509205057491-558522164.png)



## Layout

Streamlit 使您可以使用 `st.sidebar` 轻松地在左侧面板侧边栏中组织您的小部件。传递给 `st.sidebar` 的每个元素都固定在左侧，使用户可以专注于应用程序中的内容，同时仍然可以访问 UI 控件。

例如，如果要将选择框和滑块添加到侧边栏，请使用 `st.sidebar.slider` 和 `st.sidebar.selectbox` 而不是 `st.slider` 和 `st.selectbox` ：

```python
import streamlit as st

# Add a selectbox to the sidebar:
add_selectbox = st.sidebar.selectbox(
    'How would you like to be contacted?',
    ('Email', 'Home phone', 'Mobile phone')
)

# Add a slider to the sidebar:
add_slider = st.sidebar.slider(
    'Select a range of values',
    0.0, 100.0, (25.0, 75.0)
)
```

运行结果：

![image-20230509205635710](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509205637680-1490613945.png)



除了侧边栏之外，Streamlit 还提供了几种其他方式来控制应用程序的布局。 `st.columns` 让你并排放置小部件， `st.expander` 让你通过隐藏大内容来节省空间。

```python
import streamlit as st

left_column, right_column = st.columns(2)
# You can use a column just like st.sidebar:
left_column.button('Press me!')

# Or even better, call Streamlit functions inside a "with" block:
with right_column:
    chosen = st.radio(
        'Sorting hat',
        ("Gryffindor", "Ravenclaw", "Hufflepuff", "Slytherin"))
    st.write(f"You are in {chosen} house!")
```

运行结果：

![image-20230509210058890](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509210100730-870651155.png)

注意：`st.echo` 和 `st.spinner` 目前在侧边栏或布局选项中不受支持。



## Show progress

将长时间运行的计算添加到应用程序时，您可以使用 `st.progress()` 来实时显示状态。

首先，让我们输入时间。我们将使用 `time.sleep()` 方法来模拟长时间运行的计算：

```python
import time
```

现在，让我们创建一个进度条：

```python
import streamlit as st
import time

'Starting a long computation...'

# Add a placeholder
latest_iteration = st.empty()
bar = st.progress(0)

for i in range(100):
  # Update the progress bar with each iteration.
  latest_iteration.text(f'Iteration {i+1}')
  bar.progress(i + 1)
  time.sleep(0.1)

'...and now we\'re done!'
```

运行结果：

![image-20230509211017872](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509211019819-238008547.png)

小知识：

在 Streamlit 中，`st.empty()` 是一个特殊的函数，用于创建一个空白元素，可以在这个元素上动态地显示或更新内容。具体来说，`st.empty()` 会创建一个空白容器元素，可以在这个元素上添加文本、图片、图表或其他的 Streamlit 组件，并且可以在需要时更新这些组件的内容。

通常情况下，`st.empty()` 用于在应用程序中创建一个占位符，当需要动态地显示或更新内容时，可以通过这个占位符来添加、修改或删除组件。例如，当用户点击某个按钮时，应用程序需要动态地显示一张图片或一个图表，可以先使用`st.empty()` 创建一个空白容器元素，然后在点击按钮时通过这个元素添加或更新组件。

需要注意的是，`st.empty()` 返回的是一个 Streamlit 组件，而不是 Python 对象，因此需要通过赋值语句来保留这个组件的引用，以便在需要时进行操作。例如：

```python
# 创建一个空白元素
empty_elem = st.empty()

# 在空白元素上添加文本
empty_elem.text("Hello, World!")

# 在空白元素上显示一张图片
empty_elem.image(image_data)

# 在空白元素上显示一个图表
empty_elem.line_chart(data)
```

通过这种方式，我们可以在需要时动态地更新空白元素中的内容，从而实现更灵活、更交互式的应用程序。



## Themes

在 Streamlit 中，你可以使用 `config.toml` 文件来配置应用程序的主题、样式和其他选项。`config.toml` 文件是一个配置文件，存储了一系列的选项和设置，可以通过修改这些选项来改变 Streamlit 应用程序的行为和外观。

要配置 Streamlit 应用程序的主题，可以按照以下步骤操作：

1.创建一个名为 `config.toml` 的文件，并将其放置在应用程序的根目录下。

2.在 `config.toml` 文件中添加以下行来配置主题颜色：

```python
[theme]
primaryColor = "#2EB6D2"
backgroundColor = "#FFFFFF"
secondaryBackgroundColor = "#F0F2F6"
textColor = "#262730"
font = "sans-serif"
```

在上面的示例中，我们定义了四个主题颜色选项：`primaryColor`、`backgroundColor`、`secondaryBackgroundColor` 和 `textColor`，分别对应应用程序的主色调、背景颜色、次要背景颜色和文本颜色。我们还可以使用 `font` 选项来指定应用程序的字体。

3.保存 `config.toml` 文件，然后启动应用程序。如果你已经在运行 Streamlit 应用程序，请关闭它并重新启动，以便 Streamlit 可以加载新的 `config.toml` 文件。

当你启动应用程序后，Streamlit 将会使用 `config.toml` 文件中定义的主题选项来渲染应用程序的外观。如果你想更改主题颜色，可以编辑 `config.toml` 文件并保存，然后 Streamlit 会自动重新加载应用程序并应用新的主题颜色.



## Caching

Streamlit 缓存使您的应用程序即使在从 Web 加载数据、处理大型数据集或执行昂贵的计算时也能保持高性能。

缓存背后的基本思想是存储昂贵的函数调用的结果，并在相同的输入再次出现时返回缓存的结果，而不是在后续运行时调用该函数。

要在 Streamlit 中缓存一个函数，您需要使用两个装饰器（ `st.cache_data` 和 `st.cache_resource` ）之一来装饰它：

```PYTHON
@st.cache_data
def long_running_function(param1, param2):
    return …
```

在这个例子中，用 `@st.cache_data` 装饰 `long_running_function` 告诉 Streamlit 每当函数被调用时，它都会检查两件事：

1.输入参数的值（在本例中为 `param1` 和 `param2` ）。

2.函数内的代码。

如果这是 Streamlit 第一次看到这些参数值和函数代码，它会运行该函数并将返回值存储在缓存中。下次使用相同的参数和代码调用该函数时（例如，当用户与应用程序交互时），Streamlit 将完全跳过执行该函数并返回缓存的值。在开发过程中，缓存会随着功能代码的变化而自动更新，确保最新的变化反映在缓存中。

如前所述，有两个缓存装饰器：

`st.cache_data` 是缓存返回数据的计算的推荐方法：从 CSV 加载数据帧、转换 NumPy 数组、查询 API 或任何其他返回可序列化数据对象（str、int、float、DataFrame、数组、列表， …）。它会在每次函数调用时创建一个新的数据副本，使其免受突变和竞争条件的影响。在大多数情况下， `st.cache_data` 的行为是您想要的 - 所以如果您不确定，请从 `st.cache_data` 开始，看看它是否有效！

`st.cache_resource` 是缓存全局资源（如 ML 模型或数据库连接）的推荐方法——您不想多次加载的不可序列化对象。使用它，您可以在应用程序的所有重新运行和会话之间共享这些资源，而无需复制或复制。请注意，对缓存返回值的任何更改都会直接更改缓存中的对象（下面有更多详细信息）。

![Streamlit's two caching decorators and their use cases. Use st.cache_data for anything you'd store in a database. Use st.cache_resource for anything you can't store in a database, like a connection to a database or a machine learning model.](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509211741273-633958017.png)



## Pages

随着应用程序变得越来越大，将它们组织成多个页面变得很有用。这使得应用程序更容易作为开发人员进行管理，并且更易于作为用户进行导航。 Streamlit 提供了一种创建多页应用程序的顺畅方式。

我们设计此功能是为了让构建多页应用程序与构建单页应用程序一样简单！只需将更多页面添加到现有应用程序，如下所示：

1.在包含主脚本的文件夹中，创建一个新的 `pages` 文件夹。假设您的主脚本名为 `main_page.py` 。

2.在 `pages` 文件夹中添加新的 `.py` 文件以向您的应用程序添加更多页面。

3.像往常一样运行 `streamlit run main_page.py` 。

就是这样！ `main_page.py` 脚本现在将对应于您应用程序的主页。您会在侧边栏页面选择器中看到 `pages` 文件夹中的其他脚本。例如：

*main_page.py*

```python
import streamlit as st

st.markdown("# Main page 🎈")
st.sidebar.markdown("# Main page 🎈")
```

*pages/page_2.py*

```python
import streamlit as st

st.markdown("# Page 2 ❄️")
st.sidebar.markdown("# Page 2 ❄️")
```

*pages/page_3.py*

```python
import streamlit as st

st.markdown("# Page 3 🎉")
st.sidebar.markdown("# Page 3 🎉")
```

现在运行 `streamlit run main_page.py` 并查看闪亮的新多页应用程序！

![img](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509212005261-621265980.gif)

我们关于多页应用程序的文档教您如何向应用程序添加页面，包括如何定义页面、构造和运行多页应用程序，以及如何在页面之间导航。了解基础知识后，创建您的第一个多页应用程序！



## App model

现在您对所有各个部分有了更多的了解，让我们结束循环并回顾一下它是如何协同工作的：

1.Streamlit 应用程序是从上到下运行的 Python 脚本

2.每次用户打开指向您的应用程序的浏览器选项卡时，脚本都会重新执行

3.随着脚本的执行，Streamlit 在浏览器中实时绘制其输出

4.脚本使用 Streamlit 缓存来避免重新计算昂贵的函数，因此更新发生得非常快

5.每次用户与小部件交互时，您的脚本都会重新执行，并且该小部件的输出值会在该运行期间设置为新值。

6.Streamlit 应用程序可以包含多个页面，这些页面在 `pages` 文件夹中的单独 `.py` 文件中定义。

![The Streamlit app model](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509212127788-321539551.png)