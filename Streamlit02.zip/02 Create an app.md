[toc]



# Create your first app

1. 第一步是创建一个新的 Python 脚本。我们称它为 `uber_pickups.py` 。

2. 在您喜欢的 IDE 或文本编辑器中打开 `uber_pickups.py` ，然后添加以下行：

   ```python
   import streamlit as st
   import pandas as pd
   import numpy as np
   ```

3. 每个好的应用程序都有一个标题，所以让我们添加一个：

   ```python
   st.title('Uber pickups in NYC')
   ```

4. 现在是时候从命令行运行 Streamlit 了：

   ```python
   streamlit run uber_pickups.py
   ```

5. 与往常一样，该应用程序应自动在浏览器的新选项卡中打开。



# Fetch some data

现在您已经有了一个应用程序，接下来您需要做的是获取纽约市上车和下车的 Uber 数据集。

1. 让我们首先编写一个函数来加载数据。将此代码添加到您的脚本中：

   ```python
   DATE_COLUMN = 'date/time'
   DATA_URL = ('https://s3-us-west-2.amazonaws.com/'
            'streamlit-demo-data/uber-raw-data-sep14.csv.gz')
   
   def load_data(nrows):
       data = pd.read_csv(DATA_URL, nrows=nrows)
       lowercase = lambda x: str(x).lower()
       data.rename(lowercase, axis='columns', inplace=True)
       data[DATE_COLUMN] = pd.to_datetime(data[DATE_COLUMN])
       return data
   ```

   您会注意到 `load_data` 是一个普通的旧函数，它下载一些数据，将其放入 Pandas 数据框中，并将日期列从文本转换为日期时间。该函数接受一个参数 ( `nrows` )，该参数指定要加载到数据框中的行数。

2. 现在让我们测试函数并查看输出。在您的函数下方，添加以下行：

   ```python
   # Create a text element and let the reader know the data is loading.
   data_load_state = st.text('Loading data...')
   # Load 10,000 rows of data into the dataframe.
   data = load_data(10000)
   # Notify the reader that the data was successfully loaded.
   data_load_state.text('Loading data...done!')
   ```

   您会在应用程序的右上角看到几个按钮，询问您是否要重新运行该应用程序。选择始终重新运行，您将在每次保存时自动看到您的更改。

   事实证明，下载数据需要很长时间，并将 10,000 行加载到数据帧中。将日期列转换为日期时间也不是一件容易的事。您不希望每次更新应用程序时都重新加载数据——幸运的是 Streamlit 允许您缓存数据。



# Effortless caching

1. 尝试在 `load_data` 声明之前添加 `@st.cache_data` ：

   ```python
   @st.cache_data
   def load_data(nrows):
   ```

2. 然后保存脚本，Streamlit 将自动重新运行您的应用程序。由于这是您第一次使用 `@st.cache_data` 运行脚本，因此您不会看到任何变化。让我们稍微调整一下您的文件，以便您可以看到缓存的强大功能。

   ```python
   data_load_state.text("Done! (using st.cache_data)")
   ```

3. 现在保存。看看您添加的行是如何立即出现的？如果你退后一步，这实际上是相当惊人的。幕后发生了一些神奇的事情，只需要一行代码就可以激活它。



# How's it work?

让我们花几分钟时间讨论一下 `@st.cache_data` 的实际工作原理。

当你用 Streamlit 的缓存注释标记一个函数时，它会告诉 Streamlit 每当调用该函数时它应该检查两件事：

1. 您用于函数调用的输入参数。
2. 函数内的代码。

如果这是 Streamlit 第一次看到这两个项目，具有这些确切的值，并且在这个确切的组合中，它会运行该函数并将结果存储在本地缓存中。下次调用该函数时，如果这两个值没有改变，则 Streamlit 知道它可以完全跳过执行该函数。相反，它从本地缓存读取输出并将其传递给调用者——就像变魔术一样。

"但是，等一下，"你对自己说，"这听起来好得不象是真的。所有这些神奇的东西有什么限制？"

1. Streamlit 只会检查当前工作目录中的更改。如果升级 Python 库，Streamlit 的缓存只会在该库安装在您的工作目录中时注意到这一点。
2. 如果您的函数不是确定性的（也就是说，它的输出取决于随机数），或者如果它从外部时变源（例如，实时股票市场行情服务）提取数据，则缓存值将不是-更聪明。
3. 最后，您应该避免改变使用 `st.cache_data` 缓存的函数的输出，因为缓存值是通过引用存储的。

现在您已经知道 Streamlit 的缓存是如何工作的，让我们回到 Uber 上车数据。



# Inspect the raw data

在开始使用原始数据之前，最好先查看一下您正在使用的原始数据。让我们向应用程序添加一个子标题和原始数据的打印输出：

```python
st.subheader('Raw data')
st.write(data)
```

在主要概念指南中，您了解到 `st.write` 将呈现您传递给它的几乎所有内容。在这种情况下，您传入一个数据框并将其呈现为交互式表格。

`st.write` 尝试根据输入的数据类型做正确的事情。如果它没有按照您的预期运行，您可以改用 `st.dataframe` 之类的专用命令。



# Draw a histogram

*histogram：直方图*

现在您已经有机会查看数据集并观察可用的内容，让我们更进一步，绘制直方图以查看优步在纽约市的最繁忙时间。

1. 首先，让我们在原始数据部分下方添加一个子标题：

   ```python
   st.subheader('Number of pickups by hour')
   ```

2. 使用 NumPy 生成一个直方图，该直方图按小时划分取件时间：

   ```python
   hist_values = np.histogram(
       data[DATE_COLUMN].dt.hour, bins=24, range=(0,24))[0]
   ```

3. 现在，让我们使用 Streamlit 的 `st.bar_chart()` 方法来绘制这个直方图。

   ```python
   st.bar_chart(hist_values)
   ```

4. 保存你的脚本。此直方图应立即显示在您的应用程序中。快速回顾了一下，最繁忙的时间似乎是 17:00（下午 5 点）。

   为了绘制此图表，我们使用了 Streamlit 的原生 `bar_chart()` 方法，但重要的是要知道 Streamlit 支持更复杂的图表库，如 Altair、Bokeh、Plotly、Matplotlib 等。



# Plot data on a map

将直方图与 Uber 的数据集一起使用可以帮助我们确定什么时候最繁忙的接送时间，但是如果我们想弄清楚整个城市的接送集中在哪里呢。虽然您可以使用条形图来显示此数据，但除非您非常熟悉城市中的纬度和经度坐标，否则它并不容易解释。为了显示拾取集中度，让我们使用 Streamlit `st.map()` 函数将数据叠加在纽约市地图上。

1. 为该部分添加一个子标题：

   ```python
   st.subheader('Map of all pickups')
   ```

2. 使用 `st.map()` 函数绘制数据：

   ```python
   st.map(data)
   ```

3. 保存你的脚本。该地图是完全互动的。通过平移或放大一点来尝试一下。

绘制直方图后，您确定 Uber 上车最繁忙的时间是 17:00。让我们重新绘制地图以显示 17:00 的上车集中度。

1. 找到以下代码片段：

   ```python
   st.subheader('Map of all pickups')
   st.map(data)
   ```

2.  将其替换为：

   ```python
   hour_to_filter = 17
   filtered_data = data[data[DATE_COLUMN].dt.hour == hour_to_filter]
   st.subheader(f'Map of all pickups at {hour_to_filter}:00')
   st.map(filtered_data)
   ```

3. 您应该立即看到数据更新。

为了绘制这张地图，我们使用了 Streamlit 中内置的 `st.map` 函数，但如果您想可视化复杂的地图数据，我们鼓励您查看 `st.pydeck_chart` 。



# Filter results with a slider

在上一节中，当您绘制地图时，用于筛选结果的时间被硬编码到脚本中，但是如果我们想让读者实时动态筛选数据怎么办？您可以使用 Streamlit 的小部件。让我们使用 `st.slider()` 方法向应用程序添加一个滑块。

1. 找到 `hour_to_filter` 并将其替换为以下代码片段：

   ```python
   hour_to_filter = st.slider('hour', 0, 23, 17)  # min: 0h, max: 23h, default: 17h
   ```

2. 使用滑块并实时观看地图更新。



# Use a button to toggle data

滑块只是动态更改应用程序组成的一种方式。让我们使用 `st.checkbox` 函数向您的应用程序添加一个复选框。我们将使用此复选框来显示/隐藏应用程序顶部的原始数据表。

1. 找到这些行：

   ```python
   st.subheader('Raw data')
   st.write(data)
   ```

2. 用以下代码替换这些行：

   ```python
   if st.checkbox('Show raw data'):
       st.subheader('Raw data')
       st.write(data)
   ```

   

# Let's put it all together

```python
import streamlit as st
import pandas as pd
import numpy as np

st.title('Uber pickups in NYC')

DATE_COLUMN = 'date/time'
DATA_URL = ('https://s3-us-west-2.amazonaws.com/'
            'streamlit-demo-data/uber-raw-data-sep14.csv.gz')

@st.cache_data
def load_data(nrows):
    data = pd.read_csv(DATA_URL, nrows=nrows)
    lowercase = lambda x: str(x).lower()
    data.rename(lowercase, axis='columns', inplace=True)
    data[DATE_COLUMN] = pd.to_datetime(data[DATE_COLUMN])
    return data

data_load_state = st.text('Loading data...')
data = load_data(10000)
data_load_state.text("Done! (using st.cache_data)")

if st.checkbox('Show raw data'):
    st.subheader('Raw data')
    st.write(data)

st.subheader('Number of pickups by hour')
hist_values = np.histogram(data[DATE_COLUMN].dt.hour, bins=24, range=(0,24))[0]
st.bar_chart(hist_values)

# Some number in the range 0-23
hour_to_filter = st.slider('hour', 0, 23, 17)
filtered_data = data[data[DATE_COLUMN].dt.hour == hour_to_filter]

st.subheader('Map of all pickups at %s:00' % hour_to_filter)
st.map(filtered_data)
```



# Share your app

构建 Streamlit 应用程序后，就可以分享它了！为了向全世界展示它，您可以使用 Streamlit Community Cloud 免费部署、管理和共享您的应用程序。

它通过 3 个简单的步骤工作：

1. 将您的应用程序放在公共 GitHub 存储库中（并确保它有一个 requirements.txt！）
2. 登录 share.streamlit.io
3. 单击“部署应用程序”，然后粘贴您的 GitHub URL

就是这样！ 🎈 您现在拥有一个可以与全世界共享的公开部署的应用程序。单击以了解有关如何使用 Streamlit Community Cloud 的更多信息。



# Get help

这就是入门，现在您可以开始构建自己的应用程序了！如果您遇到困难，您可以采取以下措施。

- Check out our [community forum](https://discuss.streamlit.io/) and post a question

- Quick help from command line with `streamlit help`

- Go through our [Knowledge Base](https://docs.streamlit.io/knowledge-base) for tips, step-by-step tutorials, and articles that answer your questions about creating and deploying Streamlit apps.

  