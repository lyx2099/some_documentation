[TOC]



# st.write and magic **commands** st.write

Streamlit 有两种简单的方法可以将信息显示到您的应用程序中，这通常应该是您尝试的第一件事： `st.write` 和 magic。



## st.write

将参数写入应用程序。

这是 Streamlit 命令的瑞士军刀：它会根据你扔给它的东西做不同的事情。与其他 Streamlit 命令不同，write() 具有一些独特的属性：

1. 你可以传入多个参数，所有参数都会被写入。
2. 它的行为取决于输入类型，如下所示。
3. 它返回 None，因此它在 App 中的“插槽”不能被重用。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/write.py#L48) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.write(*args, unsafe_allow_html=False, **kwargs)           |                                                              |
| Parameters                                                   |                                                              |
| ***args** *(any)*                                            | One or many objects to print to the App. 要打印到应用程序的一个或多个对象。Arguments are handled as follows: 参数处理如下：write(string) : Prints the formatted Markdown string, with write(string) : 打印格式化的 Markdown 字符串，support for LaTeX expression, emoji shortcodes, and colored text. See docs for st.markdown for more. 支持 LaTeX 表达式、表情符号简码和彩色文本。有关更多信息，请参阅 st.markdown 的文档。write(data_frame) : Displays the DataFrame as a table. write(data_frame) ：将 DataFrame 显示为表格。write(error) : Prints an exception specially. write(error) ：专门打印一个异常。write(func) : Displays information about a function. write(func) ：显示有关函数的信息。write(module) : Displays information about the module. write(module) ：显示有关模块的信息。write(class) : Displays information about a class. write(class) ：显示有关类的信息。write(dict) : Displays dict in an interactive widget. write(dict) ：在交互式小部件中显示字典。write(mpl_fig) : Displays a Matplotlib figure. write(mpl_fig) ：显示 Matplotlib 图。write(altair) : Displays an Altair chart. write(altair) ：显示 Altair 图表。write(keras) : Displays a Keras model. write(keras) ：显示 Keras 模型。write(graphviz) : Displays a Graphviz graph. write(graphviz) ：显示 Graphviz 图。write(plotly_fig) : Displays a Plotly figure. write(plotly_fig) ：显示 Plotly 图。write(bokeh_fig) : Displays a Bokeh figure. write(bokeh_fig) ：显示散景图。write(sympy_expr) : Prints SymPy expression using LaTeX. write(sympy_expr) ：使用 LaTeX 打印 SymPy 表达式。write(htmlable) : Prints _repr_html_() for the object if available. write(htmlable) ：如果可用，为对象打印 _repr_html_() 。write(obj) : Prints str(obj) if otherwise unknown. write(obj) ：如果未知则打印 str(obj) 。 |
| **unsafe_allow_html** *(bool)* unsafe_allow_html（布尔）     | This is a keyword-only argument that defaults to False. 这是默认为 False 的仅限关键字的参数。By default, any HTML tags found in strings will be escaped and therefore treated as pure text. This behavior may be turned off by setting this argument to True. 默认情况下，在字符串中找到的任何 HTML 标记都将被转义，因此被视为纯文本。可以通过将此参数设置为 True 来关闭此行为。That said, *we strongly advise against it*. It is hard to write secure HTML, so by using this argument you may be compromising your users' security. For more information, see: 也就是说，我们强烈建议不要这样做。很难编写安全的 HTML，因此使用此参数可能会危及用户的安全。有关详细信息，请参阅：https://github.com/streamlit/streamlit/issues/152 |

**Example**

它的基本用例是绘制 Markdown 格式的文本，只要输入是字符串：

```python
import streamlit as st

st.write('Hello, *World!* :sunglasses:')
```

![image-20230509225232785](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509225233801-1125047631.png)



如前所述， `st.write()` 还接受其他数据格式，例如数字、数据框、样式化数据框和分类对象：

```python
import streamlit as st
import pandas as pd

st.write(1234)
st.write(pd.DataFrame({
    'first column': [1, 2, 3, 4],
    'second column': [10, 20, 30, 40],
}))
```

![image-20230509225245764](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509225246355-2027130673.png)

最后，您可以传入多个参数来执行以下操作：

```python
import streamlit as st

st.write('1 + 1 = ', 2)
st.write('Below is a DataFrame:', data_frame, 'Above is a dataframe.')
```

![image-20230509225316031](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509225316727-160438985.png)



哦，还有一件事： `st.write` 也接受图表对象！例如：

```python
import streamlit as st
import pandas as pd
import numpy as np
import altair as alt

df = pd.DataFrame(
    np.random.randn(200, 3),
    columns=['a', 'b', 'c'])

c = alt.Chart(df).mark_circle().encode(
    x='a', y='b', size='c', color='c', tooltip=['a', 'b', 'c'])

st.write(c)
```

![image-20230509225346557](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509225347236-1308110613.png)



## Magic

魔术命令是 Streamlit 中的一项功能，它允许您编写几乎所有内容（markdown、数据、图表），而无需键入显式命令。只需将您想要显示的内容放在自己的代码行中，它就会出现在您的应用程序中。这是一个例子：

```python
# Draw a title and some text to the app:
'''
# This is the document title

This is some _markdown_.
'''

import pandas as pd
df = pd.DataFrame({'col1': [1,2,3]})
df  # 👈 Draw the dataframe

x = 10
'x', x  # 👈 Draw the string 'x' and then the value of x

# Also works with most supported chart types
import matplotlib.pyplot as plt
import numpy as np

arr = np.random.normal(1, 1, size=100)
fig, ax = plt.subplots()
ax.hist(arr, bins=20)

fig  # 👈 Draw a Matplotlib chart
```



### How Magic works

每当 Streamlit 在其自己的行上看到变量或文字值时，它会使用 `st.write` 自动将其写入您的应用程序（稍后您将了解）。

此外，魔法足够聪明，可以忽略文档字符串。也就是说，它会忽略文件和函数顶部的字符串。

如果您更喜欢更明确地调用 Streamlit 命令，您始终可以使用以下设置在 `~/.streamlit/config.toml` 中关闭魔法：

```python
[runner]
magicEnabled = false
```



# Text elements

Streamlit 应用程序通常以调用 `st.title` 开始，以设置应用程序的标题。之后，您可以使用 2 个标题级别： `st.header` 和 `st.subheader` 。

纯文本用 `st.text` 输入，Markdown 用 `st.markdown` 输入。

我们还提供了一个名为 `st.write` 的“瑞士军刀”命令，它接受多个参数和多种数据类型。并且如上所述，您还可以使用魔术命令代替 `st.write` 。



## st.markdown

显示格式为 Markdown 的字符串。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/markdown.py#L31) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.markdown(body, unsafe_allow_html=False, *, help=None) st.markdown（正文，unsafe_allow_html=False，*，help=None） |                                                              |
| Parameters                                                   |                                                              |
| **body** *(str)*                                             | The string to display as Github-flavored Markdown. Syntax information can be found at: https://github.github.com/gfm. 要显示为 Github 风格的 Markdown 的字符串。可以在以下位置找到语法信息： https://github.github.com/gfm 。This also supports: 这也支持：Emoji shortcodes, such as `:+1:` and `:sunglasses:`. For a list of all supported codes, see https://share.streamlit.io/streamlit/emoji-shortcodes. 表情符号短代码，例如 `:+1:` 和 `:sunglasses:` 。有关所有受支持代码的列表，请参阅 https://share.streamlit.io/streamlit/emoji-shortcodes 。LaTeX expressions, by wrapping them in "$" or "$$" (the "$$" must be on their own lines). Supported LaTeX functions are listed at https://katex.org/docs/supported.html. LaTeX 表达式，将它们包裹在“$”或“$$”中（“$$”必须在它们自己的行中）。支持的 LaTeX 函数列在 https://katex.org/docs/supported.html 中。Colored text, using the syntax `:color[text to be colored]`, where `color` needs to be replaced with any of the following supported colors: blue, green, orange, red, violet. 彩色文本，使用语法 `:color[text to be colored]` ，其中 `color` 需要替换为以下任何受支持的颜色：蓝色、绿色、橙色、红色、紫色。 |
| **unsafe_allow_html** *(bool)*                               | By default, any HTML tags found in the body will be escaped and therefore treated as pure text. This behavior may be turned off by setting this argument to True. 默认情况下，在正文中找到的任何 HTML 标记都将被转义，因此被视为纯文本。可以通过将此参数设置为 True 来关闭此行为。That said, we *strongly advise against it*. It is hard to write secure HTML, so by using this argument you may be compromising your users' security. For more information, see: 也就是说，我们强烈建议不要这样做。很难编写安全的 HTML，因此使用此参数可能会危及用户的安全。有关详细信息，请参阅：https://github.com/streamlit/streamlit/issues/152 |
| **help** *(str)*                                             | An optional tooltip that gets displayed next to the Markdown. 显示在 Markdown 旁边的可选工具提示。 |

**Examples**

> ```python
> import streamlit as st
> 
> st.markdown('Streamlit is **_really_ cool**.')
> st.markdown(”This text is :red[colored red], and this is **:blue[colored]** and bold.”)
> st.markdown(":green[$\sqrt{x^2+y^2}=1$] is a Pythagorean identity. :pencil:")
> ```

![img](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509225817510-733516809.png)



## st.title

以标题格式显示文本。

每个文档都应该有一个 st.title()，尽管这不是强制执行的。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/heading.py#L146) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.title(body, anchor=None, *, help=None)                    |                                                              |
| Parameters                                                   |                                                              |
| **body** *(str)*                                             | The text to display as Github-flavored Markdown. Syntax information can be found at: https://github.github.com/gfm. 要显示为 Github 风格的 Markdown 的文本。可以在以下位置找到语法信息： https://github.github.com/gfm 。This also supports: 这也支持：Emoji shortcodes, such as `:+1:` and `:sunglasses:`. For a list of all supported codes, see https://share.streamlit.io/streamlit/emoji-shortcodes. 表情符号短代码，例如 `:+1:` 和 `:sunglasses:` 。有关所有受支持代码的列表，请参阅 https://share.streamlit.io/streamlit/emoji-shortcodes 。LaTeX expressions, by wrapping them in "$" or "$$" (the "$$" must be on their own lines). Supported LaTeX functions are listed at https://katex.org/docs/supported.html. LaTeX 表达式，将它们包裹在“$”或“$$”中（“$$”必须在它们自己的行中）。支持的 LaTeX 函数列在 https://katex.org/docs/supported.html 中。Colored text, using the syntax `:color[text to be colored]`, where `color` needs to be replaced with any of the following supported colors: blue, green, orange, red, violet. 彩色文本，使用语法 `:color[text to be colored]` ，其中 `color` 需要替换为以下任何受支持的颜色：蓝色、绿色、橙色、红色、紫色。 |
| **anchor** *(str or False)* 锚点（str 或 False）             | The anchor name of the header that can be accessed with #anchor in the URL. If omitted, it generates an anchor using the body. If False, the anchor is not shown in the UI. 可以使用 URL 中的#anchor 访问的标头的锚点名称。如果省略，它会使用正文生成一个锚点。如果为 False，则锚点不会显示在 UI 中。 |
| **help** *(str)*                                             | An optional tooltip that gets displayed next to the title. 显示在标题旁边的可选工具提示。 |

**Examples**

> ```python
> import streamlit as st
> 
> st.title('This is a title')
> st.title('A title with _italics_ :blue[colors] and emojis :sunglasses:')
> ```
>
> Copy

![img](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509225859312-921500659.png)



## st.header

以标题格式显示文本。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/heading.py#L40) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.header(body, anchor=None, *, help=None)                   |                                                              |
| Parameters                                                   |                                                              |
| **body** *(str)*                                             | The text to display as Github-flavored Markdown. Syntax information can be found at: https://github.github.com/gfm. 要显示为 Github 风格的 Markdown 的文本。可以在以下位置找到语法信息： https://github.github.com/gfm 。This also supports: 这也支持：Emoji shortcodes, such as `:+1:` and `:sunglasses:`. For a list of all supported codes, see https://share.streamlit.io/streamlit/emoji-shortcodes. 表情符号短代码，例如 `:+1:` 和 `:sunglasses:` 。有关所有受支持代码的列表，请参阅 https://share.streamlit.io/streamlit/emoji-shortcodes 。LaTeX expressions, by wrapping them in "$" or "$$" (the "$$" must be on their own lines). Supported LaTeX functions are listed at https://katex.org/docs/supported.html. LaTeX 表达式，将它们包裹在“$”或“$$”中（“$$”必须在它们自己的行中）。支持的 LaTeX 函数列在 https://katex.org/docs/supported.html 中。Colored text, using the syntax `:color[text to be colored]`, where `color` needs to be replaced with any of the following supported colors: blue, green, orange, red, violet. 彩色文本，使用语法 `:color[text to be colored]` ，其中 `color` 需要替换为以下任何受支持的颜色：蓝色、绿色、橙色、红色、紫色。 |
| **anchor** *(str or False)* 锚点（str 或 False）             | The anchor name of the header that can be accessed with #anchor in the URL. If omitted, it generates an anchor using the body. If False, the anchor is not shown in the UI. 可以使用 URL 中的#anchor 访问的标头的锚点名称。如果省略，它会使用正文生成一个锚点。如果为 False，则锚点不会显示在 UI 中。 |
| **help** *(str)*                                             | An optional tooltip that gets displayed next to the header. 标题旁边显示的可选工具提示。 |

**Examples**

> ```python
> import streamlit as st
> 
> st.header('This is a header')
> st.header('A header with _italics_ :blue[colors] and emojis :sunglasses:')
> ```
>
> Copy

![img](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509225943031-602490072.png)



## st.subheader

以副标题格式显示文本。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/heading.py#L93) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.subheader(body, anchor=None, *, help=None)                |                                                              |
| Parameters                                                   |                                                              |
| **body** *(str)*                                             | The text to display as Github-flavored Markdown. Syntax information can be found at: https://github.github.com/gfm. 要显示为 Github 风格的 Markdown 的文本。可以在以下位置找到语法信息： https://github.github.com/gfm 。This also supports: 这也支持：Emoji shortcodes, such as `:+1:` and `:sunglasses:`. For a list of all supported codes, see https://share.streamlit.io/streamlit/emoji-shortcodes. 表情符号短代码，例如 `:+1:` 和 `:sunglasses:` 。有关所有受支持代码的列表，请参阅 https://share.streamlit.io/streamlit/emoji-shortcodes 。LaTeX expressions, by wrapping them in "$" or "$$" (the "$$" must be on their own lines). Supported LaTeX functions are listed at https://katex.org/docs/supported.html. LaTeX 表达式，将它们包裹在“$”或“$$”中（“$$”必须在它们自己的行中）。支持的 LaTeX 函数列在 https://katex.org/docs/supported.html 中。Colored text, using the syntax `:color[text to be colored]`, where `color` needs to be replaced with any of the following supported colors: blue, green, orange, red, violet. 彩色文本，使用语法 `:color[text to be colored]` ，其中 `color` 需要替换为以下任何受支持的颜色：蓝色、绿色、橙色、红色、紫色。 |
| **anchor** *(str or False)* 锚点（str 或 False）             | The anchor name of the header that can be accessed with #anchor in the URL. If omitted, it generates an anchor using the body. If False, the anchor is not shown in the UI. 可以使用 URL 中的#anchor 访问的标头的锚点名称。如果省略，它会使用正文生成一个锚点。如果为 False，则锚点不会显示在 UI 中。 |
| **help** *(str)*                                             | An optional tooltip that gets displayed next to the subheader. 显示在副标题旁边的可选工具提示。 |

**Examples**

> ```python
> import streamlit as st
> 
> st.subheader('This is a subheader')
> st.subheader('A subheader with _italics_ :blue[colors] and emojis :sunglasses:')
> ```
>
> Copy

![img](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509230003927-1995163596.png)



## st.caption

以小字体显示文本。

这应该用于标题、旁白、脚注、旁注和其他解释性文本。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/markdown.py#L132) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.caption(body, unsafe_allow_html=False, *, help=None)      |                                                              |
| Parameters                                                   |                                                              |
| **body** *(str)*                                             | The text to display as Github-flavored Markdown. Syntax information can be found at: https://github.github.com/gfm. 要显示为 Github 风格的 Markdown 的文本。可以在以下位置找到语法信息： https://github.github.com/gfm 。This also supports: 这也支持：Emoji shortcodes, such as `:+1:` and `:sunglasses:`. For a list of all supported codes, see https://share.streamlit.io/streamlit/emoji-shortcodes. 表情符号短代码，例如 `:+1:` 和 `:sunglasses:` 。有关所有受支持代码的列表，请参阅 https://share.streamlit.io/streamlit/emoji-shortcodes 。LaTeX expressions, by wrapping them in "$" or "$$" (the "$$" must be on their own lines). Supported LaTeX functions are listed at https://katex.org/docs/supported.html. LaTeX 表达式，将它们包裹在“$”或“$$”中（“$$”必须在它们自己的行中）。支持的 LaTeX 函数列在 https://katex.org/docs/supported.html 中。Colored text, using the syntax `:color[text to be colored]`, where `color` needs to be replaced with any of the following supported colors: blue, green, orange, red, violet. 彩色文本，使用语法 `:color[text to be colored]` ，其中 `color` 需要替换为以下任何受支持的颜色：蓝色、绿色、橙色、红色、紫色。 |
| **unsafe_allow_html** *(bool)*                               | By default, any HTML tags found in strings will be escaped and therefore treated as pure text. This behavior may be turned off by setting this argument to True. 默认情况下，在字符串中找到的任何 HTML 标记都将被转义，因此被视为纯文本。可以通过将此参数设置为 True 来关闭此行为。That said, *we strongly advise against it*. It is hard to write secure HTML, so by using this argument you may be compromising your users' security. For more information, see: 也就是说，我们强烈建议不要这样做。很难编写安全的 HTML，因此使用此参数可能会危及用户的安全。有关详细信息，请参阅：https://github.com/streamlit/streamlit/issues/152 |
| **help** *(str)*                                             | An optional tooltip that gets displayed next to the caption. 显示在标题旁边的可选工具提示。 |

**Examples**

> ```python
> import streamlit as st
> 
> st.caption('This is a string that explains something above.')
> st.caption('A caption with _italics_ :blue[colors] and emojis :sunglasses:')
> ```
>
> Copy

![img](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509230033137-1386220676.png)



## st.code

显示带有可选语法突出显示的代码块。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/code.py#L27) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.code(body, language="python", line_numbers=False)         |                                                              |
| Parameters                                                   |                                                              |
| **body** *(str)*                                             | The string to display as code. 要显示为代码的字符串。        |
| **language** *(str or None)* 语言（str 或 None）             | The language that the code is written in, for syntax highlighting. If `None`, the code will be unstyled. Defaults to `"python"`. 编写代码所用的语言，用于语法高亮显示。如果是 `None` ，代码将没有样式。默认为 `"python"` 。For a list of available `language` values, see: 有关可用的 `language` 值的列表，请参阅：https://github.com/react-syntax-highlighter/react-syntax-highlighter/blob/master/AVAILABLE_LANGUAGES_PRISM.MD |
| **line_numbers** *(bool)*                                    | An optional boolean indicating whether to show line numbers to the left of the code block. Defaults to `False`. 一个可选的布尔值，指示是否在代码块的左侧显示行号。默认为 `False` 。 |

**Example**

> ```python
> import streamlit as st
> 
> code = '''def hello():
>     print("Hello, Streamlit!")'''
> st.code(code, language='python')
> ```
>
> Copy

![img](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509230107982-316601261.png)

## st.text

编写固定宽度和预格式化的文本。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/text.py#L27) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.text(body, *, help=None) st.text（正文，*，帮助=无）      |                                                              |
| Parameters                                                   |                                                              |
| **body** *(str)*                                             | The string to display. 要显示的字符串。                      |
| **help** *(str)*                                             | An optional tooltip that gets displayed next to the text. 显示在文本旁边的可选工具提示。 |

**Example**

> ```python
> import streamlit as st
> 
> st.text('This is some text.')
> ```
>
> Copy

![img](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509230213569-1804355272.png)



## st.latex

显示格式为 LaTeX 的数学表达式。

支持的 LaTeX 函数列在 https://katex.org/docs/supported.html 中。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/markdown.py#L196) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.latex(body, *, help=None) st.latex（正文，*，帮助=无）    |                                                              |
| Parameters                                                   |                                                              |
| **body** *(str or SymPy expression)* 正文（str 或 SymPy 表达式） | The string or SymPy expression to display as LaTeX. If str, it's a good idea to use raw Python strings since LaTeX uses backslashes a lot. 要显示为 LaTeX 的字符串或 SymPy 表达式。如果是 str，最好使用原始 Python 字符串，因为 LaTeX 经常使用反斜杠。 |
| **help** *(str)*                                             | An optional tooltip that gets displayed next to the LaTeX expression. 在 LaTeX 表达式旁边显示的可选工具提示。 |

**Example**

> ```python
> import streamlit as st
> 
> st.latex(r'''
>     a + ar + a r^2 + a r^3 + \cdots + a r^{n-1} =
>     \sum_{k=0}^{n-1} ar^k =
>     a \left(\frac{1-r^{n}}{1-r}\right)
>     ''')
> ```
>
> Copy

![img](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509230255240-505163964.png)



## st.divider

显示水平线。

您可以使用脚本中的 st.write("---") 或什至只是"---"（通过魔术）实现相同的效果。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/markdown.py#L244) |
| ------------------------------------------------------------ |
| st.divider()                                                 |

Example

> ```python
> import streamlit as st
> 
> st.divider()
> ```

当您的应用程序中有多个元素时，它看起来像这样：

```python
import streamlit as st

st.write("This is some text.")

st.slider("This is a slider", 0, 100, (25, 75))

st.divider()  # 👈 Draws a horizontal rule

st.write("This text is between the horizontal rules.")

st.divider()  # 👈 Another horizontal rule
```

![img](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509230400321-1079802250.png)



# Data display elements

当您处理数据时，从多个不同角度快速、交互地可视化数据是非常有价值的。这就是 Streamlit 实际构建和优化的目的。

您可以通过图表显示数据，也可以以原始形式显示。这些是可用于显示原始数据的 Streamlit 命令。



## st.dataframe

将数据框显示为交互式表格。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/dataframe_selector.py#L40) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.dataframe(data=None, width=None, height=None, *, use_container_width=False) |                                                              |
| Parameters                                                   |                                                              |
| **data** *(pandas.DataFrame, pandas.Styler, pyarrow.Table, numpy.ndarray, pyspark.sql.DataFrame, snowflake.snowpark.dataframe.DataFrame, snowflake.snowpark.table.Table, Iterable, dict, or None)* 数据（pandas.DataFrame、pandas.Styler、pyarrow.Table、numpy.ndarray、pyspark.sql.DataFrame、snowflake.snowpark.dataframe.DataFrame、snowflake.snowpark.table.Table、Iterable、dict 或 None） | The data to display. 要显示的数据。If 'data' is a pandas.Styler, it will be used to style its underlying DataFrame. Streamlit supports custom cell values and colors. (It does not support some of the more exotic pandas styling features, like bar charts, hovering, and captions.) Styler support is experimental! Pyarrow tables are not supported by Streamlit's legacy DataFrame serialization (i.e. with config.dataFrameSerialization = "legacy"). To use pyarrow tables, please enable pyarrow by changing the config setting, config.dataFrameSerialization = "arrow". 如果“data”是 pandas.Styler，它将用于设置其底层 DataFrame 的样式。 Streamlit 支持自定义单元格值和颜色。 （它不支持一些更奇特的 pandas 样式功能，如条形图、悬停和标题。）Styler 支持是实验性的！ Streamlit 的遗留 DataFrame 序列化（即 config.dataFrameSerialization = "legacy"）不支持 Pyarrow 表。要使用 pyarrow 表，请通过更改配置设置 config.dataFrameSerialization = "arrow" 启用 pyarrow。 |
| **width** *(int or None)* 宽度（整数或无）                   | Desired width of the dataframe expressed in pixels. If None, the width will be automatically calculated based on the column content. 以像素表示的数据框的所需宽度。如果没有，宽度将根据列内容自动计算。 |
| **height** *(int or None)* 高度（整数或无）                  | Desired height of the dataframe expressed in pixels. If None, a default height is used. 以像素表示的数据框的所需高度。如果没有，则使用默认高度。 |
| **use_container_width** *(bool)* 使用容器宽度（布尔值）      | If True, set the dataframe width to the width of the parent container. This takes precedence over the width argument. This argument can only be supplied by keyword. 如果为真，则将数据框宽度设置为父容器的宽度。这优先于宽度参数。此参数只能由关键字提供。 |

**Examples**

> ```python
> import streamlit as st
> import pandas as pd
> import numpy as np
> 
> df = pd.DataFrame(
>    np.random.randn(50, 20),
>    columns=('col %d' % i for i in range(20)))
> 
> st.dataframe(df)  # Same as st.write(df)
> ```

![image-20230509230645756](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509230646725-532943482.png)

```python
st.dataframe(df, 200, 100)
```

您还可以传递 Pandas Styler 对象来更改呈现的 DataFrame 的样式：

```python
import streamlit as st
import pandas as pd
import numpy as np

df = pd.DataFrame(
   np.random.randn(10, 20),
   columns=('col %d' % i for i in range(20)))

st.dataframe(df.style.highlight_max(axis=0))
```

![image-20230509230716936](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509230718731-1245063622.png)

`st.dataframe` 支持 `use_container_width` 参数来拉伸整个容器宽度：

```python
import pandas as pd
import streamlit as st

# Cache the dataframe so it's only loaded once
@st.cache_data
def load_data():
    return pd.DataFrame(
        {
            "first column": [1, 2, 3, 4],
            "second column": [10, 20, 30, 40],
        }
    )

# Boolean to resize the dataframe, stored as a session state variable
st.checkbox("Use container width", value=False, key="use_container_width")

df = load_data()

# Display the dataframe and allow the user to stretch the dataframe
# across the full width of the container, based on the checkbox value
st.dataframe(df, use_container_width=st.session_state.use_container_width)
```

![image-20230509230746757](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509230747318-1298800332.png)

### Interactivity

*Interactivity*a：互动性、交互

显示为带有 `st.dataframe` 的交互式表格的数据框具有以下交互功能：

- 列排序：通过单击标题对列进行排序。
- 调整列大小：通过拖放列标题边框来调整列大小。
- 表格（高度、宽度）调整大小：通过拖放表格右下角来调整表格大小。
- 搜索：通过单击表格搜索数据，使用热键（ `⌘ Cmd + F` 或 `Ctrl + F` ）调出搜索栏，并使用搜索栏过滤数据。
- 复制到剪贴板：选择一个或多个单元格，将它们复制到剪贴板，然后将它们粘贴到您最喜欢的电子表格软件中。

![img](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509231149760-268672219.gif)



## st.table

显示静态表。

这与 st.dataframe 的不同之处在于，本例中的表格是静态的：其全部内容直接布局在页面上。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/dataframe_selector.py#L122) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.table(data=None) st.table（数据=无）                      |                                                              |
| Parameters                                                   |                                                              |
| **data** *(pandas.DataFrame, pandas.Styler, pyarrow.Table, numpy.ndarray, pyspark.sql.DataFrame, snowflake.snowpark.dataframe.DataFrame, snowflake.snowpark.table.Table, Iterable, dict, or None)* 数据（pandas.DataFrame、pandas.Styler、pyarrow.Table、numpy.ndarray、pyspark.sql.DataFrame、snowflake.snowpark.dataframe.DataFrame、snowflake.snowpark.table.Table、Iterable、dict 或 None） | The table data. Pyarrow tables are not supported by Streamlit's legacy DataFrame serialization (i.e. with config.dataFrameSerialization = "legacy"). To use pyarrow tables, please enable pyarrow by changing the config setting, config.dataFrameSerialization = "arrow". 表数据。 Streamlit 的遗留 DataFrame 序列化（即 config.dataFrameSerialization = "legacy"）不支持 Pyarrow 表。要使用 pyarrow 表，请通过更改配置设置 config.dataFrameSerialization = "arrow" 启用 pyarrow。 |

**Example**

> ```python
> import streamlit as st
> import pandas as pd
> import numpy as np
> 
> df = pd.DataFrame(
>    np.random.randn(10, 5),
>    columns=('col %d' % i for i in range(5)))
> 
> st.table(df)
> ```

![image-20230509231202549](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509231203364-517689408.png)



## st.metric

以粗体显示指标，并可选指示指标如何变化。

提示：如果你想显示一个大数字，使用 millify 或 numerize 等包来缩短它可能是个好主意。例如。 `1234` 可以使用 `st.metric("Short number", millify(1234))` 显示为 `1.2k` 。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/metric.py#L46) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.metric(label, value, delta=None, delta_color="normal", help=None, label_visibility="visible") st.metric(label, value, delta=None, delta_color="normal", help=None, label_visibility="可见") |                                                              |
| Parameters                                                   |                                                              |
| **label** *(str)*                                            | The header or title for the metric. The label can optionally contain Markdown and supports the following elements: Bold, Italics, Strikethroughs, Inline Code, Emojis, and Links. 指标的标题或标题。标签可以选择包含 Markdown 并支持以下元素：粗体、斜体、删除线、内联代码、表情符号和链接。This also supports: 这也支持：Emoji shortcodes, such as `:+1:` and `:sunglasses:`. For a list of all supported codes, see https://share.streamlit.io/streamlit/emoji-shortcodes. 表情符号短代码，例如 `:+1:` 和 `:sunglasses:` 。有关所有受支持代码的列表，请参阅 https://share.streamlit.io/streamlit/emoji-shortcodes 。LaTeX expressions, by wrapping them in "$" or "$$" (the "$$" must be on their own lines). Supported LaTeX functions are listed at https://katex.org/docs/supported.html. LaTeX 表达式，将它们包裹在“$”或“$$”中（“$$”必须在它们自己的行中）。支持的 LaTeX 函数列在 https://katex.org/docs/supported.html 中。Colored text, using the syntax `:color[text to be colored]`, where `color` needs to be replaced with any of the following supported colors: blue, green, orange, red, violet. 彩色文本，使用语法 `:color[text to be colored]` ，其中 `color` 需要替换为以下任何受支持的颜色：蓝色、绿色、橙色、红色、紫色。Unsupported elements are unwrapped so only their children (text contents) render. Display unsupported elements as literal characters by backslash-escaping them. E.g. `1\. Not an ordered list`. 不支持的元素被展开，因此只有它们的子元素（文本内容）呈现。通过反斜杠转义将不支持的元素显示为文字字符。例如。 `1\. Not an ordered list` 。 |
| **value** *(int, float, str, or None)* 值（整数、浮点数、海峡或无） | Value of the metric. None is rendered as a long dash. 指标的值。 None 呈现为长破折号。 |
| **delta** *(int, float, str, or None)* 增量（整数、浮点数、海峡或无） | Indicator of how the metric changed, rendered with an arrow below the metric. If delta is negative (int/float) or starts with a minus sign (str), the arrow points down and the text is red; else the arrow points up and the text is green. If None (default), no delta indicator is shown. 指标如何变化的指示器，在指标下方用箭头呈现。如果 delta 为负数 (int/float) 或以减号 (str) 开头，则箭头指向下方且文本为红色；否则箭头指向上方且文本为绿色。如果无（默认），则不显示增量指标。 |
| **delta_color** *(str)*                                      | If "normal" (default), the delta indicator is shown as described above. If "inverse", it is red when positive and green when negative. This is useful when a negative change is considered good, e.g. if cost decreased. If "off", delta is shown in gray regardless of its value. 如果为“正常”（默认），增量指标将按上述方式显示。如果是“inverse”，则正时为红色，负时为绿色。当负面变化被认为是好的时候，这很有用，例如如果成本下降。如果为“off”，无论其值如何，delta 都显示为灰色。 |
| **help** *(str)*                                             | An optional tooltip that gets displayed next to the metric label. 显示在指标标签旁边的可选工具提示。 |
| **label_visibility** *("visible" or "hidden" or "collapsed")* label_visibility（“可见”或“隐藏”或“折叠”） | The visibility of the label. If "hidden", the label doesn't show but there is still empty space for it (equivalent to label=""). If "collapsed", both the label and the space are removed. Default is "visible". This argument can only be supplied by keyword. 标签的可见性。如果“隐藏”，则标签不显示但仍有空白空间（相当于标签=“”）。如果“折叠”，则标签和空格都将被删除。默认为“可见”。此参数只能由关键字提供。 |

**Example**

> ```python
> import streamlit as st
> 
> st.metric(label="Temperature", value="70 °F", delta="1.2 °F")
> ```

![image-20230509231258793](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509231259380-1295811076.png)

`st.metric` 与 `st.columns` 的结合看起来特别好：

```pythonimport streamlit as st

col1, col2, col3 = st.columns(3)
col1.metric("Temperature", "70 °F", "1.2 °F")
col2.metric("Wind", "9 mph", "-8%")
col3.metric("Humidity", "86%", "4%")
```

![image-20230509231325279](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509231325896-651573002.png)

Delta 指示器颜色也可以反转或关闭：

```python
import streamlit as st

st.metric(label="Gas price", value=4, delta=-0.5,
    delta_color="inverse")

st.metric(label="Active developers", value=123, delta=123,
    delta_color="off")
```

![image-20230509231353388](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509231354044-2111390566.png)

## st.json

将对象或字符串显示为漂亮的 JSON 字符串。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/json.py#L35) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.json(body, *, expanded=True)                              |                                                              |
| Parameters                                                   |                                                              |
| **body** *(object or str)* 正文（对象或字符串）              | The object to print as JSON. All referenced objects should be serializable to JSON as well. If object is a string, we assume it contains serialized JSON. 要打印为 JSON 的对象。所有引用的对象也应该可以序列化为 JSON。如果对象是字符串，我们假设它包含序列化的 JSON。 |
| **expanded** *(bool)*                                        | An optional boolean that allows the user to set whether the initial state of this json element should be expanded. Defaults to True. This argument can only be supplied by keyword. 一个可选的布尔值，允许用户设置是否应扩展此 json 元素的初始状态。默认为真。此参数只能由关键字提供。 |

**Example**

> ```python
> import streamlit as st
> 
> st.json({
>     'foo': 'bar',
>     'baz': 'boz',
>     'stuff': [
>         'stuff 1',
>         'stuff 2',
>         'stuff 3',
>         'stuff 5',
>     ],
> })
> ```

![image-20230509231429818](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509231430383-457301049.png)

# Chart elements

Streamlit 支持多种不同的图表库，我们的目标是不断增加对更多图表库的支持。现在，我们库中最基本的库是 Matplotlib。然后还有交互式图表库，如 Vega Lite（2D 图表）和 deck.gl（地图和 3D 图表）。最后，我们还提供了一些 Streamlit 的“原生”图表类型，例如 `st.line_chart` 和 `st.area_chart` 。



## st.line_chart

显示折线图。

这是 st.altair_chart 的语法糖。主要区别在于此命令使用数据自己的列和索引来计算图表的规格。因此，这更易于用于许多“仅绘制此”场景，同时可定制性较低。

如果 st.line_chart 没有正确猜测数据规范，请尝试使用 st.altair_chart 指定您想要的图表。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/dataframe_selector.py#L160) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.line_chart(data=None, *, x=None, y=None, width=0, height=0, use_container_width=True) st.line_chart（数据=无，*，x=无，y=无，宽度=0，高度=0，use_container_width=True） |                                                              |
| Parameters                                                   |                                                              |
| **data** *(pandas.DataFrame, pandas.Styler, pyarrow.Table, numpy.ndarray, pyspark.sql.DataFrame, snowflake.snowpark.dataframe.DataFrame, snowflake.snowpark.table.Table, Iterable, dict or None)* 数据（pandas.DataFrame、pandas.Styler、pyarrow.Table、numpy.ndarray、pyspark.sql.DataFrame、snowflake.snowpark.dataframe.DataFrame、snowflake.snowpark.table.Table、Iterable、dict 或 None） | Data to be plotted. Pyarrow tables are not supported by Streamlit's legacy DataFrame serialization (i.e. with config.dataFrameSerialization = "legacy"). To use pyarrow tables, please enable pyarrow by changing the config setting, config.dataFrameSerialization = "arrow". 要绘制的数据。 Streamlit 的遗留 DataFrame 序列化（即 config.dataFrameSerialization = "legacy"）不支持 Pyarrow 表。要使用 pyarrow 表，请通过更改配置设置 config.dataFrameSerialization = "arrow" 启用 pyarrow。 |
| **x** *(str or None)* x（str 或无）                          | Column name to use for the x-axis. If None, uses the data index for the x-axis. This argument can only be supplied by keyword. 用于 x 轴的列名。如果没有，则使用 x 轴的数据索引。此参数只能由关键字提供。 |
| **y** *(str, sequence of str, or None)* y（str，str 的序列，或无） | Column name(s) to use for the y-axis. If a sequence of strings, draws several series on the same chart by melting your wide-format table into a long-format table behind the scenes. If None, draws the data of all remaining columns as data series. This argument can only be supplied by keyword. 用于 y 轴的列名。如果是字符串序列，通过在幕后将宽格式表格融合为长格式表格，在同一张图表上绘制多个系列。如果没有，则将所有剩余列的数据绘制为数据系列。此参数只能由关键字提供。 |
| **width** *(int)*                                            | The chart width in pixels. If 0, selects the width automatically. This argument can only be supplied by keyword. 以像素为单位的图表宽度。如果为 0，则自动选择宽度。此参数只能由关键字提供。 |
| **height** *(int)*                                           | The chart height in pixels. If 0, selects the height automatically. This argument can only be supplied by keyword. 以像素为单位的图表高度。如果为 0，则自动选择高度。此参数只能由关键字提供。 |
| **use_container_width** *(bool)* 使用容器宽度（布尔值）      | If True, set the chart width to the column width. This takes precedence over the width argument. This argument can only be supplied by keyword. 如果为真，则将图表宽度设置为列宽。这优先于宽度参数。此参数只能由关键字提供。 |

**Example**

> ```python
> import streamlit as st
> import pandas as pd
> import numpy as np
> 
> chart_data = pd.DataFrame(
>     np.random.randn(20, 3),
>     columns=['a', 'b', 'c'])
> 
> st.line_chart(chart_data)
> ```

![image-20230509231630956](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509231631617-110389945.png)



## st.area_chart

显示面积图。

这只是 st.altair_chart 的语法糖。主要区别在于此命令使用数据自己的列和索引来计算图表的规格。因此，这更易于用于许多“仅绘制此”场景，同时可定制性较低。

如果 st.area_chart 没有正确猜测数据规范，请尝试使用 st.altair_chart 指定您想要的图表。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/dataframe_selector.py#L247) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.area_chart(data=None, *, x=None, y=None, width=0, height=0, use_container_width=True) st.area_chart（数据=无，*，x=无，y=无，宽度=0，高度=0，use_container_width=True） |                                                              |
| Parameters                                                   |                                                              |
| **data** *(pandas.DataFrame, pandas.Styler, pyarrow.Table, numpy.ndarray, pyspark.sql.DataFrame, snowflake.snowpark.dataframe.DataFrame, snowflake.snowpark.table.Table, Iterable, or dict)* 数据（pandas.DataFrame、pandas.Styler、pyarrow.Table、numpy.ndarray、pyspark.sql.DataFrame、snowflake.snowpark.dataframe.DataFrame、snowflake.snowpark.table.Table、Iterable 或 dict） | Data to be plotted. Pyarrow tables are not supported by Streamlit's legacy DataFrame serialization (i.e. with config.dataFrameSerialization = "legacy"). To use pyarrow tables, please enable pyarrow by changing the config setting, config.dataFrameSerialization = "arrow". 要绘制的数据。 Streamlit 的遗留 DataFrame 序列化（即 config.dataFrameSerialization = "legacy"）不支持 Pyarrow 表。要使用 pyarrow 表，请通过更改配置设置 config.dataFrameSerialization = "arrow" 启用 pyarrow。 |
| **x** *(str or None)* x（str 或无）                          | Column name to use for the x-axis. If None, uses the data index for the x-axis. This argument can only be supplied by keyword. 用于 x 轴的列名。如果没有，则使用 x 轴的数据索引。此参数只能由关键字提供。 |
| **y** *(str, sequence of str, or None)* y（str，str 的序列，或无） | Column name(s) to use for the y-axis. If a sequence of strings, draws several series on the same chart by melting your wide-format table into a long-format table behind the scenes. If None, draws the data of all remaining columns as data series. This argument can only be supplied by keyword. 用于 y 轴的列名。如果是字符串序列，通过在幕后将宽格式表格融合为长格式表格，在同一张图表上绘制多个系列。如果没有，则将所有剩余列的数据绘制为数据系列。此参数只能由关键字提供。 |
| **width** *(int)*                                            | The chart width in pixels. If 0, selects the width automatically. This argument can only be supplied by keyword. 以像素为单位的图表宽度。如果为 0，则自动选择宽度。此参数只能由关键字提供。 |
| **height** *(int)*                                           | The chart height in pixels. If 0, selects the height automatically. This argument can only be supplied by keyword. 以像素为单位的图表高度。如果为 0，则自动选择高度。此参数只能由关键字提供。 |
| **use_container_width** *(bool)* 使用容器宽度（布尔值）      | If True, set the chart width to the column width. This takes precedence over the width argument. This argument can only be supplied by keyword. 如果为真，则将图表宽度设置为列宽。这优先于宽度参数。此参数只能由关键字提供。 |

**Example**

> ```python
> import streamlit as st
> import pandas as pd
> import numpy as np
> 
> chart_data = pd.DataFrame(
>     np.random.randn(20, 3),
>     columns=['a', 'b', 'c'])
> 
> st.area_chart(chart_data)
> ```

![image-20230509231716343](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509231717058-1086870789.png)



## st.bar_chart

显示条形图。

这只是 st.altair_chart 的语法糖。主要区别在于此命令使用数据自己的列和索引来计算图表的规格。因此，这更易于用于许多“仅绘制此”场景，同时可定制性较低。

如果 st.bar_chart 没有正确猜测数据规范，请尝试使用 st.altair_chart 指定您想要的图表。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/dataframe_selector.py#L334) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.bar_chart(data=None, *, x=None, y=None, width=0, height=0, use_container_width=True) st.bar_chart（数据=无，*，x=无，y=无，宽度=0，高度=0，use_container_width=True） |                                                              |
| Parameters                                                   |                                                              |
| **data** *(pandas.DataFrame, pandas.Styler, pyarrow.Table, numpy.ndarray, pyspark.sql.DataFrame, snowflake.snowpark.dataframe.DataFrame, snowflake.snowpark.table.Table, Iterable, or dict)* 数据（pandas.DataFrame、pandas.Styler、pyarrow.Table、numpy.ndarray、pyspark.sql.DataFrame、snowflake.snowpark.dataframe.DataFrame、snowflake.snowpark.table.Table、Iterable 或 dict） | Data to be plotted. Pyarrow tables are not supported by Streamlit's legacy DataFrame serialization (i.e. with config.dataFrameSerialization = "legacy"). To use pyarrow tables, please enable pyarrow by changing the config setting, config.dataFrameSerialization = "arrow". 要绘制的数据。 Streamlit 的遗留 DataFrame 序列化（即 config.dataFrameSerialization = "legacy"）不支持 Pyarrow 表。要使用 pyarrow 表，请通过更改配置设置 config.dataFrameSerialization = "arrow" 启用 pyarrow。 |
| **x** *(str or None)* x（str 或无）                          | Column name to use for the x-axis. If None, uses the data index for the x-axis. This argument can only be supplied by keyword. 用于 x 轴的列名。如果没有，则使用 x 轴的数据索引。此参数只能由关键字提供。 |
| **y** *(str, sequence of str, or None)* y（str，str 的序列，或无） | Column name(s) to use for the y-axis. If a sequence of strings, draws several series on the same chart by melting your wide-format table into a long-format table behind the scenes. If None, draws the data of all remaining columns as data series. This argument can only be supplied by keyword. 用于 y 轴的列名。如果是字符串序列，通过在幕后将宽格式表格融合为长格式表格，在同一张图表上绘制多个系列。如果没有，则将所有剩余列的数据绘制为数据系列。此参数只能由关键字提供。 |
| **width** *(int)*                                            | The chart width in pixels. If 0, selects the width automatically. This argument can only be supplied by keyword. 以像素为单位的图表宽度。如果为 0，则自动选择宽度。此参数只能由关键字提供。 |
| **height** *(int)*                                           | The chart height in pixels. If 0, selects the height automatically. This argument can only be supplied by keyword. 以像素为单位的图表高度。如果为 0，则自动选择高度。此参数只能由关键字提供。 |
| **use_container_width** *(bool)* 使用容器宽度（布尔值）      | If True, set the chart width to the column width. This takes precedence over the width argument. This argument can only be supplied by keyword. 如果为真，则将图表宽度设置为列宽。这优先于宽度参数。此参数只能由关键字提供。 |

**Example**

> ```python
> import streamlit as st
> import pandas as pd
> import numpy as np
> 
> chart_data = pd.DataFrame(
>     np.random.randn(20, 3),
>     columns=["a", "b", "c"])
> 
> st.bar_chart(chart_data)
> ```

![image-20230509231808601](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509231809154-1684163234.png)



## st.pyplot

显示 matplotlib.pyplot 图。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/pyplot.py#L38) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.pyplot(fig=None, clear_figure=None, use_container_width=True, **kwargs) |                                                              |
| Parameters                                                   |                                                              |
| **fig** *(Matplotlib Figure)* 图（Matplotlib 图）            | The figure to plot. When this argument isn't specified, this function will render the global figure (but this is deprecated, as described below) 要绘制的图形。未指定此参数时，此函数将渲染全局图形（但已弃用，如下所述） |
| **clear_figure** *(bool)*                                    | If True, the figure will be cleared after being rendered. If False, the figure will not be cleared after being rendered. If left unspecified, we pick a default based on the value of fig. 如果为 True，图形将在渲染后清除。如果为False，图形在渲染后不会被清除。如果未指定，我们会根据图的值选择默认值。If fig is set, defaults to False. 如果设置了 fig，则默认为 False。If fig is not set, defaults to True. This simulates Jupyter's approach to matplotlib rendering. 如果未设置 fig，则默认为 True。这模拟了 Jupyter 的 matplotlib 渲染方法。 |
| **use_container_width** *(bool)* 使用容器宽度（布尔值）      | If True, set the chart width to the column width. Defaults to True. 如果为真，则将图表宽度设置为列宽。默认为真。 |
| ***\*kwargs** *(any)*                                        | Arguments to pass to Matplotlib's savefig function. 传递给 Matplotlib 的 savefig 函数的参数。 |

**Example**

> ```python
> import streamlit as st
> import matplotlib.pyplot as plt
> import numpy as np
> 
> arr = np.random.normal(1, 1, size=100)
> fig, ax = plt.subplots()
> ax.hist(arr, bins=20)
> 
> st.pyplot(fig)
> ```

![image-20230509231843277](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509231843833-1800612624.png)

弃用警告。 2020 年 12 月 1 日之后，我们将取消在 st.pyplot() 中不指定任何参数的功能，因为这需要使用 Matplotlib 的全局图形对象，这不是线程安全的。所以请始终传递一个图形对象，如上面的示例部分所示。

Matplotlib 支持多种类型的“后端”。如果将 Matplotlib 与 Streamlit 结合使用时出现错误，请尝试将后端设置为“TkAgg”：

```python
echo "backend: TkAgg" >> ~/.matplotlib/matplotlibrc
```



## st.altair_chart

使用 Altair 库显示图表。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/dataframe_selector.py#L422) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.altair_chart(altair_chart, use_container_width=False, theme="streamlit") |                                                              |
| Parameters                                                   |                                                              |
| **altair_chart** *(altair.vegalite.v2.api.Chart)* altair_chart (altair.vegalite.v2.api.Chart) | The Altair chart object to display. 要显示的 Altair 图表对象。 |
| **use_container_width** *(bool)* 使用容器宽度（布尔值）      | If True, set the chart width to the column width. This takes precedence over Altair's native width value. 如果为真，则将图表宽度设置为列宽。这优先于 Altair 的本机宽度值。 |
| **theme** *("streamlit" or None)* 主题（“streamlit”或无）    | The theme of the chart. Currently, we only support "streamlit" for the Streamlit defined design or None to fallback to the default behavior of the library. 图表的主题。目前，我们仅支持 Streamlit 定义设计的“streamlit”或 None 以回退到库的默认行为。 |

**Example**

> ```python
> import streamlit as st
> import pandas as pd
> import numpy as np
> import altair as alt
> 
> chart_data = pd.DataFrame(
>     np.random.randn(20, 3),
>     columns=['a', 'b', 'c'])
> 
> c = alt.Chart(chart_data).mark_circle().encode(
>     x='a', y='b', size='c', color='c', tooltip=['a', 'b', 'c'])
> 
> st.altair_chart(c, use_container_width=True)
> ```

可以在 https://altair-viz.github.io/gallery/ 找到 Altair 图表的示例。

![image-20230509231943521](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509231944189-777168789.png)

默认情况下，Altair 图表使用 Streamlit 主题显示。这个主题时尚、用户友好，并结合了 Streamlit 的调色板。额外的好处是您的图表可以更好地与应用程序设计的其余部分集成。

Streamlit 主题可通过 `theme="streamlit"` 关键字参数从 Streamlit 1.16.0 获得。要禁用它并使用 Altair 的原生主题，请改用 `theme=None` 。

让我们看一个带有 Streamlit 主题和原生 Altair 主题的图表示例：

```python
import altair as alt
from vega_datasets import data

source = data.cars()

chart = alt.Chart(source).mark_circle().encode(
    x='Horsepower',
    y='Miles_per_Gallon',
    color='Origin',
).interactive()

tab1, tab2 = st.tabs(["Streamlit theme (default)", "Altair native theme"])

with tab1:
    # Use the Streamlit theme.
    # This is the default. So you can also omit the theme argument.
    st.altair_chart(chart, theme="streamlit", use_container_width=True)
with tab2:
    # Use the native Altair theme.
    st.altair_chart(chart, theme=None, use_container_width=True)
```

单击下面交互式应用程序中的选项卡，查看启用和禁用 Streamlit 主题的图表。

![image-20230509232055957](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509232057060-216174204.png)

![image-20230509232104593](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509232105166-1801276897.png)

如果您想知道您自己的定制是否仍会被考虑在内，请不要担心！您仍然可以更改图表配置。换句话说，虽然我们现在默认启用 Streamlit 主题，但您可以使用自定义颜色或字体覆盖它。例如，如果您希望图表线条为绿色而不是默认的红色，您可以做到！

这是一个 Altair 图表的示例，其中完成并反映了手动颜色传递：

```python
import altair as alt
import streamlit as st
from vega_datasets import data

source = data.seattle_weather()

scale = alt.Scale(
    domain=["sun", "fog", "drizzle", "rain", "snow"],
    range=["#e7ba52", "#a7a7a7", "#aec7e8", "#1f77b4", "#9467bd"],
)
color = alt.Color("weather:N", scale=scale)

# We create two selections:
# - a brush that is active on the top panel
# - a multi-click that is active on the bottom panel
brush = alt.selection_interval(encodings=["x"])
click = alt.selection_multi(encodings=["color"])

# Top panel is scatter plot of temperature vs time
points = (
    alt.Chart()
    .mark_point()
    .encode(
        alt.X("monthdate(date):T", title="Date"),
        alt.Y(
            "temp_max:Q",
            title="Maximum Daily Temperature (C)",
            scale=alt.Scale(domain=[-5, 40]),
        ),
        color=alt.condition(brush, color, alt.value("lightgray")),
        size=alt.Size("precipitation:Q", scale=alt.Scale(range=[5, 200])),
    )
    .properties(width=550, height=300)
    .add_selection(brush)
    .transform_filter(click)
)

# Bottom panel is a bar chart of weather type
bars = (
    alt.Chart()
    .mark_bar()
    .encode(
        x="count()",
        y="weather:N",
        color=alt.condition(click, color, alt.value("lightgray")),
    )
    .transform_filter(brush)
    .properties(
        width=550,
    )
    .add_selection(click)
)

chart = alt.vconcat(points, bars, data=source, title="Seattle Weather: 2012-2015")

tab1, tab2 = st.tabs(["Streamlit theme (default)", "Altair native theme"])

with tab1:
    st.altair_chart(chart, theme="streamlit", use_container_width=True)
with tab2:
    st.altair_chart(chart, theme=None, use_container_width=True)
```

![image-20230509232155909](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509232156579-1052196838.png)

![image-20230509232209429](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509232210233-406775470.png)

有关带有和不带有 Streamlit 主题的 Altair 图表的更多示例，请查看 [altair.streamlit.app](https://altair.streamlit.app/).



## Annotating charts

Altair 还允许您使用文本、图像和表情符号对图表进行注释。您可以通过创建分层图表来做到这一点，这样您就可以将两个不同的图表叠加在一起。这个想法是使用第一个图表显示数据，第二个图表显示注释。然后可以使用 `+` 运算符将第二个图表覆盖在第一个图表之上，以创建分层图表。

让我们来看一个使用文本和表情符号注释时间序列图表的示例。

### Step 1: Create the base chart

在这个例子中，我们创建了一个时间序列图表来跟踪股票价格的演变。该图表是交互式的，并包含多行工具提示。单击此处了解有关 Altair 中多行工具提示的更多信息。

首先，我们导入所需的库并使用 `vega_datasets` 包加载示例股票数据集：

```python
import altair as alt
import pandas as pd
import streamlit as st
from vega_datasets import data

# We use @st.cache_data to keep the dataset in cache
@st.cache_data
def get_data():
    source = data.stocks()
    source = source[source.date.gt("2004-01-01")]
    return source

source = get_data()
```

接下来，我们定义一个函数 `get_chart()` 来创建带有多行工具提示的交互式股票价格时间序列图表。 x 轴代表日期，y 轴代表股票价格。

然后我们调用 `get_chart()` ，它将股票价格数据框作为输入并返回一个图表对象。这将是我们的基础图表，我们将在其上叠加步骤 2 中的注释。

```python
# Define the base time-series chart.
def get_chart(data):
    hover = alt.selection_single(
        fields=["date"],
        nearest=True,
        on="mouseover",
        empty="none",
    )

    lines = (
        alt.Chart(data, title="Evolution of stock prices")
        .mark_line()
        .encode(
            x="date",
            y="price",
            color="symbol",
        )
    )

    # Draw points on the line, and highlight based on selection
    points = lines.transform_filter(hover).mark_circle(size=65)

    # Draw a rule at the location of the selection
    tooltips = (
        alt.Chart(data)
        .mark_rule()
        .encode(
            x="yearmonthdate(date)",
            y="price",
            opacity=alt.condition(hover, alt.value(0.3), alt.value(0)),
            tooltip=[
                alt.Tooltip("date", title="Date"),
                alt.Tooltip("price", title="Price (USD)"),
            ],
        )
        .add_selection(hover)
    )
    return (lines + points + tooltips).interactive()

chart = get_chart(source)
```



### Step 2: Annotate the chart

*Annotate ：标注*

现在我们有了第一个显示数据的图表，我们可以用文本和表情符号对其进行注释。让我们在特定兴趣点的时间序列图表顶部叠加 ⬇ 表情符号。我们希望用户将鼠标悬停在 ⬇ 表情符号上以查看关联的注释文本。

为简单起见，让我们注释四个特定日期并将注释的高度设置为常量值 `10` 。

**Tip:**

您可以通过将硬编码值替换为 Streamlit 小部件的输出来改变注释的水平和垂直位置！单击此处跳转到下面的实时示例，并通过使用 Streamlit 小部件培养对注释的理想水平和垂直位置的直觉。

为此，我们创建了一个包含日期、注释文本和注释高度的数据框 `annotations_df` ：

```python
# Add annotations
ANNOTATIONS = [
    ("Mar 01, 2008", "Pretty good day for GOOG"),
    ("Dec 01, 2007", "Something's going wrong for GOOG & AAPL"),
    ("Nov 01, 2008", "Market starts again thanks to..."),
    ("Dec 01, 2009", "Small crash for GOOG after..."),
]
annotations_df = pd.DataFrame(ANNOTATIONS, columns=["date", "event"])
annotations_df.date = pd.to_datetime(annotations_df.date)
annotations_df["y"] = 10
```

使用此数据框，我们创建了一个散点图，其中 x 轴表示日期，y 轴表示注释的高度。特定日期和高度的数据点由 ⬇ 表情符号表示，使用 Altair 的 `mark_text()` 标记。

当用户将鼠标悬停在 ⬇ 表情符号上时，注释文本将显示为工具提示。这是通过使用 Altair 的 `encode()` 方法将包含注释文本的 `event` 列映射到绘图的视觉属性 ⬇ 来实现的。

```python
annotation_layer = (
    alt.Chart(annotations_df)
    .mark_text(size=20, text="⬇", dx=-8, dy=-10, align="left")
    .encode(
        x="date:T",
        y=alt.Y("y:Q"),
        tooltip=["event"],
    )
    .interactive()
)
```

最后，我们使用 `+` 运算符将注释叠加在基本图表之上，以创建最终的分层图表！ 🎈

```python
st.altair_chart(
    (chart + annotation_layer).interactive(),
    use_container_width=True
)
```

![img](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509232607315-1163206434.png)

要使用图像而不是表情符号，请将包含 `.mark_text()` 的行替换为 `.mark_image()` ，并将下面的 `image_url` 替换为图像的 URL：

```python
.mark_image(
    width=12,
    height=12,
    url="image_url",
)
```

### Interactive example

*Interactive：交互*

既然您已经学会了如何注释图表，那就没有极限了！我们扩展了上面的示例，让您可以交互式地粘贴您最喜欢的表情符号，并使用 Streamlit 小部件设置其在图表上的位置。 👇

![image-20230509232815206](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509232815986-564820605.png)





## st.vega_lite_chart

使用 Vega-Lite 库显示图表。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/dataframe_selector.py#L475) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.vega_lite_chart(data=None, spec=None, use_container_width=False, theme="streamlit", **kwargs) st.vega_lite_chart（数据=无，规格=无，use_container_width=False，主题=“streamlit”，** kwargs） |                                                              |
| Parameters                                                   |                                                              |
| **data** *(pandas.DataFrame, pandas.Styler, pyarrow.Table, numpy.ndarray, Iterable, dict, or None)* 数据（pandas.DataFrame、pandas.Styler、pyarrow.Table、numpy.ndarray、Iterable、dict 或 None） | Either the data to be plotted or a Vega-Lite spec containing the data (which more closely follows the Vega-Lite API). Pyarrow tables are not supported by Streamlit's legacy DataFrame serialization (i.e. with config.dataFrameSerialization = "legacy"). To use pyarrow tables, please enable pyarrow by changing the config setting, config.dataFrameSerialization = "arrow". 要绘制的数据或包含数据的 Vega-Lite 规范（更接近于 Vega-Lite API）。 Streamlit 的遗留 DataFrame 序列化（即 config.dataFrameSerialization = "legacy"）不支持 Pyarrow 表。要使用 pyarrow 表，请通过更改配置设置 config.dataFrameSerialization = "arrow" 启用 pyarrow。 |
| **spec** *(dict or None)* 规格（字典或无）                   | The Vega-Lite spec for the chart. If the spec was already passed in the previous argument, this must be set to None. See https://vega.github.io/vega-lite/docs/ for more info. 图表的 Vega-Lite 规范。如果规范已经在前一个参数中传递，则必须将其设置为 None。有关更多信息，请参阅 https://vega.github.io/vega-lite/docs/ 。 |
| **use_container_width** *(bool)* 使用容器宽度（布尔值）      | If True, set the chart width to the column width. This takes precedence over Vega-Lite's native width value. 如果为真，则将图表宽度设置为列宽。这优先于 Vega-Lite 的原始宽度值。 |
| **theme** *("streamlit" or None)* 主题（“streamlit”或无）    | The theme of the chart. Currently, we only support "streamlit" for the Streamlit defined design or None to fallback to the default behavior of the library. 图表的主题。目前，我们仅支持 Streamlit 定义设计的“streamlit”或 None 以回退到库的默认行为。 |
| ***\*kwargs** *(any)*                                        | Same as spec, but as keywords. 与规范相同，但作为关键字。    |

**Example**

> ```python
> import streamlit as st
> import pandas as pd
> import numpy as np
> 
> chart_data = pd.DataFrame(
>     np.random.randn(200, 3),
>     columns=['a', 'b', 'c'])
> 
> st.vega_lite_chart(chart_data, {
>     'mark': {'type': 'circle', 'tooltip': True},
>     'encoding': {
>         'x': {'field': 'a', 'type': 'quantitative'},
>         'y': {'field': 'b', 'type': 'quantitative'},
>         'size': {'field': 'c', 'type': 'quantitative'},
>         'color': {'field': 'c', 'type': 'quantitative'},
>     },
> })
> ```

![image-20230509232934029](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509232934696-1326448962.png)

可以在 https://vega.github.io/vega-lite/examples/ 找到不使用 Streamlit 的 Vega-Lite 用法示例。其中大部分可以很容易地转换为上面显示的语法。

### Theming

Vega-Lite 图表默认使用 Streamlit 主题显示。这个主题时尚、用户友好，并结合了 Streamlit 的调色板。额外的好处是您的图表可以更好地与应用程序设计的其余部分集成。

Streamlit 主题可通过 `theme="streamlit"` 关键字参数从 Streamlit 1.16.0 获得。要禁用它并使用 Vega-Lite 的原生主题，请改用 `theme=None` 。

让我们看一个带有 Streamlit 主题和原生 Vega-Lite 主题的图表示例：

```python
import streamlit as st
from vega_datasets import data

source = data.cars()

chart = {
    "mark": "point",
    "encoding": {
        "x": {
            "field": "Horsepower",
            "type": "quantitative",
        },
        "y": {
            "field": "Miles_per_Gallon",
            "type": "quantitative",
        },
        "color": {"field": "Origin", "type": "nominal"},
        "shape": {"field": "Origin", "type": "nominal"},
    },
}

tab1, tab2 = st.tabs(["Streamlit theme (default)", "Vega-Lite native theme"])

with tab1:
    # Use the Streamlit theme.
    # This is the default. So you can also omit the theme argument.
    st.vega_lite_chart(
        source, chart, theme="streamlit", use_container_width=True
    )
with tab2:
    st.vega_lite_chart(
        source, chart, theme=None, use_container_width=True
    )
```

![image-20230509233043398](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509233044066-805895740.png)

![image-20230509233055300](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509233055986-1761800685.png)

## st.plotly_chart

显示交互式 Plotly 图表。

Plotly 是 Python 的图表库。此函数的参数与 Plotly 的 plot() 函数的参数非常接近。您可以在 https://plot.ly/python 找到更多关于 Plotly 的信息。

要在 Streamlit 中显示 Plotly 图表，请在调用 Plotly 的 py.plot 或 py.iplot 的任何地方调用 st.plotly_chart。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/plotly_chart.py#L81) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.plotly_chart(figure_or_data, use_container_width=False, sharing="streamlit", theme="streamlit", **kwargs) st.plotly_chart(figure_or_data, use_container_width=False, sharing="streamlit", 主题="streamlit", **kwargs) |                                                              |
| Parameters                                                   |                                                              |
| **figure_or_data** *(plotly.graph_objs.Figure, plotly.graph_objs.Data,)* figure_or_data (plotly.graph_objs.Figure, plotly.graph_objs.Data,) | dict/list of plotly.graph_objs.Figure/Data plotly.graph_objs.Figure/Data 的字典/列表See https://plot.ly/python/ for examples of graph descriptions. 有关图形描述的示例，请参阅 https://plot.ly/python/ 。 |
| **use_container_width** *(bool)* 使用容器宽度（布尔值）      | If True, set the chart width to the column width. This takes precedence over the figure's native width value. 如果为真，则将图表宽度设置为列宽。这优先于图形的原始宽度值。 |
| **sharing** *({'streamlit', 'private', 'secret', 'public'})* 分享（{'streamlit', 'private', 'secret', 'public'}） | Use 'streamlit' to insert the plot and all its dependencies directly in the Streamlit app using plotly's offline mode (default). Use any other sharing mode to send the chart to Plotly chart studio, which requires an account. See https://plot.ly/python/chart-studio/ for more information. 使用“streamlit”使用 plotly 的离线模式（默认）将绘图及其所有依赖项直接插入到 Streamlit 应用程序中。使用任何其他共享模式将图表发送到 Plotly chart studio，这需要一个帐户。有关详细信息，请参阅 https://plot.ly/python/chart-studio/ 。 |
| **theme** *("streamlit" or None)* 主题（“streamlit”或无）    | The theme of the chart. Currently, we only support "streamlit" for the Streamlit defined design or None to fallback to the default behavior of the library. 图表的主题。目前，我们仅支持 Streamlit 定义设计的“streamlit”或 None 以回退到库的默认行为。 |
| ***\*kwargs** *(null)*                                       | Any argument accepted by Plotly's plot() function. Plotly 的 plot() 函数接受的任何参数。 |

**Example**

下面的示例直接来自 https://plot.ly/python 的示例：

```python
import streamlit as st
import numpy as np
import plotly.figure_factory as ff

# Add histogram data
x1 = np.random.randn(200) - 2
x2 = np.random.randn(200)
x3 = np.random.randn(200) + 2

# Group data together
hist_data = [x1, x2, x3]

group_labels = ['Group 1', 'Group 2', 'Group 3']

# Create distplot with custom bin_size
fig = ff.create_distplot(
        hist_data, group_labels, bin_size=[.1, .25, .5])

# Plot!
st.plotly_chart(fig, use_container_width=True)
```

![image-20230509233304939](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509233305589-1286305089.png)

### Theming

默认情况下，Plotly 图表使用 Streamlit 主题显示。这个主题时尚、用户友好，并结合了 Streamlit 的调色板。额外的好处是您的图表可以更好地与应用程序设计的其余部分集成。

Streamlit 主题可通过 `theme="streamlit"` 关键字参数从 Streamlit 1.16.0 获得。要禁用它并使用 Plotly 的原生主题，请改用 `theme=None` 。

让我们看一个带有 Streamlit 主题和原生 Plotly 主题的图表示例：

```python
import plotly.express as px
import streamlit as st

df = px.data.gapminder()

fig = px.scatter(
    df.query("year==2007"),
    x="gdpPercap",
    y="lifeExp",
    size="pop",
    color="continent",
    hover_name="country",
    log_x=True,
    size_max=60,
)

tab1, tab2 = st.tabs(["Streamlit theme (default)", "Plotly native theme"])
with tab1:
    # Use the Streamlit theme.
    # This is the default. So you can also omit the theme argument.
    st.plotly_chart(fig, theme="streamlit", use_container_width=True)
with tab2:
    # Use the native Plotly theme.
    st.plotly_chart(fig, theme=None, use_container_width=True)
```

![image-20230509233415708](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509233416513-957613910.png)

![image-20230509233430642](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509233431300-1574946773.png)



如果您想知道您自己的定制是否仍会被考虑在内，请不要担心！您仍然可以更改图表配置。换句话说，虽然我们现在默认启用 Streamlit 主题，但您可以使用自定义颜色或字体覆盖它。例如，如果您希望图表线条为绿色而不是默认的红色，您可以做到！

下面是一个 Plotly 图表的示例，其中定义并反映了自定义色标：

```python
import plotly.express as px
import streamlit as st

st.subheader("Define a custom colorscale")
df = px.data.iris()
fig = px.scatter(
    df,
    x="sepal_width",
    y="sepal_length",
    color="sepal_length",
    color_continuous_scale="reds",
)

tab1, tab2 = st.tabs(["Streamlit theme (default)", "Plotly native theme"])
with tab1:
    st.plotly_chart(fig, theme="streamlit", use_container_width=True)
with tab2:
    st.plotly_chart(fig, theme=None, use_container_width=True)
```

请注意自定义色标如何仍然反映在图表中，即使启用了 Streamlit 主题👇

![image-20230509233513076](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509233513722-1176848571.png)

![image-20230509233523931](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509233524518-708198666.png)



## st.bokeh_chart

显示交互式散景图。

Bokeh 是 Python 的图表库。此函数的参数与 Bokeh 的 show 函数的参数非常相似。您可以在 [https://bokeh.pydata.org](https://bokeh.pydata.org/) 找到更多关于 Bokeh 的信息。

要在 Streamlit 中显示 Bokeh 图表，请在调用 Bokeh 显示的任何地方调用 st.bokeh_chart。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/bokeh_chart.py#L36) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.bokeh_chart(figure, use_container_width=False) st.bokeh_chart（图，use_container_width=False） |                                                              |
| Parameters                                                   |                                                              |
| **figure** *(bokeh.plotting.figure.Figure)* 图（bokeh.plotting.figure.Figure） | A Bokeh figure to plot. 要绘制的散景图。                     |
| **use_container_width** *(bool)* 使用容器宽度（布尔值）      | If True, set the chart width to the column width. This takes precedence over Bokeh's native width value. 如果为真，则将图表宽度设置为列宽。这优先于 Bokeh 的原生宽度值。 |

**Example**

> ```python
> import streamlit as st
> from bokeh.plotting import figure
> 
> x = [1, 2, 3, 4, 5]
> y = [6, 7, 2, 4, 5]
> 
> p = figure(
>     title='simple line example',
>     x_axis_label='x',
>     y_axis_label='y')
> 
> p.line(x, y, legend_label='Trend', line_width=2)
> 
> st.bokeh_chart(p, use_container_width=True)
> ```

![image-20230509233639991](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509233640614-914811445.png)



## st.pydeck_chart

使用 PyDeck 库绘制图表。

这支持 3D 地图、点云等！有关 PyDeck 的更多信息，请访问 https://deckgl.readthedocs.io/en/latest/ 。

这些文档也很有用：

- DeckGL docs: https://github.com/uber/deck.gl/tree/master/docs DeckGL 文档： https://github.com/uber/deck.gl/tree/master/docs
- DeckGL JSON docs: https://github.com/uber/deck.gl/tree/master/modules/json
  DeckGL JSON 文档： https://github.com/uber/deck.gl/tree/master/modules/json

使用此命令时，Mapbox 提供地图瓦片来渲染地图内容。请注意，Mapbox 是第三方产品，其使用受 Mapbox 使用条款的约束。

Mapbox 要求用户注册并提供令牌，然后用户才能请求地图图块。目前，Streamlit 为您提供此令牌，但这可能随时更改。我们强烈建议所有用户创建和使用他们自己的个人 Mapbox 令牌，以避免对他们的体验造成任何干扰。您可以使用 `mapbox.token` 配置选项执行此操作。

要为自己获取令牌，请在 [https://mapbox.com](https://mapbox.com/) 创建一个帐户。有关如何设置配置选项的更多信息，请参阅 https://docs.streamlit.io/library/advanced-features/configuration

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/deck_gl_json_chart.py#L36) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.pydeck_chart(pydeck_obj=None, use_container_width=False) st.pydeck_chart（pydeck_obj=无，use_container_width=False） |                                                              |
| Parameters                                                   |                                                              |
| **pydeck_obj** *(pydeck.Deck or None)* pydeck_obj（pydeck.Deck 或无） | Object specifying the PyDeck chart to draw. 指定要绘制的 PyDeck 图表的对象。 |
| **use_container_width** *(bool)* 使用容器宽度（布尔值）      | No description                                               |

**Example**

这是使用 HexagonLayer 和 ScatterplotLayer 的图表。它使用浅色或深色贴图样式，基于当前激活的 Streamlit 主题：

```python
import streamlit as st
import pandas as pd
import numpy as np
import pydeck as pdk

chart_data = pd.DataFrame(
   np.random.randn(1000, 2) / [50, 50] + [37.76, -122.4],
   columns=['lat', 'lon'])

st.pydeck_chart(pdk.Deck(
    map_style=None,
    initial_view_state=pdk.ViewState(
        latitude=37.76,
        longitude=-122.4,
        zoom=11,
        pitch=50,
    ),
    layers=[
        pdk.Layer(
           'HexagonLayer',
           data=chart_data,
           get_position='[lon, lat]',
           radius=200,
           elevation_scale=4,
           elevation_range=[0, 1000],
           pickable=True,
           extruded=True,
        ),
        pdk.Layer(
            'ScatterplotLayer',
            data=chart_data,
            get_position='[lon, lat]',
            get_color='[200, 30, 0, 160]',
            get_radius=200,
        ),
    ],
))
Copy

```

![image-20230509233832530](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509233833511-2106791317.png)

为了使PyDeck图表的风格与Streamlit的主题一致，可以在 `pydeck.Deck` 对象中设置 `map_style=None` 。



## st.graphviz_chart

使用 dagre-d3 库显示图形。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/graphviz_chart.py#L39) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.graphviz_chart(figure_or_dot, use_container_width=False)  |                                                              |
| Parameters                                                   |                                                              |
| **figure_or_dot** *(graphviz.dot.Graph, graphviz.dot.Digraph, str)* figure_or_dot (graphviz.dot.Graph, graphviz.dot.Digraph, str) | The Graphlib graph object or dot string to display 要显示的 Graphlib 图形对象或点字符串 |
| **use_container_width** *(bool)* 使用容器宽度（布尔值）      | If True, set the chart width to the column width. This takes precedence over the figure's native width value. 如果为真，则将图表宽度设置为列宽。这优先于图形的原始宽度值。 |

**Example**

> ```python
> import streamlit as st
> import graphviz
> 
> # Create a graphlib graph object
> graph = graphviz.Digraph()
> graph.edge('run', 'intr')
> graph.edge('intr', 'runbl')
> graph.edge('runbl', 'run')
> graph.edge('run', 'kernel')
> graph.edge('kernel', 'zombie')
> graph.edge('kernel', 'sleep')
> graph.edge('kernel', 'runmem')
> graph.edge('sleep', 'swap')
> graph.edge('swap', 'runswap')
> graph.edge('runswap', 'new')
> graph.edge('runswap', 'runmem')
> graph.edge('new', 'runmem')
> graph.edge('sleep', 'runmem')
> 
> st.graphviz_chart(graph)
> ```

或者您可以使用 GraphViz 的 Dot 语言从图形中呈现图表：

```python
st.graphviz_chart('''
    digraph {
        run -> intr
        intr -> runbl
        runbl -> run
        run -> kernel
        kernel -> zombie
        kernel -> sleep
        kernel -> runmem
        sleep -> swap
        swap -> runswap
        runswap -> new
        runswap -> runmem
        new -> runmem
        sleep -> runmem
    }
''')
```

![image-20230509233942733](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509233943383-1693233717.png)



## st.map

显示带有点的地图。

这是一个围绕 `st.pydeck_chart` 的包装器，用于在地图上快速创建散点图，具有自动居中和自动缩放功能。

使用此命令时，Mapbox 提供地图瓦片来渲染地图内容。请注意，Mapbox 是第三方产品，其使用受 Mapbox 使用条款的约束。

Mapbox 要求用户注册并提供令牌，然后用户才能请求地图图块。目前，Streamlit 为您提供此令牌，但这可能随时更改。我们强烈建议所有用户创建和使用他们自己的个人 Mapbox 令牌，以避免对他们的体验造成任何干扰。您可以使用 `mapbox.token` 配置选项执行此操作。

要为自己获取令牌，请在 [https://mapbox.com](https://mapbox.com/) 创建一个帐户。有关如何设置配置选项的更多信息，请参阅 https://docs.streamlit.io/library/advanced-features/configuration

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/map.py#L76) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.map(data=None, zoom=None, use_container_width=True) st.map（数据=无，缩放=无，use_container_width=True） |                                                              |
| Parameters                                                   |                                                              |
| **data** *(pandas.DataFrame, pandas.Styler, pyarrow.Table, numpy.ndarray, pyspark.sql.DataFrame, snowflake.snowpark.dataframe.DataFrame, snowflake.snowpark.table.Table, Iterable, dict, or None)* 数据（pandas.DataFrame、pandas.Styler、pyarrow.Table、numpy.ndarray、pyspark.sql.DataFrame、snowflake.snowpark.dataframe.DataFrame、snowflake.snowpark.table.Table、Iterable、dict 或 None） | The data to be plotted. Must have two columns: 要绘制的数据。必须有两列：latitude called 'lat', 'latitude', 'LAT', 'LATITUDE' 纬度称为'lat'，'latitude'，'LAT'，'LATITUDE'longitude called 'lon', 'longitude', 'LON', 'LONGITUDE'. 经度称为“lon”、“longitude”、“LON”、“LONGITUDE”。 |
| **zoom** *(int)*                                             | Zoom level as specified in https://wiki.openstreetmap.org/wiki/Zoom_levels https://wiki.openstreetmap.org/wiki/Zoom_levels 中指定的缩放级别 |
| **use_container_width** *(bool)* 使用容器宽度（布尔值）      | No description                                               |

**Example**

> ```python
> import streamlit as st
> import pandas as pd
> import numpy as np
> 
> df = pd.DataFrame(
>     np.random.randn(1000, 2) / [50, 50] + [37.76, -122.4],
>     columns=['lat', 'lon'])
> 
> st.map(df)
> ```

![image-20230509234058991](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509234100209-78172254.png)



# Input widgets

## st.button

显示按钮微件。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/button.py#L61) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.button(label, key=None, help=None, on_click=None, args=None, kwargs=None, *, type="secondary", disabled=False, use_container_width=False) st.button（label， key=None， help=None， on_click=None， args=None， kwargs=None， *， type=“secondary”， disabled=False， use_container_width=False） |                                                              |
| Parameters                                                   |                                                              |
| **label** *(str)*                                            | A short label explaining to the user what this button is for. The label can optionally contain Markdown and supports the following elements: Bold, Italics, Strikethroughs, Inline Code, and Emojis. 向用户解释此按钮用途的简短标签。标签可以选择包含 Markdown 并支持以下元素：粗体、斜体、删除线、内联代码和表情符号。This also supports: 这也支持：Emoji shortcodes, such as `:+1:` and `:sunglasses:`. For a list of all supported codes, see https://share.streamlit.io/streamlit/emoji-shortcodes. 表情符号短代码，例如 `:+1:` 和 `:sunglasses:` 。有关所有支持的代码的列表，请参阅 https://share.streamlit.io/streamlit/emoji-shortcodes 。LaTeX expressions, by wrapping them in "$" or "$$" (the "$$" must be on their own lines). Supported LaTeX functions are listed at https://katex.org/docs/supported.html. LaTeX 表达式，通过将它们包装在“$”或“$$”中（“$$”必须在它们自己的行上）。支持的 LaTeX 函数列在 https://katex.org/docs/supported.html 中。Colored text, using the syntax `:color[text to be colored]`, where `color` needs to be replaced with any of the following supported colors: blue, green, orange, red, violet. 彩色文本，使用语法 `:color[text to be colored]` ，其中 `color` 需要替换为以下任何受支持的颜色：蓝色、绿色、橙色、红色、紫色。Unsupported elements are unwrapped so only their children (text contents) render. Display unsupported elements as literal characters by backslash-escaping them. E.g. `1\. Not an ordered list`. 不受支持的元素将解开包装，以便仅呈现其子元素（文本内容）。通过反斜杠转义将不支持的元素显示为文字字符。例如 `1\. Not an ordered list` . |
| **key** *(str or int)* 键（STR 或 INT）                      | An optional string or integer to use as the unique key for the widget. If this is omitted, a key will be generated for the widget based on its content. Multiple widgets of the same type may not share the same key. 用作小组件唯一键的可选字符串或整数。如果省略此项，将根据其内容为小部件生成一个键。同一类型的多个小部件不能共享同一个键。 |
| **help** *(str)*                                             | An optional tooltip that gets displayed when the button is hovered over. 将鼠标悬停在按钮上时显示的可选工具提示。 |
| **on_click** *(callable)* on_click（可赎回）                 | An optional callback invoked when this button is clicked. 单击此按钮时调用的可选回调。 |
| **args** *(tuple)*                                           | An optional tuple of args to pass to the callback. 要传递给回调的参数的可选元组。 |
| **kwargs** *(dict)*                                          | An optional dict of kwargs to pass to the callback. 要传递给回调的 kwargs 的可选字典。 |
| **type** *("secondary" or "primary")* 类型（“辅助”或“主要”） | An optional string that specifies the button type. Can be "primary" for a button with additional emphasis or "secondary" for a normal button. This argument can only be supplied by keyword. Defaults to "secondary". 指定按钮类型的可选字符串。对于具有附加强调的按钮，可以是“主要”，对于普通按钮，可以是“次要”。此参数只能由关键字提供。默认为“辅助”。 |
| **disabled** *(bool)*                                        | An optional boolean, which disables the button if set to True. The default is False. This argument can only be supplied by keyword. 一个可选的布尔值，如果设置为 True，则禁用该按钮。默认值为 False。此参数只能由关键字提供。 |
| **use_container_width** *(bool)* use_container_width（布尔值） | An optional boolean, which makes the button stretch its width to match the parent container. 可选的布尔值，它使按钮拉伸其宽度以匹配父容器。 |
| Returns                                                      |                                                              |
| *(bool)*                                                     | True if the button was clicked on the last run of the app, False otherwise. 如果在上次运行应用时单击了该按钮，则为 True，否则为 False。 |

**Example**

> ```python
> import streamlit as st
> 
> if st.button('Say hello'):
>     st.write('Why hello there')
> else:
>     st.write('Goodbye')
> ```

![image-20230510065151360](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510065151942-2010721067.png)

## st.experimental_data_editor

显示数据编辑器微件。

显示数据编辑器小组件，允许您在类似表的 UI 中编辑数据帧和许多其他数据结构。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/data_editor.py#L448) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.experimental_data_editor(data, *, width=None, height=None, use_container_width=False, num_rows="fixed", disabled=False, key=None, on_change=None, args=None, kwargs=None) st.experimental_data_editor（data， *， width=None， height=None， use_container_width=False， num_rows=“fixed”， disabled=False， key=None， on_change=None， args=None， kwargs=None） |                                                              |
| Parameters                                                   |                                                              |
| **data** *(pandas.DataFrame, pandas.Styler, pandas.Index, pyarrow.Table, numpy.ndarray, pyspark.sql.DataFrame, snowflake.snowpark.DataFrame, list, set, tuple, dict, or None)* 数据（熊猫。数据帧，熊猫。斯泰勒，熊猫。索引，皮箭头。Table， numpy.ndarray， pyspark.sql.DataFrame， snowflake.snowpark.DataFrame， list， set， tuple， dict， or None） | The data to edit in the data editor. 要在数据编辑器中编辑的数据。 |
| **width** *(int or None)* 宽度（整数或无）                   | Desired width of the data editor expressed in pixels. If None, the width will be automatically determined. 数据编辑器的所需宽度（以像素表示）。如果为“无”，将自动确定宽度。 |
| **height** *(int or None)* 高度（整数或无）                  | Desired height of the data editor expressed in pixels. If None, the height will be automatically determined. 数据编辑器的所需高度，以像素表示。如果为“无”，将自动确定高度。 |
| **use_container_width** *(bool)* use_container_width（布尔值） | If True, set the data editor width to the width of the parent container. This takes precedence over the width argument. Defaults to False. 如果为 True，则将数据编辑器宽度设置为父容器的宽度。这优先于宽度参数。默认为 False。 |
| **num_rows** *("fixed" or "dynamic")* num_rows（“固定”或“动态”） | Specifies if the user can add and delete rows in the data editor. If "fixed", the user cannot add or delete rows. If "dynamic", the user can add and delete rows in the data editor, but column sorting is disabled. Defaults to "fixed". 指定用户是否可以在数据编辑器中添加和删除行。如果“固定”，则用户无法添加或删除行。如果是“动态”，用户可以在数据编辑器中添加和删除行，但禁用列排序。默认为“固定”。 |
| **disabled** *(bool)*                                        | An optional boolean which, if True, disables the data editor and prevents any edits. Defaults to False. This argument can only be supplied by keyword. 一个可选的布尔值，如果为 True，则禁用数据编辑器并阻止任何编辑。默认为 False。此参数只能由关键字提供。 |
| **key** *(str)*                                              | An optional string to use as the unique key for this widget. If this is omitted, a key will be generated for the widget based on its content. Multiple widgets of the same type may not share the same key. 用作此小组件的唯一键的可选字符串。如果省略此项，将根据其内容为小部件生成一个键。同一类型的多个小部件不能共享同一个键。 |
| **on_change** *(callable)*                                   | An optional callback invoked when this data_editor's value changes. 当此data_editor的值更改时调用的可选回调。 |
| **args** *(tuple)*                                           | An optional tuple of args to pass to the callback. 要传递给回调的参数的可选元组。 |
| **kwargs** *(dict)*                                          | An optional dict of kwargs to pass to the callback. 要传递给回调的 kwargs 的可选字典。 |
| Returns                                                      |                                                              |
| *(pd.DataFrame, pd.Styler, pyarrow.Table, np.ndarray, list, set, tuple, or dict.) （PD.数据帧，pd。斯泰勒，皮亚罗。表、np.ndarray、list、set、tuple 或字典。* | The edited data. The edited data is returned in its original data type if it corresponds to any of the supported return types. All other data types are returned as a `pd.DataFrame`. 编辑后的数据。如果编辑的数据对应于任何受支持的返回类型，则以原始数据类型返回。所有其他数据类型都以 `pd.DataFrame` 的形式返回。 |

**Examples**

> ```python
> import streamlit as st
> import pandas as pd
> 
> df = pd.DataFrame(
>     [
>        {"command": "st.selectbox", "rating": 4, "is_widget": True},
>        {"command": "st.balloons", "rating": 5, "is_widget": False},
>        {"command": "st.time_input", "rating": 3, "is_widget": True},
>    ]
> )
> edited_df = st.experimental_data_editor(df)
> 
> favorite_command = edited_df.loc[edited_df["rating"].idxmax()]["command"]
> st.markdown(f"Your favorite command is **{favorite_command}** 🎈")
> ```

![image-20230510065306884](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510065306813-966221027.png)

您还可以通过将 `num_rows` 设置为“动态”来允许用户添加和删除行：

```python
import streamlit as st
import pandas as pd

df = pd.DataFrame(
    [
       {"command": "st.selectbox", "rating": 4, "is_widget": True},
       {"command": "st.balloons", "rating": 5, "is_widget": False},
       {"command": "st.time_input", "rating": 3, "is_widget": True},
   ]
)
edited_df = st.experimental_data_editor(df, num_rows="dynamic")

favorite_command = edited_df.loc[edited_df["rating"].idxmax()]["command"]
st.markdown(f"Your favorite command is **{favorite_command}** 🎈")
```

![image-20230510065330581](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510065330234-2136151137.png)



## st.download_button

显示下载按钮小部件。

当你希望为用户提供一种直接从你的应用下载文件的方法时，这非常有用。

请注意，当用户连接时，要下载的数据存储在内存中，因此最好将文件大小保持在几百兆字节以下以节省内存。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/button.py#L169) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.download_button(label, data, file_name=None, mime=None, key=None, help=None, on_click=None, args=None, kwargs=None, *, disabled=False, use_container_width=False) st.download_button（label， data， file_name=None， mime=None， key=None， help=None， on_click=None， args=None， kwargs=None， *， disabled=False， use_container_width=False） |                                                              |
| Parameters                                                   |                                                              |
| **label** *(str)*                                            | A short label explaining to the user what this button is for. The label can optionally contain Markdown and supports the following elements: Bold, Italics, Strikethroughs, Inline Code, and Emojis. 向用户解释此按钮用途的简短标签。标签可以选择包含 Markdown 并支持以下元素：粗体、斜体、删除线、内联代码和表情符号。This also supports: 这也支持：Emoji shortcodes, such as `:+1:` and `:sunglasses:`. For a list of all supported codes, see https://share.streamlit.io/streamlit/emoji-shortcodes. 表情符号短代码，例如 `:+1:` 和 `:sunglasses:` 。有关所有支持的代码的列表，请参阅 https://share.streamlit.io/streamlit/emoji-shortcodes 。LaTeX expressions, by wrapping them in "$" or "$$" (the "$$" must be on their own lines). Supported LaTeX functions are listed at https://katex.org/docs/supported.html. LaTeX 表达式，通过将它们包装在“$”或“$$”中（“$$”必须在它们自己的行上）。支持的 LaTeX 函数列在 https://katex.org/docs/supported.html 中。Colored text, using the syntax `:color[text to be colored]`, where `color` needs to be replaced with any of the following supported colors: blue, green, orange, red, violet. 彩色文本，使用语法 `:color[text to be colored]` ，其中 `color` 需要替换为以下任何受支持的颜色：蓝色、绿色、橙色、红色、紫色。Unsupported elements are unwrapped so only their children (text contents) render. Display unsupported elements as literal characters by backslash-escaping them. E.g. `1\. Not an ordered list`. 不受支持的元素将解开包装，以便仅呈现其子元素（文本内容）。通过反斜杠转义将不支持的元素显示为文字字符。例如 `1\. Not an ordered list` . |
| **data** *(str or bytes or file)* 数据（str 或字节或文件）   | The contents of the file to be downloaded. See example below for caching techniques to avoid recomputing this data unnecessarily. 要下载的文件的内容。有关缓存技术，请参阅下面的示例，以避免不必要地重新计算此数据。 |
| **file_name** *(str)*                                        | An optional string to use as the name of the file to be downloaded, such as 'my_file.csv'. If not specified, the name will be automatically generated. 用作要下载的文件名称的可选字符串，例如“my_file.csv”。如果未指定，将自动生成名称。 |
| **mime** *(str or None)* 哑剧（str 或 none）                 | The MIME type of the data. If None, defaults to "text/plain" (if data is of type *str* or is a textual *file*) or "application/octet-stream" (if data is of type *bytes* or is a binary *file*). 数据的 MIME 类型。如果为 None，则默认为“text/plain”（如果数据属于 str 类型或文本文件）或“application/octet-stream”（如果数据为字节类型或二进制文件）。 |
| **key** *(str or int)* 键（STR 或 INT）                      | An optional string or integer to use as the unique key for the widget. If this is omitted, a key will be generated for the widget based on its content. Multiple widgets of the same type may not share the same key. 用作小组件唯一键的可选字符串或整数。如果省略此项，将根据其内容为小部件生成一个键。同一类型的多个小部件不能共享同一个键。 |
| **help** *(str)*                                             | An optional tooltip that gets displayed when the button is hovered over. 将鼠标悬停在按钮上时显示的可选工具提示。 |
| **on_click** *(callable)*                                    | An optional callback invoked when this button is clicked. 单击此按钮时调用的可选回调。 |
| **args** *(tuple)*                                           | An optional tuple of args to pass to the callback. 要传递给回调的参数的可选元组。 |
| **kwargs** *(dict)*                                          | An optional dict of kwargs to pass to the callback. 要传递给回调的 kwargs 的可选字典。 |
| **disabled** *(bool)*                                        | An optional boolean, which disables the download button if set to True. The default is False. This argument can only be supplied by keyword. 可选的布尔值，如果设置为 True，则禁用下载按钮。默认值为 False。此参数只能由关键字提供。 |
| **use_container_width** *(bool)* use_container_width（布尔值） | An optional boolean, which makes the button stretch its width to match the parent container. 可选的布尔值，它使按钮拉伸其宽度以匹配父容器。 |
| Returns                                                      |                                                              |
| *(bool)*                                                     | True if the button was clicked on the last run of the app, False otherwise. 如果在上次运行应用时单击了该按钮，则为 True，否则为 False。 |

**Examples**

将大型数据帧下载为 CSV：

```python
import streamlit as st

@st.cache
def convert_df(df):
    # IMPORTANT: Cache the conversion to prevent computation on every rerun
    return df.to_csv().encode('utf-8')

csv = convert_df(my_large_df)

st.download_button(
    label="Download data as CSV",
    data=csv,
    file_name='large_df.csv',
    mime='text/csv',
)
```

将字符串下载为文件：

```python
import streamlit as st

text_contents = '''This is some text'''
st.download_button('Download some text', text_contents)
```

下载二进制文件：

```python
import streamlit as st

binary_contents = b'example content'
# Defaults to 'application/octet-stream'
st.download_button('Download binary file', binary_contents)
```

下载图像：

```python
import streamlit as st

with open("flower.png", "rb") as file:
    btn = st.download_button(
            label="Download image",
            data=file,
            file_name="flower.png",
            mime="image/png"
          )
```

![image-20230510065453016](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510065452711-410552723.png)



## st.checkbox

显示复选框微件。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/checkbox.py#L52) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.checkbox(label, value=False, key=None, help=None, on_change=None, args=None, kwargs=None, *, disabled=False, label_visibility="visible") st.checkbox（label， value=False， key=None， help=None， on_change=None， args=None， kwargs=None， *， disabled=False， label_visibility=“visible”） |                                                              |
| Parameters                                                   |                                                              |
| **label** *(str)*                                            | A short label explaining to the user what this checkbox is for. The label can optionally contain Markdown and supports the following elements: Bold, Italics, Strikethroughs, Inline Code, Emojis, and Links. 向用户解释此复选框的用途的简短标签。标签可以选择包含 Markdown 并支持以下元素：粗体、斜体、删除线、内联代码、表情符号和链接。This also supports: 这也支持：Emoji shortcodes, such as `:+1:` and `:sunglasses:`. For a list of all supported codes, see https://share.streamlit.io/streamlit/emoji-shortcodes. 表情符号短代码，例如 `:+1:` 和 `:sunglasses:` 。有关所有支持的代码的列表，请参阅 https://share.streamlit.io/streamlit/emoji-shortcodes 。LaTeX expressions, by wrapping them in "$" or "$$" (the "$$" must be on their own lines). Supported LaTeX functions are listed at https://katex.org/docs/supported.html. LaTeX 表达式，通过将它们包装在“$”或“$$”中（“$$”必须在它们自己的行上）。支持的 LaTeX 函数列在 https://katex.org/docs/supported.html 中。Colored text, using the syntax `:color[text to be colored]`, where `color` needs to be replaced with any of the following supported colors: blue, green, orange, red, violet. 彩色文本，使用语法 `:color[text to be colored]` ，其中 `color` 需要替换为以下任何受支持的颜色：蓝色、绿色、橙色、红色、紫色。Unsupported elements are unwrapped so only their children (text contents) render. Display unsupported elements as literal characters by backslash-escaping them. E.g. `1\. Not an ordered list`. 不受支持的元素将解开包装，以便仅呈现其子元素（文本内容）。通过反斜杠转义将不支持的元素显示为文字字符。例如 `1\. Not an ordered list` . |
| **value** *(bool)*                                           | Preselect the checkbox when it first renders. This will be cast to bool internally. 首次渲染时预先选中该复选框。这将在内部转换为布尔值。 |
| **key** *(str or int)* 键（STR 或 INT）                      | An optional string or integer to use as the unique key for the widget. If this is omitted, a key will be generated for the widget based on its content. Multiple widgets of the same type may not share the same key. 用作小组件唯一键的可选字符串或整数。如果省略此项，将根据其内容为小部件生成一个键。同一类型的多个小部件不能共享同一个键。 |
| **help** *(str)*                                             | An optional tooltip that gets displayed next to the checkbox. 显示在复选框旁边的可选工具提示。 |
| **on_change** *(callable)* on_change（可赎回）               | An optional callback invoked when this checkbox's value changes. 当此复选框的值更改时调用的可选回调。 |
| **args** *(tuple)*                                           | An optional tuple of args to pass to the callback. 要传递给回调的参数的可选元组。 |
| **kwargs** *(dict)*                                          | An optional dict of kwargs to pass to the callback. 要传递给回调的 kwargs 的可选字典。 |
| **disabled** *(bool)*                                        | An optional boolean, which disables the checkbox if set to True. The default is False. This argument can only be supplied by keyword. 一个可选的布尔值，如果设置为 True，则禁用该复选框。默认值为 False。此参数只能由关键字提供。 |
| **label_visibility** *("visible" or "hidden" or "collapsed")* label_visibility（“可见”或“隐藏”或“折叠”） | The visibility of the label. If "hidden", the label doesn't show but there is still empty space for it (equivalent to label=""). If "collapsed", both the label and the space are removed. Default is "visible". This argument can only be supplied by keyword. 标签的可见性。如果为“隐藏”，则标签不显示，但仍有空白空间（相当于 label=“”）。如果“折叠”，则标签和空格都将被删除。默认值为“可见”。此参数只能由关键字提供。 |
| Returns                                                      |                                                              |
| *(bool)*                                                     | Whether or not the checkbox is checked. 是否选中该复选框。   |

#### Example

> ```python
> import streamlit as st
> 
> agree = st.checkbox('I agree')
> 
> if agree:
>     st.write('Great!')
> ```

![image-20230510065525984](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510065525621-2071846237.png)



## st.radio

显示单选按钮微件。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/radio.py#L75) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.radio(label, options, index=0, format_func=special_internal_function, key=None, help=None, on_change=None, args=None, kwargs=None, *, disabled=False, horizontal=False, label_visibility="visible") st.radio（label， options， index=0， format_func=special_internal_function， key=None， help=None， on_change=None， args=None， kwargs=None， *， disabled=False， horizontal=False， label_visibility=“visible”） |                                                              |
| Parameters                                                   |                                                              |
| **label** *(str)*                                            | A short label explaining to the user what this radio group is for. The label can optionally contain Markdown and supports the following elements: Bold, Italics, Strikethroughs, Inline Code, Emojis, and Links. 向用户解释此单选组用途的简短标签。标签可以选择包含 Markdown 并支持以下元素：粗体、斜体、删除线、内联代码、表情符号和链接。This also supports: 这也支持：Emoji shortcodes, such as `:+1:` and `:sunglasses:`. For a list of all supported codes, see https://share.streamlit.io/streamlit/emoji-shortcodes. 表情符号短代码，例如 `:+1:` 和 `:sunglasses:` 。有关所有支持的代码的列表，请参阅 https://share.streamlit.io/streamlit/emoji-shortcodes 。LaTeX expressions, by wrapping them in "$" or "$$" (the "$$" must be on their own lines). Supported LaTeX functions are listed at https://katex.org/docs/supported.html. LaTeX 表达式，通过将它们包装在“$”或“$$”中（“$$”必须在它们自己的行上）。支持的 LaTeX 函数列在 https://katex.org/docs/supported.html 中。Colored text, using the syntax `:color[text to be colored]`, where `color` needs to be replaced with any of the following supported colors: blue, green, orange, red, violet. 彩色文本，使用语法 `:color[text to be colored]` ，其中 `color` 需要替换为以下任何受支持的颜色：蓝色、绿色、橙色、红色、紫色。Unsupported elements are unwrapped so only their children (text contents) render. Display unsupported elements as literal characters by backslash-escaping them. E.g. `1\. Not an ordered list`. 不受支持的元素将解开包装，以便仅呈现其子元素（文本内容）。通过反斜杠转义将不支持的元素显示为文字字符。例如 `1\. Not an ordered list` .For accessibility reasons, you should never set an empty label (label="") but hide it with label_visibility if needed. In the future, we may disallow empty labels by raising an exception. 出于辅助功能原因，切勿设置空标签 （label=“”），而应在需要时使用 label_visibility 将其隐藏。将来，我们可能会通过引发异常来禁止空标签。 |
| **options** *(Sequence, numpy.ndarray, pandas.Series, pandas.DataFrame, or pandas.Index)* 选项（Sequence， numpy.ndarray， pandas.系列，熊猫。数据帧或熊猫。索引） | Labels for the radio options. This will be cast to str internally by default. For pandas.DataFrame, the first column is selected. 单选选项的标签。默认情况下，这将在内部强制转换为 str。对于熊猫。数据帧，则选择第一列。 |
| **index** *(int)*                                            | The index of the preselected option on first render. 首次呈现时预选选项的索引。 |
| **format_func** *(function)* format_func（功能）             | Function to modify the display of radio options. It receives the raw option as an argument and should output the label to be shown for that option. This has no impact on the return value of the radio. 修改收音机选项显示的功能。它接收原始选项作为参数，并应输出要为该选项显示的标签。这对无线电的返回值没有影响。 |
| **key** *(str or int)* 键（STR 或 INT）                      | An optional string or integer to use as the unique key for the widget. If this is omitted, a key will be generated for the widget based on its content. Multiple widgets of the same type may not share the same key. 用作小组件唯一键的可选字符串或整数。如果省略此项，将根据其内容为小部件生成一个键。同一类型的多个小部件不能共享同一个键。 |
| **help** *(str)*                                             | An optional tooltip that gets displayed next to the radio. 显示在收音机旁边的可选工具提示。 |
| **on_change** *(callable)* on_change（可赎回）               | An optional callback invoked when this radio's value changes. 当此无线电的值更改时调用的可选回调。 |
| **args** *(tuple)*                                           | An optional tuple of args to pass to the callback. 要传递给回调的参数的可选元组。 |
| **kwargs** *(dict)*                                          | An optional dict of kwargs to pass to the callback. 要传递给回调的 kwargs 的可选字典。 |
| **disabled** *(bool)*                                        | An optional boolean, which disables the radio button if set to True. The default is False. This argument can only be supplied by keyword. 一个可选的布尔值，如果设置为 True，则禁用单选按钮。默认值为 False。此参数只能由关键字提供。 |
| **horizontal** *(bool)*                                      | An optional boolean, which orients the radio group horizontally. The default is false (vertical buttons). This argument can only be supplied by keyword. 一个可选的布尔值，用于水平定向无线电组。默认值为 false（垂直按钮）。此参数只能由关键字提供。 |
| **label_visibility** *("visible" or "hidden" or "collapsed")* label_visibility（“可见”或“隐藏”或“折叠”） | The visibility of the label. If "hidden", the label doesn't show but there is still empty space for it above the widget (equivalent to label=""). If "collapsed", both the label and the space are removed. Default is "visible". This argument can only be supplied by keyword. 标签的可见性。如果为“隐藏”，则标签不显示，但小部件上方仍有空白空间（相当于 label=“”）。如果“折叠”，则标签和空格都将被删除。默认值为“可见”。此参数只能由关键字提供。 |
| Returns                                                      |                                                              |
| *(any)*                                                      | The selected option. 所选选项。                              |

#### Example

> ```python
> import streamlit as st
> 
> genre = st.radio(
>     "What\'s your favorite movie genre",
>     ('Comedy', 'Drama', 'Documentary'))
> 
> if genre == 'Comedy':
>     st.write('You selected comedy.')
> else:
>     st.write("You didn\'t select comedy.")
> ```

小组件可以使用 `label_visibility` 参数自定义隐藏其标签的方式。如果为“隐藏”，则标签不显示，但小部件上方仍有空白空间（相当于 `label=""` ）。如果“折叠”，则标签和空格都将被删除。默认值为“可见”。也可以使用 `disabled` 参数禁用单选按钮，并使用 `horizontal` 参数水平定向：

```python
import streamlit as st

# Store the initial value of widgets in session state
if "visibility" not in st.session_state:
    st.session_state.visibility = "visible"
    st.session_state.disabled = False
    st.session_state.horizontal = False

col1, col2 = st.columns(2)

with col1:
    st.checkbox("Disable radio widget", key="disabled")
    st.checkbox("Orient radio options horizontally", key="horizontal")

with col2:
    st.radio(
        "Set label visibility 👇",
        ["visible", "hidden", "collapsed"],
        key="visibility",
        label_visibility=st.session_state.visibility,
        disabled=st.session_state.disabled,
        horizontal=st.session_state.horizontal,
    )
```

![image-20230510065616027](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510065615698-1767366796.png)



## st.selectbox

显示选择微件。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/selectbox.py#L71) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.selectbox(label, options, index=0, format_func=special_internal_function, key=None, help=None, on_change=None, args=None, kwargs=None, *, disabled=False, label_visibility="visible") st.selectbox（label， options， index=0， format_func=special_internal_function， key=None， help=None， on_change=None， args=None， kwargs=None， *， disabled=False， label_visibility=“visible”） |                                                              |
| Parameters                                                   |                                                              |
| **label** *(str)*                                            | A short label explaining to the user what this select widget is for. The label can optionally contain Markdown and supports the following elements: Bold, Italics, Strikethroughs, Inline Code, Emojis, and Links. 向用户解释此选择小部件的用途的简短标签。标签可以选择包含 Markdown 并支持以下元素：粗体、斜体、删除线、内联代码、表情符号和链接。This also supports: 这也支持：Emoji shortcodes, such as `:+1:` and `:sunglasses:`. For a list of all supported codes, see https://share.streamlit.io/streamlit/emoji-shortcodes. 表情符号短代码，例如 `:+1:` 和 `:sunglasses:` 。有关所有支持的代码的列表，请参阅 https://share.streamlit.io/streamlit/emoji-shortcodes 。LaTeX expressions, by wrapping them in "$" or "$$" (the "$$" must be on their own lines). Supported LaTeX functions are listed at https://katex.org/docs/supported.html. LaTeX 表达式，通过将它们包装在“$”或“$$”中（“$$”必须在它们自己的行上）。支持的 LaTeX 函数列在 https://katex.org/docs/supported.html 中。Colored text, using the syntax `:color[text to be colored]`, where `color` needs to be replaced with any of the following supported colors: blue, green, orange, red, violet. 彩色文本，使用语法 `:color[text to be colored]` ，其中 `color` 需要替换为以下任何受支持的颜色：蓝色、绿色、橙色、红色、紫色。Unsupported elements are unwrapped so only their children (text contents) render. Display unsupported elements as literal characters by backslash-escaping them. E.g. `1\. Not an ordered list`. 不受支持的元素将解开包装，以便仅呈现其子元素（文本内容）。通过反斜杠转义将不支持的元素显示为文字字符。例如 `1\. Not an ordered list` .For accessibility reasons, you should never set an empty label (label="") but hide it with label_visibility if needed. In the future, we may disallow empty labels by raising an exception. 出于辅助功能原因，切勿设置空标签 （label=“”），而应在需要时使用 label_visibility 将其隐藏。将来，我们可能会通过引发异常来禁止空标签。 |
| **options** *(Sequence, numpy.ndarray, pandas.Series, pandas.DataFrame, or pandas.Index)* 选项（Sequence， numpy.ndarray， pandas.系列，熊猫。数据帧或熊猫。索引） | Labels for the select options. This will be cast to str internally by default. For pandas.DataFrame, the first column is selected. 选择选项的标签。默认情况下，这将在内部强制转换为 str。对于熊猫。数据帧，则选择第一列。 |
| **index** *(int)*                                            | The index of the preselected option on first render. 首次呈现时预选选项的索引。 |
| **format_func** *(function)* format_func（功能）             | Function to modify the display of the labels. It receives the option as an argument and its output will be cast to str. 修改标签显示的功能。它接收选项作为参数，其输出将被转换为 str。 |
| **key** *(str or int)* 键（STR 或 INT）                      | An optional string or integer to use as the unique key for the widget. If this is omitted, a key will be generated for the widget based on its content. Multiple widgets of the same type may not share the same key. 用作小组件唯一键的可选字符串或整数。如果省略此项，将根据其内容为小部件生成一个键。同一类型的多个小部件不能共享同一个键。 |
| **help** *(str)*                                             | An optional tooltip that gets displayed next to the selectbox. 显示在选择框旁边的可选工具提示。 |
| **on_change** *(callable)* on_change（可赎回）               | An optional callback invoked when this selectbox's value changes. 当此选择框的值更改时调用的可选回调。 |
| **args** *(tuple)*                                           | An optional tuple of args to pass to the callback. 要传递给回调的参数的可选元组。 |
| **kwargs** *(dict)*                                          | An optional dict of kwargs to pass to the callback. 要传递给回调的 kwargs 的可选字典。 |
| **disabled** *(bool)*                                        | An optional boolean, which disables the selectbox if set to True. The default is False. This argument can only be supplied by keyword. 一个可选的布尔值，如果设置为 True，则禁用选择框。默认值为 False。此参数只能由关键字提供。 |
| **label_visibility** *("visible" or "hidden" or "collapsed")* label_visibility（“可见”或“隐藏”或“折叠”） | The visibility of the label. If "hidden", the label doesn't show but there is still empty space for it above the widget (equivalent to label=""). If "collapsed", both the label and the space are removed. Default is "visible". This argument can only be supplied by keyword. 标签的可见性。如果为“隐藏”，则标签不显示，但小部件上方仍有空白空间（相当于 label=“”）。如果“折叠”，则标签和空格都将被删除。默认值为“可见”。此参数只能由关键字提供。 |
| Returns                                                      |                                                              |
| *(any)*                                                      | The selected option 所选选项                                 |

#### Example

> ```python
> import streamlit as st
> 
> option = st.selectbox(
>     'How would you like to be contacted?',
>     ('Email', 'Home phone', 'Mobile phone'))
> 
> st.write('You selected:', option)
> ```

![image-20230510065702136](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510065701763-1144694060.png)

选择小组件可以使用 `label_visibility` 参数自定义隐藏其标签的方式。如果为“隐藏”，则标签不显示，但小部件上方仍有空白空间（相当于 `label=""` ）。如果“折叠”，则标签和空格都将被删除。默认值为“可见”。也可以使用 `disabled` 参数禁用选择小部件：

```python
import streamlit as st

# Store the initial value of widgets in session state
if "visibility" not in st.session_state:
    st.session_state.visibility = "visible"
    st.session_state.disabled = False

col1, col2 = st.columns(2)

with col1:
    st.checkbox("Disable selectbox widget", key="disabled")
    st.radio(
        "Set selectbox label visibility 👉",
        key="visibility",
        options=["visible", "hidden", "collapsed"],
    )

with col2:
    option = st.selectbox(
        "How would you like to be contacted?",
        ("Email", "Home phone", "Mobile phone"),
        label_visibility=st.session_state.visibility,
        disabled=st.session_state.disabled,
    )
```

![image-20230510065723663](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510065723424-1266313463.png)



## st.multiselect

显示多选微件。

多选构件开始时为空。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/multiselect.py#L145) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.multiselect(label, options, default=None, format_func=special_internal_function, key=None, help=None, on_change=None, args=None, kwargs=None, *, disabled=False, label_visibility="visible", max_selections=None) st.multiselect（label， options， default=none， format_func=special_internal_function， key=None， help=None， on_change=None， args=None， kwargs=None， *， disabled=False， label_visibility=“visible”， max_selections=None） |                                                              |
| Parameters                                                   |                                                              |
| **label** *(str)*                                            | A short label explaining to the user what this select widget is for. The label can optionally contain Markdown and supports the following elements: Bold, Italics, Strikethroughs, Inline Code, Emojis, and Links. 向用户解释此选择小部件的用途的简短标签。标签可以选择包含 Markdown 并支持以下元素：粗体、斜体、删除线、内联代码、表情符号和链接。This also supports: 这也支持：Emoji shortcodes, such as `:+1:` and `:sunglasses:`. For a list of all supported codes, see https://share.streamlit.io/streamlit/emoji-shortcodes. 表情符号短代码，例如 `:+1:` 和 `:sunglasses:` 。有关所有支持的代码的列表，请参阅 https://share.streamlit.io/streamlit/emoji-shortcodes 。LaTeX expressions, by wrapping them in "$" or "$$" (the "$$" must be on their own lines). Supported LaTeX functions are listed at https://katex.org/docs/supported.html. LaTeX 表达式，通过将它们包装在“$”或“$$”中（“$$”必须在它们自己的行上）。支持的 LaTeX 函数列在 https://katex.org/docs/supported.html 中。Colored text, using the syntax `:color[text to be colored]`, where `color` needs to be replaced with any of the following supported colors: blue, green, orange, red, violet. 彩色文本，使用语法 `:color[text to be colored]` ，其中 `color` 需要替换为以下任何受支持的颜色：蓝色、绿色、橙色、红色、紫色。Unsupported elements are unwrapped so only their children (text contents) render. Display unsupported elements as literal characters by backslash-escaping them. E.g. `1\. Not an ordered list`. 不受支持的元素将解开包装，以便仅呈现其子元素（文本内容）。通过反斜杠转义将不支持的元素显示为文字字符。例如 `1\. Not an ordered list` .For accessibility reasons, you should never set an empty label (label="") but hide it with label_visibility if needed. In the future, we may disallow empty labels by raising an exception. 出于辅助功能原因，切勿设置空标签 （label=“”），而应在需要时使用 label_visibility 将其隐藏。将来，我们可能会通过引发异常来禁止空标签。 |
| **options** *(Sequence[V], numpy.ndarray, pandas.Series, pandas.DataFrame, or pandas.Index)* 选项（Sequence[V]， numpy.ndarray， pandas.系列，熊猫。数据帧或熊猫。索引） | Labels for the select options. This will be cast to str internally by default. For pandas.DataFrame, the first column is selected. 选择选项的标签。默认情况下，这将在内部强制转换为 str。对于熊猫。数据帧，则选择第一列。 |
| **default** *([V], V, or None)* 默认值（[V]、V 或无）        | List of default values. Can also be a single value. 默认值列表。也可以是单个值。 |
| **format_func** *(function)*                                 | Function to modify the display of selectbox options. It receives the raw option as an argument and should output the label to be shown for that option. This has no impact on the return value of the multiselect. 修改选择框选项显示的功能。它接收原始选项作为参数，并应输出要为该选项显示的标签。这对多选的返回值没有影响。 |
| **key** *(str or int)* 键（STR 或 INT）                      | An optional string or integer to use as the unique key for the widget. If this is omitted, a key will be generated for the widget based on its content. Multiple widgets of the same type may not share the same key. 用作小组件唯一键的可选字符串或整数。如果省略此项，将根据其内容为小部件生成一个键。同一类型的多个小部件不能共享同一个键。 |
| **help** *(str)*                                             | An optional tooltip that gets displayed next to the multiselect. 显示在多选旁边的可选工具提示。 |
| **on_change** *(callable)*                                   | An optional callback invoked when this multiselect's value changes. 当此多重选择的值更改时调用的可选回调。 |
| **args** *(tuple)*                                           | An optional tuple of args to pass to the callback. 要传递给回调的参数的可选元组。 |
| **kwargs** *(dict)*                                          | An optional dict of kwargs to pass to the callback. 要传递给回调的 kwargs 的可选字典。 |
| **disabled** *(bool)*                                        | An optional boolean, which disables the multiselect widget if set to True. The default is False. This argument can only be supplied by keyword. 一个可选的布尔值，如果设置为 True，则禁用多选构件。默认值为 False。此参数只能由关键字提供。 |
| **label_visibility** *("visible" or "hidden" or "collapsed")* label_visibility（“可见”或“隐藏”或“折叠”） | The visibility of the label. If "hidden", the label doesn't show but there is still empty space for it above the widget (equivalent to label=""). If "collapsed", both the label and the space are removed. Default is "visible". This argument can only be supplied by keyword. 标签的可见性。如果为“隐藏”，则标签不显示，但小部件上方仍有空白空间（相当于 label=“”）。如果“折叠”，则标签和空格都将被删除。默认值为“可见”。此参数只能由关键字提供。 |
| **max_selections** *(int)*                                   | The max selections that can be selected at a time. This argument can only be supplied by keyword. 一次可以选择的最大选择数。此参数只能由关键字提供。 |
| Returns                                                      |                                                              |
| *(list)*                                                     | A list with the selected options 包含所选选项的列表          |

#### Example

> ```python
> import streamlit as st
> 
> options = st.multiselect(
>     'What are your favorite colors',
>     ['Green', 'Yellow', 'Red', 'Blue'],
>     ['Yellow', 'Red'])
> 
> st.write('You selected:', options)
> ```

![image-20230510065806998](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510065806630-1873743731.png)



## st.slider

显示滑块微件。

这支持 int、float、date、time 和 datetime 类型。

这还允许您通过将双元素元组或列表作为值传递来呈现范围滑块。

st.slider 和 st.select_slider 之间的区别在于，滑块只接受数字或日期/时间数据，并将范围作为输入，而 select_slider 接受任何数据类型并采用一组可迭代的选项。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/slider.py#L171) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.slider(label, min_value=None, max_value=None, value=None, step=None, format=None, key=None, help=None, on_change=None, args=None, kwargs=None, *, disabled=False, label_visibility="visible") st.slider（label， min_value=无， max_value=无， 值=无， 步骤=无， 格式=无， 键=无， 帮助=无， on_change=无， 参数=无， kwargs=无， *， 禁用=假， label_visibility=“可见”） |                                                              |
| Parameters                                                   |                                                              |
| **label** *(str)*                                            | A short label explaining to the user what this slider is for. The label can optionally contain Markdown and supports the following elements: Bold, Italics, Strikethroughs, Inline Code, Emojis, and Links. 向用户解释此滑块用途的简短标签。标签可以选择包含 Markdown 并支持以下元素：粗体、斜体、删除线、内联代码、表情符号和链接。This also supports: 这也支持：Emoji shortcodes, such as `:+1:` and `:sunglasses:`. For a list of all supported codes, see https://share.streamlit.io/streamlit/emoji-shortcodes. 表情符号短代码，例如 `:+1:` 和 `:sunglasses:` 。有关所有支持的代码的列表，请参阅 https://share.streamlit.io/streamlit/emoji-shortcodes 。LaTeX expressions, by wrapping them in "$" or "$$" (the "$$" must be on their own lines). Supported LaTeX functions are listed at https://katex.org/docs/supported.html. LaTeX 表达式，通过将它们包装在“$”或“$$”中（“$$”必须在它们自己的行上）。支持的 LaTeX 函数列在 https://katex.org/docs/supported.html 中。Colored text, using the syntax `:color[text to be colored]`, where `color` needs to be replaced with any of the following supported colors: blue, green, orange, red, violet. 彩色文本，使用语法 `:color[text to be colored]` ，其中 `color` 需要替换为以下任何受支持的颜色：蓝色、绿色、橙色、红色、紫色。Unsupported elements are unwrapped so only their children (text contents) render. Display unsupported elements as literal characters by backslash-escaping them. E.g. `1\. Not an ordered list`. 不受支持的元素将解开包装，以便仅呈现其子元素（文本内容）。通过反斜杠转义将不支持的元素显示为文字字符。例如 `1\. Not an ordered list` .For accessibility reasons, you should never set an empty label (label="") but hide it with label_visibility if needed. In the future, we may disallow empty labels by raising an exception. 出于辅助功能原因，切勿设置空标签 （label=“”），而应在需要时使用 label_visibility 将其隐藏。将来，我们可能会通过引发异常来禁止空标签。 |
| **min_value** *(a supported type or None)* min_value（支持的类型或无） | The minimum permitted value. Defaults to 0 if the value is an int, 0.0 if a float, value - timedelta(days=14) if a date/datetime, time.min if a time 允许的最小值。如果值为 int，则默认为 0，如果浮点数，则默认为 0.0，值 - timedelta（days=14） 如果是日期/日期时间，则为 time.min |
| **max_value** *(a supported type or None)* max_value（支持的类型或无） | The maximum permitted value. Defaults to 100 if the value is an int, 1.0 if a float, value + timedelta(days=14) if a date/datetime, time.max if a time 允许的最大值。如果值为 int，则默认为 100，如果浮点数，则默认为 1.0，如果为日期/日期时间，则值 + timedelta（days=14），如果是时间.max则为 |
| **value** *(a supported type or a tuple/list of supported types or None)* 值（支持的类型或元组/支持类型的列表或无） | The value of the slider when it first renders. If a tuple/list of two values is passed here, then a range slider with those lower and upper bounds is rendered. For example, if set to (1, 10) the slider will have a selectable range between 1 and 10. Defaults to min_value. 滑块首次呈现时的值。如果在此处传递包含两个值的元组/列表，则会呈现具有这些下限和上限的范围滑块。例如，如果设置为 （1， 10），则滑块将具有介于 1 和 10 之间的可选范围。默认值为min_value。 |
| **step** *(int/float/timedelta or None)* 步长（整数/浮点数/时间增量或无） | The stepping interval. Defaults to 1 if the value is an int, 0.01 if a float, timedelta(days=1) if a date/datetime, timedelta(minutes=15) if a time (or if max_value - min_value < 1 day) 步进间隔。如果值为 int，则默认为 1，如果浮点数，则默认为 0.01，如果日期/日期时间，则默认为 timedelta（days=1），如果为时间（或如果 max_value - min_value < 1 天），则默认为 timedelta（分钟=15） |
| **format** *(str or None)* 格式（str 或 none）               | A printf-style format string controlling how the interface should display numbers. This does not impact the return value. Formatter for int/float supports: %d %e %f %g %i Formatter for date/time/datetime uses Moment.js notation: https://momentjs.com/docs/#/displaying/format/ 一个 printf 样式的格式字符串，用于控制界面应如何显示数字。这不会影响返回值。int/float 支持的格式化程序：%d %e %f %g %i 日期/时间/日期时间的格式化程序使用 Moment.js 表示法： https://momentjs.com/docs/#/displaying/format/ |
| **key** *(str or int)* 键（STR 或 INT）                      | An optional string or integer to use as the unique key for the widget. If this is omitted, a key will be generated for the widget based on its content. Multiple widgets of the same type may not share the same key. 用作小组件唯一键的可选字符串或整数。如果省略此项，将根据其内容为小部件生成一个键。同一类型的多个小部件不能共享同一个键。 |
| **help** *(str)*                                             | An optional tooltip that gets displayed next to the slider. 显示在滑块旁边的可选工具提示。 |
| **on_change** *(callable)* on_change（可赎回）               | An optional callback invoked when this slider's value changes. 当此滑块的值更改时调用的可选回调。 |
| **args** *(tuple)*                                           | An optional tuple of args to pass to the callback. 要传递给回调的参数的可选元组。 |
| **kwargs** *(dict)*                                          | An optional dict of kwargs to pass to the callback. 要传递给回调的 kwargs 的可选字典。 |
| **disabled** *(bool)*                                        | An optional boolean, which disables the slider if set to True. The default is False. This argument can only be supplied by keyword. 一个可选的布尔值，如果设置为 True，则禁用滑块。默认值为 False。此参数只能由关键字提供。 |
| **label_visibility** *("visible" or "hidden" or "collapsed")* label_visibility（“可见”或“隐藏”或“折叠”） | The visibility of the label. If "hidden", the label doesn't show but there is still empty space for it above the widget (equivalent to label=""). If "collapsed", both the label and the space are removed. Default is "visible". This argument can only be supplied by keyword. 标签的可见性。如果为“隐藏”，则标签不显示，但小部件上方仍有空白空间（相当于 label=“”）。如果“折叠”，则标签和空格都将被删除。默认值为“可见”。此参数只能由关键字提供。 |
| Returns                                                      |                                                              |
| *(int/float/date/time/datetime or tuple of int/float/date/time/datetime) （int/float/date/time/datetime 或 int/float/date/time/datetime 的元组）* | The current value of the slider widget. The return type will match the data type of the value parameter. 滑块微件的当前值。返回类型将与值参数的数据类型匹配。 |

#### Examples

> ```python
> import streamlit as st
> 
> age = st.slider('How old are you?', 0, 130, 25)
> st.write("I'm ", age, 'years old')
> ```

下面是范围滑块的示例：

```python
import streamlit as st

values = st.slider(
    'Select a range of values',
    0.0, 100.0, (25.0, 75.0))
st.write('Values:', values)
```

这是一个范围时间滑块：

```python
import streamlit as st
from datetime import time

appointment = st.slider(
    "Schedule your appointment:",
    value=(time(11, 30), time(12, 45)))
st.write("You're scheduled for:", appointment)
```

最后，日期时间滑块：

```python
import streamlit as st
from datetime import datetime

start_time = st.slider(
    "When do you start?",
    value=datetime(2020, 1, 1, 9, 30),
    format="MM/DD/YY - hh:mm")
st.write("Start time:", start_time)
```

![image-20230510065924124](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510065923816-594096171.png)

## st.select_slider

显示滑块微件以从列表中选择项目。

这还允许您通过将双元素元组或列表作为值传递来呈现范围滑块。

st.select_slider 和 st.slider 之间的区别在于，select_slider 接受任何数据类型并采用一组可迭代的选项，而滑块仅接受数字或日期/时间数据，并将范围作为输入。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/select_slider.py#L106) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.select_slider(label, options=(), value=None, format_func=special_internal_function, key=None, help=None, on_change=None, args=None, kwargs=None, *, disabled=False, label_visibility="visible") st.select_slider（label， options=（）， value=None， format_func=special_internal_function， key=None， help=None， on_change=None， args=None， kwargs=None， *， disabled=False， label_visibility=“visible”） |                                                              |
| Parameters                                                   |                                                              |
| **label** *(str)*                                            | A short label explaining to the user what this slider is for. The label can optionally contain Markdown and supports the following elements: Bold, Italics, Strikethroughs, Inline Code, Emojis, and Links. 向用户解释此滑块用途的简短标签。标签可以选择包含 Markdown 并支持以下元素：粗体、斜体、删除线、内联代码、表情符号和链接。This also supports: 这也支持：Emoji shortcodes, such as `:+1:` and `:sunglasses:`. For a list of all supported codes, see https://share.streamlit.io/streamlit/emoji-shortcodes. 表情符号短代码，例如 `:+1:` 和 `:sunglasses:` 。有关所有支持的代码的列表，请参阅 https://share.streamlit.io/streamlit/emoji-shortcodes 。LaTeX expressions, by wrapping them in "$" or "$$" (the "$$" must be on their own lines). Supported LaTeX functions are listed at https://katex.org/docs/supported.html. LaTeX 表达式，通过将它们包装在“$”或“$$”中（“$$”必须在它们自己的行上）。支持的 LaTeX 函数列在 https://katex.org/docs/supported.html 中。Colored text, using the syntax `:color[text to be colored]`, where `color` needs to be replaced with any of the following supported colors: blue, green, orange, red, violet. 彩色文本，使用语法 `:color[text to be colored]` ，其中 `color` 需要替换为以下任何受支持的颜色：蓝色、绿色、橙色、红色、紫色。Unsupported elements are unwrapped so only their children (text contents) render. Display unsupported elements as literal characters by backslash-escaping them. E.g. `1\. Not an ordered list`. 不受支持的元素将解开包装，以便仅呈现其子元素（文本内容）。通过反斜杠转义将不支持的元素显示为文字字符。例如 `1\. Not an ordered list` .For accessibility reasons, you should never set an empty label (label="") but hide it with label_visibility if needed. In the future, we may disallow empty labels by raising an exception. 出于辅助功能原因，切勿设置空标签 （label=“”），而应在需要时使用 label_visibility 将其隐藏。将来，我们可能会通过引发异常来禁止空标签。 |
| **options** *(Sequence, numpy.ndarray, pandas.Series, pandas.DataFrame, or pandas.Index)* 选项（Sequence， numpy.ndarray， pandas.系列，熊猫。数据帧或熊猫。索引） | Labels for the slider options. All options will be cast to str internally by default. For pandas.DataFrame, the first column is selected. 滑块选项的标签。默认情况下，所有选项都将在内部转换为 str。对于熊猫。数据帧，则选择第一列。 |
| **value** *(a supported type or a tuple/list of supported types or None)* 值（支持的类型或元组/支持类型的列表或无） | The value of the slider when it first renders. If a tuple/list of two values is passed here, then a range slider with those lower and upper bounds is rendered. For example, if set to (1, 10) the slider will have a selectable range between 1 and 10. Defaults to first option. 滑块首次呈现时的值。如果在此处传递包含两个值的元组/列表，则会呈现具有这些下限和上限的范围滑块。例如，如果设置为 （1， 10），则滑块将具有介于 1 和 10 之间的可选范围。默认为第一个选项。 |
| **format_func** *(function)* format_func（功能）             | Function to modify the display of the labels from the options. argument. It receives the option as an argument and its output will be cast to str. 从选项修改标签显示的功能。论点。它接收选项作为参数，其输出将被转换为 str。 |
| **key** *(str or int)* 键（STR 或 INT）                      | An optional string or integer to use as the unique key for the widget. If this is omitted, a key will be generated for the widget based on its content. Multiple widgets of the same type may not share the same key. 用作小组件唯一键的可选字符串或整数。如果省略此项，将根据其内容为小部件生成一个键。同一类型的多个小部件不能共享同一个键。 |
| **help** *(str)*                                             | An optional tooltip that gets displayed next to the select slider. 显示在选择滑块旁边的可选工具提示。 |
| **on_change** *(callable)* on_change（可赎回）               | An optional callback invoked when this select_slider's value changes. 当此select_slider的值更改时调用的可选回调。 |
| **args** *(tuple)*                                           | An optional tuple of args to pass to the callback. 要传递给回调的参数的可选元组。 |
| **kwargs** *(dict)*                                          | An optional dict of kwargs to pass to the callback. 要传递给回调的 kwargs 的可选字典。 |
| **disabled** *(bool)*                                        | An optional boolean, which disables the select slider if set to True. The default is False. This argument can only be supplied by keyword. 一个可选的布尔值，如果设置为 True，则禁用选择滑块。默认值为 False。此参数只能由关键字提供。 |
| **label_visibility** *("visible" or "hidden" or "collapsed")* label_visibility（“可见”或“隐藏”或“折叠”） | The visibility of the label. If "hidden", the label doesn't show but there is still empty space for it above the widget (equivalent to label=""). If "collapsed", both the label and the space are removed. Default is "visible". This argument can only be supplied by keyword. 标签的可见性。如果为“隐藏”，则标签不显示，但小部件上方仍有空白空间（相当于 label=“”）。如果“折叠”，则标签和空格都将被删除。默认值为“可见”。此参数只能由关键字提供。 |
| Returns                                                      |                                                              |
| *(any value or tuple of any value) （任何值或任何值的元组）* | The current value of the slider widget. The return type will match the data type of the value parameter. 滑块微件的当前值。返回类型将与值参数的数据类型匹配。 |

#### Examples

```python
import streamlit as st

color = st.select_slider(
    'Select a color of the rainbow',
    options=['red', 'orange', 'yellow', 'green', 'blue', 'indigo', 'violet'])
st.write('My favorite color is', color)
```

下面是范围选择滑块的示例：

```python
import streamlit as st

start_color, end_color = st.select_slider(
    'Select a range of color wavelength',
    options=['red', 'orange', 'yellow', 'green', 'blue', 'indigo', 'violet'],
    value=('red', 'blue'))
st.write('You selected wavelengths between', start_color, 'and', end_color)
```

![image-20230510070026630](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510070026336-1510899611.png)



## st.text_input

显示单行文本输入微件。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/text_widgets.py#L71) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.text_input(label, value="", max_chars=None, key=None, type="default", help=None, autocomplete=None, on_change=None, args=None, kwargs=None, *, placeholder=None, disabled=False, label_visibility="visible") st.text_input（label， value=“”， max_chars=None， key=None， type=“default”， help=None， autocomplete=None， on_change=None， args=None， kwargs=None， *， 占位符=None， disabled=False， label_visibility=“visible”） |                                                              |
| Parameters                                                   |                                                              |
| **label** *(str)*                                            | A short label explaining to the user what this input is for. The label can optionally contain Markdown and supports the following elements: Bold, Italics, Strikethroughs, Inline Code, Emojis, and Links. ❗ 🔄This also supports: 这也支持：Emoji shortcodes, such as `:+1:` and `:sunglasses:`. For a list of all supported codes, see https://share.streamlit.io/streamlit/emoji-shortcodes. 表情符号短代码，例如 `:+1:` 和 `:sunglasses:` 。有关所有支持的代码的列表，请参阅 https://share.streamlit.io/streamlit/emoji-shortcodes 。LaTeX expressions, by wrapping them in "$" or "$$" (the "$$" must be on their own lines). Supported LaTeX functions are listed at https://katex.org/docs/supported.html. LaTeX 表达式，通过将它们包装在“$”或“$$”中（“$$”必须在它们自己的行上）。支持的 LaTeX 函数列在 https://katex.org/docs/supported.html 中。Colored text, using the syntax `:color[text to be colored]`, where `color` needs to be replaced with any of the following supported colors: blue, green, orange, red, violet. 彩色文本，使用语法 `:color[text to be colored]` ，其中 `color` 需要替换为以下任何受支持的颜色：蓝色、绿色、橙色、红色、紫色。Unsupported elements are unwrapped so only their children (text contents) render. Display unsupported elements as literal characters by backslash-escaping them. E.g. `1\. Not an ordered list`. 不受支持的元素将解开包装，以便仅呈现其子元素（文本内容）。通过反斜杠转义将不支持的元素显示为文字字符。例如 `1\. Not an ordered list` .For accessibility reasons, you should never set an empty label (label="") but hide it with label_visibility if needed. In the future, we may disallow empty labels by raising an exception. 出于辅助功能原因，切勿设置空标签 （label=“”），而应在需要时使用 label_visibility 将其隐藏。将来，我们可能会通过引发异常来禁止空标签。 |
| **value** *(object)*                                         | The text value of this widget when it first renders. This will be cast to str internally. 此小组件首次呈现时的文本值。这将在内部强制转换为 str。 |
| **max_chars** *(int or None)* max_chars（整数或无）          | Max number of characters allowed in text input. 文本输入中允许的最大字符数。 |
| **key** *(str or int)* 键（STR 或 INT）                      | An optional string or integer to use as the unique key for the widget. If this is omitted, a key will be generated for the widget based on its content. Multiple widgets of the same type may not share the same key. 用作小组件唯一键的可选字符串或整数。如果省略此项，将根据其内容为小部件生成一个键。同一类型的多个小部件不能共享同一个键。 |
| **type** *("default" or "password")* 类型（“默认”或“密码”）  | The type of the text input. This can be either "default" (for a regular text input), or "password" (for a text input that masks the user's typed value). Defaults to "default". 文本输入的类型。这可以是“默认”（对于常规文本输入）或“密码”（对于屏蔽用户键入的值的文本输入）。默认为“默认”。 |
| **help** *(str)*                                             | An optional tooltip that gets displayed next to the input. 显示在输入旁边的可选工具提示。 |
| **autocomplete** *(str)* 自动完成 （str）                    | An optional value that will be passed to the <input> element's autocomplete property. If unspecified, this value will be set to "new-password" for "password" inputs, and the empty string for "default" inputs. For more details, see https://developer.mozilla.org/en-US/docs/Web/HTML/Attributes/autocomplete 将传递给<input>元素的自动完成属性的可选值。如果未指定，则此值将设置为“密码”输入的“新密码”，以及“默认”输入的空字符串。有关详细信息，请参阅 https://developer.mozilla.org/en-US/docs/Web/HTML/Attributes/autocomplete |
| **on_change** *(callable)* on_change（可赎回）               | An optional callback invoked when this text input's value changes. 当此文本输入的值更改时调用的可选回调。 |
| **args** *(tuple)*                                           | An optional tuple of args to pass to the callback. 要传递给回调的参数的可选元组。 |
| **kwargs** *(dict)*                                          | An optional dict of kwargs to pass to the callback. 要传递给回调的 kwargs 的可选字典。 |
| **placeholder** *(str or None)* 占位符（str 或 none）        | An optional string displayed when the text input is empty. If None, no text is displayed. This argument can only be supplied by keyword. 文本输入为空时显示的可选字符串。如果为“无”，则不显示任何文本。此参数只能由关键字提供。 |
| **disabled** *(bool)*                                        | An optional boolean, which disables the text input if set to True. The default is False. This argument can only be supplied by keyword. 可选的布尔值，如果设置为 True，则禁用文本输入。默认值为 False。此参数只能由关键字提供。 |
| **label_visibility** *("visible" or "hidden" or "collapsed")* label_visibility（“可见”或“隐藏”或“折叠”） | The visibility of the label. If "hidden", the label doesn't show but there is still empty space for it above the widget (equivalent to label=""). If "collapsed", both the label and the space are removed. Default is "visible". This argument can only be supplied by keyword. 标签的可见性。如果为“隐藏”，则标签不显示，但小部件上方仍有空白空间（相当于 label=“”）。如果“折叠”，则标签和空格都将被删除。默认值为“可见”。此参数只能由关键字提供。 |
| Returns                                                      |                                                              |
| *(str)*                                                      | The current value of the text input widget. 文本输入微件的当前值。 |

#### Example

> ```python
> import streamlit as st
> 
> title = st.text_input('Movie title', 'Life of Brian')
> st.write('The current movie title is', title)
> ```

![image-20230510070059572](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510070059186-1971961231.png)

文本输入微件可以使用 `label_visibility` 参数自定义隐藏其标签的方式。如果为“隐藏”，则标签不显示，但小部件上方仍有空白空间（相当于 `label=""` ）。如果“折叠”，则标签和空格都将被删除。默认值为“可见”。也可以使用 `disabled` 参数禁用文本输入微件，并且可以在文本输入为空时使用 `placeholder` 参数显示可选的占位符文本：

```python
import streamlit as st

# Store the initial value of widgets in session state
if "visibility" not in st.session_state:
    st.session_state.visibility = "visible"
    st.session_state.disabled = False

col1, col2 = st.columns(2)

with col1:
    st.checkbox("Disable text input widget", key="disabled")
    st.radio(
        "Set text input label visibility 👉",
        key="visibility",
        options=["visible", "hidden", "collapsed"],
    )
    st.text_input(
        "Placeholder for the other text input widget",
        "This is a placeholder",
        key="placeholder",
    )

with col2:
    text_input = st.text_input(
        "Enter some text 👇",
        label_visibility=st.session_state.visibility,
        disabled=st.session_state.disabled,
        placeholder=st.session_state.placeholder,
    )

    if text_input:
        st.write("You entered: ", text_input)
```

![image-20230510070120058](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510070119725-1479449581.png)

## st.number_input

显示数值输入微件。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/number_input.py#L66) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.number_input(label, min_value=None, max_value=None, value=, step=None, format=None, key=None, help=None, on_change=None, args=None, kwargs=None, *, disabled=False, label_visibility="visible") st.number_input（label， min_value=None， max_value=None， value=， step=None， format=None， key=None， help=None， on_change=None， args=None， kwargs=None， *， disabled=False， label_visibility=“visible”） |                                                              |
| Parameters                                                   |                                                              |
| **label** *(str)*                                            | A short label explaining to the user what this input is for. The label can optionally contain Markdown and supports the following elements: Bold, Italics, Strikethroughs, Inline Code, Emojis, and Links. 向用户解释此输入用途的简短标签。标签可以选择包含 Markdown 并支持以下元素：粗体、斜体、删除线、内联代码、表情符号和链接。This also supports: 这也支持：Emoji shortcodes, such as `:+1:` and `:sunglasses:`. For a list of all supported codes, see https://share.streamlit.io/streamlit/emoji-shortcodes. 表情符号短代码，例如 `:+1:` 和 `:sunglasses:` 。有关所有支持的代码的列表，请参阅 https://share.streamlit.io/streamlit/emoji-shortcodes 。LaTeX expressions, by wrapping them in "$" or "$$" (the "$$" must be on their own lines). Supported LaTeX functions are listed at https://katex.org/docs/supported.html. LaTeX 表达式，通过将它们包装在“$”或“$$”中（“$$”必须在它们自己的行上）。支持的 LaTeX 函数列在 https://katex.org/docs/supported.html 中。Colored text, using the syntax `:color[text to be colored]`, where `color` needs to be replaced with any of the following supported colors: blue, green, orange, red, violet. 彩色文本，使用语法 `:color[text to be colored]` ，其中 `color` 需要替换为以下任何受支持的颜色：蓝色、绿色、橙色、红色、紫色。Unsupported elements are unwrapped so only their children (text contents) render. Display unsupported elements as literal characters by backslash-escaping them. E.g. `1\. Not an ordered list`. 不受支持的元素将解开包装，以便仅呈现其子元素（文本内容）。通过反斜杠转义将不支持的元素显示为文字字符。例如 `1\. Not an ordered list` .For accessibility reasons, you should never set an empty label (label="") but hide it with label_visibility if needed. In the future, we may disallow empty labels by raising an exception. 出于辅助功能原因，切勿设置空标签 （label=“”），而应在需要时使用 label_visibility 将其隐藏。将来，我们可能会通过引发异常来禁止空标签。 |
| **min_value** *(int or float or None)* min_value（整数或浮点数或无） | The minimum permitted value. If None, there will be no minimum. 允许的最小值。如果为“无”，则没有最低要求。 |
| **max_value** *(int or float or None)* max_value（整数或浮点数或无） | The maximum permitted value. If None, there will be no maximum. 允许的最大值。如果为“无”，则没有最大值。 |
| **value** *(int or float or None)* 值（整数或浮点数或无）    | The value of this widget when it first renders. Defaults to min_value, or 0.0 if min_value is None 此小组件首次呈现时的值。默认为 min_value，如果min_value为“无”，则默认为 0.0 |
| **step** *(int or float or None)* 步长（整数或浮点数或无）   | The stepping interval. Defaults to 1 if the value is an int, 0.01 otherwise. If the value is not specified, the format parameter will be used. 步进间隔。如果值为 int，则默认为 1，否则默认为 0.01。如果未指定该值，则将使用 format 参数。 |
| **format** *(str or None)* 格式（str 或 none）               | A printf-style format string controlling how the interface should display numbers. Output must be purely numeric. This does not impact the return value. Valid formatters: %d %e %f %g %i %u 一个 printf 样式的格式字符串，用于控制界面应如何显示数字。输出必须是纯数字。这不会影响返回值。有效格式化程序： %d %e %f %g %i %u |
| **key** *(str or int)* 键（STR 或 INT）                      | An optional string or integer to use as the unique key for the widget. If this is omitted, a key will be generated for the widget based on its content. Multiple widgets of the same type may not share the same key. 用作小组件唯一键的可选字符串或整数。如果省略此项，将根据其内容为小部件生成一个键。同一类型的多个小部件不能共享同一个键。 |
| **help** *(str)*                                             | An optional tooltip that gets displayed next to the input. 显示在输入旁边的可选工具提示。 |
| **on_change** *(callable)*                                   | An optional callback invoked when this number_input's value changes. 当此number_input的值更改时调用的可选回调。 |
| **args** *(tuple)*                                           | An optional tuple of args to pass to the callback. 要传递给回调的参数的可选元组。 |
| **kwargs** *(dict)*                                          | An optional dict of kwargs to pass to the callback. 要传递给回调的 kwargs 的可选字典。 |
| **disabled** *(bool)*                                        | An optional boolean, which disables the number input if set to True. The default is False. This argument can only be supplied by keyword. 可选的布尔值，如果设置为 True，则禁用数字输入。默认值为 False。此参数只能由关键字提供。 |
| **label_visibility** *("visible" or "hidden" or "collapsed")* label_visibility（“可见”或“隐藏”或“折叠”） | The visibility of the label. If "hidden", the label doesn't show but there is still empty space for it above the widget (equivalent to label=""). If "collapsed", both the label and the space are removed. Default is "visible". This argument can only be supplied by keyword. 标签的可见性。如果为“隐藏”，则标签不显示，但小部件上方仍有空白空间（相当于 label=“”）。如果“折叠”，则标签和空格都将被删除。默认值为“可见”。此参数只能由关键字提供。 |
| Returns                                                      |                                                              |
| *(int or float) （整数或浮点数）*                            | The current value of the numeric input widget. The return type will match the data type of the value parameter. 数值输入微件的当前值。返回类型将与值参数的数据类型匹配。 |

#### Example

> ```python
> import streamlit as st
> 
> number = st.number_input('Insert a number')
> st.write('The current number is ', number)
> ```

![image-20230510070151547](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510070151231-1727553951.png)

## st.text_area

显示多行文本输入微件。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/text_widgets.py#L274) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.text_area(label, value="", height=None, max_chars=None, key=None, help=None, on_change=None, args=None, kwargs=None, *, placeholder=None, disabled=False, label_visibility="visible") st.text_area（label， value=“”， height=None， max_chars=None， key=None， help=None， on_change=None， args=None， kwargs=None， *， 占位符=None， disabled=False， label_visibility=“visible”） |                                                              |
| Parameters                                                   |                                                              |
| **label** *(str)*                                            | A short label explaining to the user what this input is for. The label can optionally contain Markdown and supports the following elements: Bold, Italics, Strikethroughs, Inline Code, Emojis, and Links. 向用户解释此输入用途的简短标签。标签可以选择包含 Markdown 并支持以下元素：粗体、斜体、删除线、内联代码、表情符号和链接。This also supports: 这也支持：Emoji shortcodes, such as `:+1:` and `:sunglasses:`. For a list of all supported codes, see https://share.streamlit.io/streamlit/emoji-shortcodes. 表情符号短代码，例如 `:+1:` 和 `:sunglasses:` 。有关所有支持的代码的列表，请参阅 https://share.streamlit.io/streamlit/emoji-shortcodes 。LaTeX expressions, by wrapping them in "$" or "$$" (the "$$" must be on their own lines). Supported LaTeX functions are listed at https://katex.org/docs/supported.html. LaTeX 表达式，通过将它们包装在“$”或“$$”中（“$$”必须在它们自己的行上）。支持的 LaTeX 函数列在 https://katex.org/docs/supported.html 中。Colored text, using the syntax `:color[text to be colored]`, where `color` needs to be replaced with any of the following supported colors: blue, green, orange, red, violet. 彩色文本，使用语法 `:color[text to be colored]` ，其中 `color` 需要替换为以下任何受支持的颜色：蓝色、绿色、橙色、红色、紫色。Unsupported elements are unwrapped so only their children (text contents) render. Display unsupported elements as literal characters by backslash-escaping them. E.g. `1\. Not an ordered list`. 不受支持的元素将解开包装，以便仅呈现其子元素（文本内容）。通过反斜杠转义将不支持的元素显示为文字字符。例如 `1\. Not an ordered list` .For accessibility reasons, you should never set an empty label (label="") but hide it with label_visibility if needed. In the future, we may disallow empty labels by raising an exception. 出于辅助功能原因，切勿设置空标签 （label=“”），而应在需要时使用 label_visibility 将其隐藏。将来，我们可能会通过引发异常来禁止空标签。 |
| **value** *(object)*                                         | The text value of this widget when it first renders. This will be cast to str internally. 此小组件首次呈现时的文本值。这将在内部强制转换为 str。 |
| **height** *(int or None)* 高度（整数或无）                  | Desired height of the UI element expressed in pixels. If None, a default height is used. |
| **max_chars** *(int or None)* max_chars（整数或无）          | Maximum number of characters allowed in text area.           |
| **key** *(str or int)* 键（STR 或 INT）                      | An optional string or integer to use as the unique key for the widget. If this is omitted, a key will be generated for the widget based on its content. Multiple widgets of the same type may not share the same key. 用作小组件唯一键的可选字符串或整数。如果省略此项，将根据其内容为小部件生成一个键。同一类型的多个小部件不能共享同一个键。 |
| **help** *(str)*                                             | An optional tooltip that gets displayed next to the textarea. |
| **on_change** *(callable)*                                   | An optional callback invoked when this text_area's value changes. |
| **args** *(tuple)*                                           | An optional tuple of args to pass to the callback. 要传递给回调的参数的可选元组。 |
| **kwargs** *(dict)*                                          | An optional dict of kwargs to pass to the callback. 要传递给回调的 kwargs 的可选字典。 |
| **placeholder** *(str or None)* 占位符（str 或 none）        | An optional string displayed when the text area is empty. If None, no text is displayed. This argument can only be supplied by keyword. |
| **disabled** *(bool)*                                        | An optional boolean, which disables the text area if set to True. The default is False. This argument can only be supplied by keyword. |
| **label_visibility** *("visible" or "hidden" or "collapsed")* label_visibility（“可见”或“隐藏”或“折叠”） | The visibility of the label. If "hidden", the label doesn't show but there is still empty space for it above the widget (equivalent to label=""). If "collapsed", both the label and the space are removed. Default is "visible". This argument can only be supplied by keyword. 标签的可见性。如果为“隐藏”，则标签不显示，但小部件上方仍有空白空间（相当于 label=“”）。如果“折叠”，则标签和空格都将被删除。默认值为“可见”。此参数只能由关键字提供。 |
| Returns                                                      |                                                              |
| *(str)*                                                      | The current value of the text input widget. 文本输入微件的当前值。 |

#### Example

> ```python
> import streamlit as st
> 
> txt = st.text_area('Text to analyze', '''
>     It was the best of times, it was the worst of times, it was
>     the age of wisdom, it was the age of foolishness, it was
>     the epoch of belief, it was the epoch of incredulity, it
>     was the season of Light, it was the season of Darkness, it
>     was the spring of hope, it was the winter of despair, (...)
>     ''')
> st.write('Sentiment:', run_sentiment_analysis(txt))
> ```



## st.date_input

显示日期输入微件。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/time_widgets.py#L399) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.date_input(label, value=None, min_value=None, max_value=None, key=None, help=None, on_change=None, args=None, kwargs=None, *, disabled=False, label_visibility="visible") st.date_input（label， value=None， min_value=None， max_value=None， key=None， help=None， on_change=None， args=None， kwargs=None， *， disabled=False， label_visibility=“visible”） |                                                              |
| Parameters                                                   |                                                              |
| **label** *(str)*                                            | A short label explaining to the user what this date input is for. The label can optionally contain Markdown and supports the following elements: Bold, Italics, Strikethroughs, Inline Code, Emojis, and Links. 向用户解释此日期输入的用途的简短标签。标签可以选择包含 Markdown 并支持以下元素：粗体、斜体、删除线、内联代码、表情符号和链接。This also supports: 这也支持：Emoji shortcodes, such as `:+1:` and `:sunglasses:`. For a list of all supported codes, see https://share.streamlit.io/streamlit/emoji-shortcodes. 表情符号短代码，例如 `:+1:` 和 `:sunglasses:` 。有关所有支持的代码的列表，请参阅 https://share.streamlit.io/streamlit/emoji-shortcodes 。LaTeX expressions, by wrapping them in "$" or "$$" (the "$$" must be on their own lines). Supported LaTeX functions are listed at https://katex.org/docs/supported.html. LaTeX 表达式，通过将它们包装在“$”或“$$”中（“$$”必须在它们自己的行上）。支持的 LaTeX 函数列在 https://katex.org/docs/supported.html 中。Colored text, using the syntax `:color[text to be colored]`, where `color` needs to be replaced with any of the following supported colors: blue, green, orange, red, violet. 彩色文本，使用语法 `:color[text to be colored]` ，其中 `color` 需要替换为以下任何受支持的颜色：蓝色、绿色、橙色、红色、紫色。Unsupported elements are unwrapped so only their children (text contents) render. Display unsupported elements as literal characters by backslash-escaping them. E.g. `1\. Not an ordered list`. 不受支持的元素将解开包装，以便仅呈现其子元素（文本内容）。通过反斜杠转义将不支持的元素显示为文字字符。例如 `1\. Not an ordered list` .For accessibility reasons, you should never set an empty label (label="") but hide it with label_visibility if needed. In the future, we may disallow empty labels by raising an exception. 出于辅助功能原因，切勿设置空标签 （label=“”），而应在需要时使用 label_visibility 将其隐藏。将来，我们可能会通过引发异常来禁止空标签。 |
| **value** *(datetime.date or datetime.datetime or list/tuple of datetime.date or datetime.datetime or None)* 值（datetime.date 或 datetime.datetime 或 list/tuple of datetime.date or datetime.datetime or None） | The value of this widget when it first renders. If a list/tuple with 0 to 2 date/datetime values is provided, the datepicker will allow users to provide a range. Defaults to today as a single-date picker. 此小组件首次呈现时的值。如果提供了具有 0 到 2 个日期/日期时间值的列表/元组，则日期选取器将允许用户提供范围。默认为今天作为单日期选取器。 |
| **min_value** *(datetime.date or datetime.datetime)* min_value（datetime.date 或 datetime.datetime） | The minimum selectable date. If value is a date, defaults to value - 10 years. If value is the interval [start, end], defaults to start - 10 years. 最小可选日期。如果值是日期，则默认为值 - 10 年。如果值为间隔 [开始、结束]，则默认为 开始 - 10 年。 |
| **max_value** *(datetime.date or datetime.datetime)* max_value（datetime.date 或 datetime.datetime） | The maximum selectable date. If value is a date, defaults to value + 10 years. If value is the interval [start, end], defaults to end + 10 years. 最大可选日期。如果值是日期，则默认为值 + 10 年。如果值为间隔 [开始、结束]，则默认为结束 + 10 年。 |
| **key** *(str or int)* 键（STR 或 INT）                      | An optional string or integer to use as the unique key for the widget. If this is omitted, a key will be generated for the widget based on its content. Multiple widgets of the same type may not share the same key. 用作小组件唯一键的可选字符串或整数。如果省略此项，将根据其内容为小部件生成一个键。同一类型的多个小部件不能共享同一个键。 |
| **help** *(str)*                                             | An optional tooltip that gets displayed next to the input. 显示在输入旁边的可选工具提示。 |
| **on_change** *(callable)*                                   | An optional callback invoked when this date_input's value changes. 当此date_input的值更改时调用的可选回调。 |
| **args** *(tuple)*                                           | An optional tuple of args to pass to the callback. 要传递给回调的参数的可选元组。 |
| **kwargs** *(dict)*                                          | An optional dict of kwargs to pass to the callback. 要传递给回调的 kwargs 的可选字典。 |
| **disabled** *(bool)*                                        | An optional boolean, which disables the date input if set to True. The default is False. This argument can only be supplied by keyword. 一个可选的布尔值，如果设置为 True，则禁用日期输入。默认值为 False。此参数只能由关键字提供。 |
| **label_visibility** *("visible" or "hidden" or "collapsed")* label_visibility（“可见”或“隐藏”或“折叠”） | The visibility of the label. If "hidden", the label doesn't show but there is still empty space for it above the widget (equivalent to label=""). If "collapsed", both the label and the space are removed. Default is "visible". This argument can only be supplied by keyword. 标签的可见性。如果为“隐藏”，则标签不显示，但小部件上方仍有空白空间（相当于 label=“”）。如果“折叠”，则标签和空格都将被删除。默认值为“可见”。此参数只能由关键字提供。 |
| Returns                                                      |                                                              |
| *(datetime.date or a tuple with 0-2 dates) （datetime.date 或具有 0-2 个日期的元组）* | The current value of the date input widget. 日期输入构件的当前值。 |

#### Example

> ```python
> import datetime
> import streamlit as st
> 
> d = st.date_input(
>     "When\'s your birthday",
>     datetime.date(2019, 7, 6))
> st.write('Your birthday is:', d)
> ```

![image-20230510070249810](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510070249503-213217447.png)

## st.time_input

显示时间输入微件。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/time_widgets.py#L214) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.time_input(label, value=None, key=None, help=None, on_change=None, args=None, kwargs=None, *, disabled=False, label_visibility="visible", step=0:15:00) st.time_input（label， value=None， key=None， help=None， on_change=None， args=None， kwargs=None， *， disabled=False， label_visibility=“visible”， step=0：15：00） |                                                              |
| Parameters                                                   |                                                              |
| **label** *(str)*                                            | A short label explaining to the user what this time input is for. The label can optionally contain Markdown and supports the following elements: Bold, Italics, Strikethroughs, Inline Code, Emojis, and Links. 向用户解释此时间输入的用途的简短标签。标签可以选择包含 Markdown 并支持以下元素：粗体、斜体、删除线、内联代码、表情符号和链接。This also supports: 这也支持：Emoji shortcodes, such as `:+1:` and `:sunglasses:`. For a list of all supported codes, see https://share.streamlit.io/streamlit/emoji-shortcodes. 表情符号短代码，例如 `:+1:` 和 `:sunglasses:` 。有关所有支持的代码的列表，请参阅 https://share.streamlit.io/streamlit/emoji-shortcodes 。LaTeX expressions, by wrapping them in "$" or "$$" (the "$$" must be on their own lines). Supported LaTeX functions are listed at https://katex.org/docs/supported.html. LaTeX 表达式，通过将它们包装在“$”或“$$”中（“$$”必须在它们自己的行上）。支持的 LaTeX 函数列在 https://katex.org/docs/supported.html 中。Colored text, using the syntax `:color[text to be colored]`, where `color` needs to be replaced with any of the following supported colors: blue, green, orange, red, violet. 彩色文本，使用语法 `:color[text to be colored]` ，其中 `color` 需要替换为以下任何受支持的颜色：蓝色、绿色、橙色、红色、紫色。Unsupported elements are unwrapped so only their children (text contents) render. Display unsupported elements as literal characters by backslash-escaping them. E.g. `1\. Not an ordered list`. 不受支持的元素将解开包装，以便仅呈现其子元素（文本内容）。通过反斜杠转义将不支持的元素显示为文字字符。例如 `1\. Not an ordered list` .For accessibility reasons, you should never set an empty label (label="") but hide it with label_visibility if needed. In the future, we may disallow empty labels by raising an exception. 出于辅助功能原因，切勿设置空标签 （label=“”），而应在需要时使用 label_visibility 将其隐藏。将来，我们可能会通过引发异常来禁止空标签。 |
| **value** *(datetime.time/datetime.datetime)* 值（日期时间.时间/日期时间.日期时间） | The value of this widget when it first renders. This will be cast to str internally. Defaults to the current time. 此小组件首次呈现时的值。这将在内部强制转换为 str。默认为当前时间。 |
| **key** *(str or int)* 键（STR 或 INT）                      | An optional string or integer to use as the unique key for the widget. If this is omitted, a key will be generated for the widget based on its content. Multiple widgets of the same type may not share the same key. 用作小组件唯一键的可选字符串或整数。如果省略此项，将根据其内容为小部件生成一个键。同一类型的多个小部件不能共享同一个键。 |
| **help** *(str)*                                             | An optional tooltip that gets displayed next to the input. 显示在输入旁边的可选工具提示。 |
| **on_change** *(callable)*                                   | An optional callback invoked when this time_input's value changes. 当此time_input的值更改时调用的可选回调。 |
| **args** *(tuple)*                                           | An optional tuple of args to pass to the callback. 要传递给回调的参数的可选元组。 |
| **kwargs** *(dict)*                                          | An optional dict of kwargs to pass to the callback. 要传递给回调的 kwargs 的可选字典。 |
| **disabled** *(bool)*                                        | An optional boolean, which disables the time input if set to True. The default is False. This argument can only be supplied by keyword. 可选的布尔值，如果设置为 True，则禁用时间输入。默认值为 False。此参数只能由关键字提供。 |
| **label_visibility** *("visible" or "hidden" or "collapsed")* label_visibility（“可见”或“隐藏”或“折叠”） | The visibility of the label. If "hidden", the label doesn't show but there is still empty space for it above the widget (equivalent to label=""). If "collapsed", both the label and the space are removed. Default is "visible". This argument can only be supplied by keyword. 标签的可见性。如果为“隐藏”，则标签不显示，但小部件上方仍有空白空间（相当于 label=“”）。如果“折叠”，则标签和空格都将被删除。默认值为“可见”。此参数只能由关键字提供。 |
| **step** *(int or timedelta)* 步长（整数或时间增量）         | The stepping interval in seconds. Defaults to 900, i.e. 15 minutes. You can also pass a datetime.timedelta object. 步进间隔（以秒为单位）。默认为 900，即 15 分钟。还可以传递 datetime.timedelta 对象。 |
| Returns                                                      |                                                              |
| *(datetime.time)*                                            | The current value of the time input widget. 时间输入小组件的当前值。 |

#### Example

> ```python
> import datetime
> import streamlit as st
> 
> t = st.time_input('Set an alarm for', datetime.time(8, 45))
> st.write('Alarm is set for', t)
> ```

![image-20230510070338122](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510070338044-1813944274.png)



## st.file_uploader

显示文件上传器小部件。

默认情况下，上传的文件限制为 200MB。您可以使用 server.maxUploadSize 配置选项进行配置。有关如何设置配置选项的详细信息，请参阅 https://docs.streamlit.io/library/advanced-features/configuration#set-configuration-options

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/file_uploader.py#L205) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.file_uploader(label, type=None, accept_multiple_files=False, key=None, help=None, on_change=None, args=None, kwargs=None, *, disabled=False, label_visibility="visible") st.file_uploader（label， type=None， accept_multiple_files=False， key=None， help=None， on_change=None， args=None， kwargs=None， *， disabled=False， label_visibility=“visible”） |                                                              |
| Parameters                                                   |                                                              |
| **label** *(str)*                                            | A short label explaining to the user what this file uploader is for. The label can optionally contain Markdown and supports the following elements: Bold, Italics, Strikethroughs, Inline Code, Emojis, and Links. 向用户解释此文件上传程序用途的简短标签。标签可以选择包含 Markdown 并支持以下元素：粗体、斜体、删除线、内联代码、表情符号和链接。This also supports: 这也支持：Emoji shortcodes, such as `:+1:` and `:sunglasses:`. For a list of all supported codes, see https://share.streamlit.io/streamlit/emoji-shortcodes. 表情符号短代码，例如 `:+1:` 和 `:sunglasses:` 。有关所有支持的代码的列表，请参阅 https://share.streamlit.io/streamlit/emoji-shortcodes 。LaTeX expressions, by wrapping them in "$" or "$$" (the "$$" must be on their own lines). Supported LaTeX functions are listed at https://katex.org/docs/supported.html. LaTeX 表达式，通过将它们包装在“$”或“$$”中（“$$”必须在它们自己的行上）。支持的 LaTeX 函数列在 https://katex.org/docs/supported.html 中。Colored text, using the syntax `:color[text to be colored]`, where `color` needs to be replaced with any of the following supported colors: blue, green, orange, red, violet. 彩色文本，使用语法 `:color[text to be colored]` ，其中 `color` 需要替换为以下任何受支持的颜色：蓝色、绿色、橙色、红色、紫色。Unsupported elements are unwrapped so only their children (text contents) render. Display unsupported elements as literal characters by backslash-escaping them. E.g. `1\. Not an ordered list`. 不受支持的元素将解开包装，以便仅呈现其子元素（文本内容）。通过反斜杠转义将不支持的元素显示为文字字符。例如 `1\. Not an ordered list` .For accessibility reasons, you should never set an empty label (label="") but hide it with label_visibility if needed. In the future, we may disallow empty labels by raising an exception. 出于辅助功能原因，切勿设置空标签 （label=“”），而应在需要时使用 label_visibility 将其隐藏。将来，我们可能会通过引发异常来禁止空标签。 |
| **type** *(str or list of str or None)* 类型（str 或 str 列表或 none） | Array of allowed extensions. ['png', 'jpg'] The default is None, which means all extensions are allowed. 允许的扩展数组。[“PNG”， “JPG”]默认值为 None，这意味着允许所有扩展。 |
| **accept_multiple_files** *(bool)* accept_multiple_files（布尔值） | If True, allows the user to upload multiple files at the same time, in which case the return value will be a list of files. Default: False 如果为 True，则允许用户同时上传多个文件，在这种情况下，返回值将是文件列表。默认值：假 |
| **key** *(str or int)* 键（STR 或 INT）                      | An optional string or integer to use as the unique key for the widget. If this is omitted, a key will be generated for the widget based on its content. Multiple widgets of the same type may not share the same key. 用作小组件唯一键的可选字符串或整数。如果省略此项，将根据其内容为小部件生成一个键。同一类型的多个小部件不能共享同一个键。 |
| **help** *(str)*                                             | A tooltip that gets displayed next to the file uploader. 显示在文件上传程序旁边的工具提示。 |
| **on_change** *(callable)* on_change（可赎回）               | An optional callback invoked when this file_uploader's value changes. 当此file_uploader的值更改时调用的可选回调。 |
| **args** *(tuple)*                                           | An optional tuple of args to pass to the callback. 要传递给回调的参数的可选元组。 |
| **kwargs** *(dict)*                                          | An optional dict of kwargs to pass to the callback. 要传递给回调的 kwargs 的可选字典。 |
| **disabled** *(bool)*                                        | An optional boolean, which disables the file uploader if set to True. The default is False. This argument can only be supplied by keyword. 一个可选的布尔值，如果设置为 True，则会禁用文件上传程序。默认值为 False。此参数只能由关键字提供。 |
| **label_visibility** *("visible" or "hidden" or "collapsed")* label_visibility（“可见”或“隐藏”或“折叠”） | The visibility of the label. If "hidden", the label doesn't show but there is still empty space for it above the widget (equivalent to label=""). If "collapsed", both the label and the space are removed. Default is "visible". This argument can only be supplied by keyword. 标签的可见性。如果为“隐藏”，则标签不显示，但小部件上方仍有空白空间（相当于 label=“”）。如果“折叠”，则标签和空格都将被删除。默认值为“可见”。此参数只能由关键字提供。 |
| Returns                                                      |                                                              |
| *(None or UploadedFile or list of UploadedFile) （无或上传文件或上传文件列表）* | If accept_multiple_files is False, returns either None or an UploadedFile object. 如果accept_multiple_files为 False，则返回 None 或 UploadedFile 对象。If accept_multiple_files is True, returns a list with the uploaded files as UploadedFile objects. If no files were uploaded, returns an empty list. 如果accept_multiple_files为 True，则返回一个列表，其中包含作为 UploadedFile 对象的上载文件。如果未上传任何文件，则返回空列表。The UploadedFile class is a subclass of BytesIO, and therefore it is "file-like". This means you can pass them anywhere where a file is expected. UploadedFile 类是 BytesIO 的一个子类，因此它是“类似文件的”。这意味着您可以将它们传递到任何需要文件的位置。 |

#### Examples

插入一次接受单个文件的文件上传器：

```python
import streamlit as st
import pandas as pd
from io import StringIO

uploaded_file = st.file_uploader("Choose a file")
if uploaded_file is not None:
    # To read file as bytes:
    bytes_data = uploaded_file.getvalue()
    st.write(bytes_data)

    # To convert to a string based IO:
    stringio = StringIO(uploaded_file.getvalue().decode("utf-8"))
    st.write(stringio)

    # To read file as string:
    string_data = stringio.read()
    st.write(string_data)

    # Can be used wherever a "file-like" object is accepted:
    dataframe = pd.read_csv(uploaded_file)
    st.write(dataframe)
```

插入一次接受多个文件的文件上传程序：

```python
import streamlit as st

uploaded_files = st.file_uploader("Choose a CSV file", accept_multiple_files=True)
for uploaded_file in uploaded_files:
    bytes_data = uploaded_file.read()
    st.write("filename:", uploaded_file.name)
    st.write(bytes_data)
```

![image-20230510070452728](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510070452619-1056181472.png)

## st.camera_input

显示从用户网络摄像头返回图片的小组件。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/camera_input.py#L109) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.camera_input(label, key=None, help=None, on_change=None, args=None, kwargs=None, *, disabled=False, label_visibility="visible") st.camera_input（label， key=None， help=None， on_change=None， args=None， kwargs=None， *， disabled=False， label_visibility=“visible”） |                                                              |
| Parameters                                                   |                                                              |
| **label** *(str)*                                            | A short label explaining to the user what this widget is used for. The label can optionally contain Markdown and supports the following elements: Bold, Italics, Strikethroughs, Inline Code, Emojis, and Links. 向用户解释此小部件用途的简短标签。标签可以选择包含 Markdown 并支持以下元素：粗体、斜体、删除线、内联代码、表情符号和链接。This also supports: 这也支持：Emoji shortcodes, such as `:+1:` and `:sunglasses:`. For a list of all supported codes, see https://share.streamlit.io/streamlit/emoji-shortcodes. 表情符号短代码，例如 `:+1:` 和 `:sunglasses:` 。有关所有支持的代码的列表，请参阅 https://share.streamlit.io/streamlit/emoji-shortcodes 。LaTeX expressions, by wrapping them in "$" or "$$" (the "$$" must be on their own lines). Supported LaTeX functions are listed at https://katex.org/docs/supported.html. LaTeX 表达式，通过将它们包装在“$”或“$$”中（“$$”必须在它们自己的行上）。支持的 LaTeX 函数列在 https://katex.org/docs/supported.html 中。Colored text, using the syntax `:color[text to be colored]`, where `color` needs to be replaced with any of the following supported colors: blue, green, orange, red, violet. 彩色文本，使用语法 `:color[text to be colored]` ，其中 `color` 需要替换为以下任何受支持的颜色：蓝色、绿色、橙色、红色、紫色。Unsupported elements are unwrapped so only their children (text contents) render. Display unsupported elements as literal characters by backslash-escaping them. E.g. `1\. Not an ordered list`. 不受支持的元素将解开包装，以便仅呈现其子元素（文本内容）。通过反斜杠转义将不支持的元素显示为文字字符。例如 `1\. Not an ordered list` .For accessibility reasons, you should never set an empty label (label="") but hide it with label_visibility if needed. In the future, we may disallow empty labels by raising an exception. 出于辅助功能原因，切勿设置空标签 （label=“”），而应在需要时使用 label_visibility 将其隐藏。将来，我们可能会通过引发异常来禁止空标签。 |
| **key** *(str or int)* 键（STR 或 INT）                      | An optional string or integer to use as the unique key for the widget. If this is omitted, a key will be generated for the widget based on its content. Multiple widgets of the same type may not share the same key. 用作小组件唯一键的可选字符串或整数。如果省略此项，将根据其内容为小部件生成一个键。同一类型的多个小部件不能共享同一个键。 |
| **help** *(str)*                                             | A tooltip that gets displayed next to the camera input. 显示在相机输入旁边的工具提示。 |
| **on_change** *(callable)* on_change（可赎回）               | An optional callback invoked when this camera_input's value changes. 当此camera_input的值更改时调用的可选回调。 |
| **args** *(tuple)*                                           | An optional tuple of args to pass to the callback. 要传递给回调的参数的可选元组。 |
| **kwargs** *(dict)*                                          | An optional dict of kwargs to pass to the callback. 要传递给回调的 kwargs 的可选字典。 |
| **disabled** *(bool)*                                        | An optional boolean, which disables the camera input if set to True. The default is False. This argument can only be supplied by keyword. 可选的布尔值，如果设置为 True，则禁用相机输入。默认值为 False。此参数只能由关键字提供。 |
| **label_visibility** *("visible" or "hidden" or "collapsed")* label_visibility（“可见”或“隐藏”或“折叠”） | The visibility of the label. If "hidden", the label doesn't show but there is still empty space for it above the widget (equivalent to label=""). If "collapsed", both the label and the space are removed. Default is "visible". This argument can only be supplied by keyword. 标签的可见性。如果为“隐藏”，则标签不显示，但小部件上方仍有空白空间（相当于 label=“”）。如果“折叠”，则标签和空格都将被删除。默认值为“可见”。此参数只能由关键字提供。 |
| Returns                                                      |                                                              |
| *(None or UploadedFile) （无或上传文件）*                    | The UploadedFile class is a subclass of BytesIO, and therefore it is "file-like". This means you can pass them anywhere where a file is expected. UploadedFile 类是 BytesIO 的一个子类，因此它是“类似文件的”。这意味着您可以将它们传递到任何需要文件的位置。 |

#### Examples

> ```python
> import streamlit as st
> 
> picture = st.camera_input("Take a picture")
> 
> if picture:
>     st.image(picture)
> ```

若要将图像文件缓冲区读取为字节，可以在 `UploadedFile` 对象上使用 `getvalue()` 。

```python
import streamlit as st

img_file_buffer = st.camera_input("Take a picture")

if img_file_buffer is not None:
    # To read image file buffer as bytes:
    bytes_data = img_file_buffer.getvalue()
    # Check the type of bytes_data:
    # Should output: <class 'bytes'>
    st.write(type(bytes_data))
```

**Important：**

`st.camera_input` 返回 `UploadedFile` 类的对象，该对象是 BytesIO 的子类。因此，它是一个“类似文件”的对象。这意味着您可以将其传递到任何需要文件的位置，类似于 `st.file_uploader` 。

### Image processing examples

可以将 `st.camera_input` 的输出用于各种下游任务，包括图像处理。下面，我们演示如何将 `st.camera_input` 小部件与流行的图像和数据处理库一起使用，例如Pillow，NumPy，OpenCV，TensorFlow，torchvision和PyTorch。

虽然我们为最流行的用例和库提供了示例，但欢迎您根据自己的需求和最喜欢的库调整这些示例。



### Pillow (PIL) and NumPy

Ensure you have installed [Pillow](https://pillow.readthedocs.io/en/stable/installation.html) and [NumPy](https://numpy.org/).

要将图像文件缓冲区读取为 PIL 图像并将其转换为 NumPy 数组，请执行以下操作：

```python
import streamlit as st
from PIL import Image
import numpy as np

img_file_buffer = st.camera_input("Take a picture")

if img_file_buffer is not None:
    # To read image file buffer as a PIL Image:
    img = Image.open(img_file_buffer)

    # To convert PIL Image to numpy array:
    img_array = np.array(img)

    # Check the type of img_array:
    # Should output: <class 'numpy.ndarray'>
    st.write(type(img_array))

    # Check the shape of img_array:
    # Should output shape: (height, width, channels)
    st.write(img_array.shape)
```



### OpenCV (cv2)

确保您已安装 OpenCV 和 NumPy。

要使用 OpenCV 读取图像文件缓冲区，请执行以下操作：

```python
import streamlit as st
import cv2
import numpy as np

img_file_buffer = st.camera_input("Take a picture")

if img_file_buffer is not None:
    # To read image file buffer with OpenCV:
    bytes_data = img_file_buffer.getvalue()
    cv2_img = cv2.imdecode(np.frombuffer(bytes_data, np.uint8), cv2.IMREAD_COLOR)

    # Check the type of cv2_img:
    # Should output: <class 'numpy.ndarray'>
    st.write(type(cv2_img))

    # Check the shape of cv2_img:
    # Should output shape: (height, width, channels)
    st.write(cv2_img.shape)
```



### TensorFlow

Ensure you have installed [TensorFlow](https://www.tensorflow.org/install/).

要使用 TensorFlow 将图像文件缓冲区读取为 3 维 uint8 张量：

```python
import streamlit as st
import tensorflow as tf

img_file_buffer = st.camera_input("Take a picture")

if img_file_buffer is not None:
    # To read image file buffer as a 3D uint8 tensor with TensorFlow:
    bytes_data = img_file_buffer.getvalue()
    img_tensor = tf.io.decode_image(bytes_data, channels=3)

    # Check the type of img_tensor:
    # Should output: <class 'tensorflow.python.framework.ops.EagerTensor'>
    st.write(type(img_tensor))

    # Check the shape of img_tensor:
    # Should output shape: (height, width, channels)
    st.write(img_tensor.shape)
```





### Torchvision

确保您已安装Torchvision（它未与PyTorch捆绑在一起）和PyTorch。

要使用 `torchvision.io` 将图像文件缓冲区读取为 3 维 uint8 张量：

```python
import streamlit as st
import torch
import torchvision

img_file_buffer = st.camera_input("Take a picture")

if img_file_buffer is not None:
    # To read image file buffer as a 3D uint8 tensor with `torchvision.io`:
    bytes_data = img_file_buffer.getvalue()
    torch_img = torchvision.io.decode_image(
        torch.frombuffer(bytes_data, dtype=torch.uint8)
    )

    # Check the type of torch_img:
    # Should output: <class 'torch.Tensor'>
    st.write(type(torch_img))

    # Check the shape of torch_img:
    # Should output shape: torch.Size([channels, height, width])
    st.write(torch_img.shape)
```



### PyTorch

确保您已安装 PyTorch 和 NumPy。

要使用 PyTorch 将图像文件缓冲区读取为 3 维 uint8 张量：

```python
import streamlit as st
import torch
import numpy as np

img_file_buffer = st.camera_input("Take a picture")

if img_file_buffer is not None:
    # To read image file buffer as a 3D uint8 tensor with PyTorch:
    bytes_data = img_file_buffer.getvalue()
    torch_img = torch.ops.image.decode_image(
        torch.from_numpy(np.frombuffer(bytes_data, np.uint8)), 3
    )

    # Check the type of torch_img:
    # Should output: <class 'torch.Tensor'>
    st.write(type(torch_img))

    # Check the shape of torch_img:
    # Should output shape: torch.Size([channels, height, width])
    st.write(torch_img.shape)
```





## st.color_picker

显示颜色选取器微件。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/color_picker.py#L52) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.color_picker(label, value=None, key=None, help=None, on_change=None, args=None, kwargs=None, *, disabled=False, label_visibility="visible") st.color_picker（label， value=None， key=None， help=None， on_change=None， args=None， kwargs=None， *， disabled=False， label_visibility=“visible”） |                                                              |
| Parameters                                                   |                                                              |
| **label** *(str)*                                            | A short label explaining to the user what this input is for. The label can optionally contain Markdown and supports the following elements: Bold, Italics, Strikethroughs, Inline Code, Emojis, and Links. 向用户解释此输入用途的简短标签。标签可以选择包含 Markdown 并支持以下元素：粗体、斜体、删除线、内联代码、表情符号和链接。This also supports: 这也支持：Emoji shortcodes, such as `:+1:` and `:sunglasses:`. For a list of all supported codes, see https://share.streamlit.io/streamlit/emoji-shortcodes. 表情符号短代码，例如 `:+1:` 和 `:sunglasses:` 。有关所有支持的代码的列表，请参阅 https://share.streamlit.io/streamlit/emoji-shortcodes 。LaTeX expressions, by wrapping them in "$" or "$$" (the "$$" must be on their own lines). Supported LaTeX functions are listed at https://katex.org/docs/supported.html. LaTeX 表达式，通过将它们包装在“$”或“$$”中（“$$”必须在它们自己的行上）。支持的 LaTeX 函数列在 https://katex.org/docs/supported.html 中。Colored text, using the syntax `:color[text to be colored]`, where `color` needs to be replaced with any of the following supported colors: blue, green, orange, red, violet. 彩色文本，使用语法 `:color[text to be colored]` ，其中 `color` 需要替换为以下任何受支持的颜色：蓝色、绿色、橙色、红色、紫色。Unsupported elements are unwrapped so only their children (text contents) render. Display unsupported elements as literal characters by backslash-escaping them. E.g. `1\. Not an ordered list`. 不受支持的元素将解开包装，以便仅呈现其子元素（文本内容）。通过反斜杠转义将不支持的元素显示为文字字符。例如 `1\. Not an ordered list` .For accessibility reasons, you should never set an empty label (label="") but hide it with label_visibility if needed. In the future, we may disallow empty labels by raising an exception. 出于辅助功能原因，切勿设置空标签 （label=“”），而应在需要时使用 label_visibility 将其隐藏。将来，我们可能会通过引发异常来禁止空标签。 |
| **value** *(str)*                                            | The hex value of this widget when it first renders. If None, defaults to black. 此小组件首次呈现时的十六进制值。如果为“无”，则默认为黑色。 |
| **key** *(str or int)* 键（STR 或 INT）                      | An optional string or integer to use as the unique key for the widget. If this is omitted, a key will be generated for the widget based on its content. Multiple widgets of the same type may not share the same key. 用作小组件唯一键的可选字符串或整数。如果省略此项，将根据其内容为小部件生成一个键。同一类型的多个小部件不能共享同一个键。 |
| **help** *(str)*                                             | An optional tooltip that gets displayed next to the color picker. 显示在颜色选取器旁边的可选工具提示。 |
| **on_change** *(callable)*                                   | An optional callback invoked when this color_picker's value changes. 当此color_picker的值更改时调用的可选回调。 |
| **args** *(tuple)*                                           | An optional tuple of args to pass to the callback. 要传递给回调的参数的可选元组。 |
| **kwargs** *(dict)*                                          | An optional dict of kwargs to pass to the callback. 要传递给回调的 kwargs 的可选字典。 |
| **disabled** *(bool)*                                        | An optional boolean, which disables the color picker if set to True. The default is False. This argument can only be supplied by keyword. 一个可选的布尔值，如果设置为 True，则禁用颜色选取器。默认值为 False。此参数只能由关键字提供。 |
| **label_visibility** *("visible" or "hidden" or "collapsed")* label_visibility（“可见”或“隐藏”或“折叠”） | The visibility of the label. If "hidden", the label doesn’t show but there is still empty space for it above the widget (equivalent to label=""). If "collapsed", both the label and the space are removed. Default is "visible". This argument can only be supplied by keyword. 标签的可见性。如果为“隐藏”，则标签不显示，但小部件上方仍有空白空间（相当于 label=“”）。如果“折叠”，则标签和空格都将被删除。默认值为“可见”。此参数只能由关键字提供。 |
| Returns                                                      |                                                              |
| *(str)*                                                      | The selected color as a hex string. 所选颜色作为十六进制字符串。 |

#### Example

> ```python
> import streamlit as st
> 
> color = st.color_picker('Pick A Color', '#00f900')
> st.write('The current color is', color)
> ```

![image-20230510070953663](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510070953451-263553067.png)



# Media elements

将图像、视频和音频文件直接嵌入到您的 Streamlit 应用程序中很容易。



## st.image

显示图像或图像列表。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/image.py#L88) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.image(image, caption=None, width=None, use_column_width=None, clamp=False, channels="RGB", output_format="auto") st.image（image， caption=none， width=none， use_column_width=none， clamp=False， 通道=“RGB”， output_format=“auto”） |                                                              |
| Parameters                                                   |                                                              |
| **image** *(numpy.ndarray, [numpy.ndarray], BytesIO, str, or [str])* image （numpy.ndarray， [numpy.ndarray]， BytesIO， str， or [str]） | Monochrome image of shape (w,h) or (w,h,1) OR a color image of shape (w,h,3) OR an RGBA image of shape (w,h,4) OR a URL to fetch the image from OR a path of a local image file OR an SVG XML string like <svg xmlns=...</svg> OR a list of one of the above, to display multiple images. 形状 （w，h） 或 （w，h，1） 的单色图像或形状的彩色图像 （w，h，3） 或形状 （w，h，4） 的 RGBA 图像或用于从本地图像文件的路径或 SVG XML 字符串（如 <svg xmlns=...</svg>或上述之一的列表，以显示多个图像。 |
| **caption** *(str or list of str)* 标题（STR 或 STR 列表）   | Image caption. If displaying multiple images, caption should be a list of captions (one for each image). 图片说明。如果显示多个图像，标题应为标题列表（每个图像一个）。 |
| **width** *(int or None)* 宽度（整数或无）                   | Image width. None means use the image width, but do not exceed the width of the column. Should be set for SVG images, as they have no default image width. 图像宽度。“无”表示使用图像宽度，但不要超过列的宽度。应为 SVG 图像设置，因为它们没有默认图像宽度。 |
| **use_column_width** *('auto' or 'always' or 'never' or bool)* use_column_width（“自动”或“总是”或“从不”或布尔值） | If 'auto', set the image's width to its natural size, but do not exceed the width of the column. If 'always' or True, set the image's width to the column width. If 'never' or False, set the image's width to its natural size. Note: if set, use_column_width takes precedence over the width parameter. 如果为“auto”，请将图像的宽度设置为其自然大小，但不要超过列的宽度。如果为“always”或 True，请将图像的宽度设置为列宽。如果为“从不”或 False，请将图像的宽度设置为其自然大小。注： 如果设置，则use_column_width优先于宽度参数。 |
| **clamp** *(bool)*                                           | Clamp image pixel values to a valid range ([0-255] per channel). This is only meaningful for byte array images; the parameter is ignored for image URLs. If this is not set, and an image has an out-of-range value, an error will be thrown. 将图像像素值钳制到有效范围（每通道 [0-255]）。这仅对字节数组图像有意义;对于图像 URL，将忽略该参数。如果未设置此选项，并且图像的值超出范围，则会引发错误。 |
| **channels** *('RGB' or 'BGR')* 通道（“RGB”或“BGR”）         | If image is an nd.array, this parameter denotes the format used to represent color information. Defaults to 'RGB', meaning image[:, :, 0] is the red channel, image[:, :, 1] is green, and image[:, :, 2] is blue. For images coming from libraries like OpenCV you should set this to 'BGR', instead. 如果图像是 nd.array，则此参数表示用于表示颜色信息的格式。默认为“RGB”，表示图像[：， ：， 0]是红色通道，图像[：， ：， 1]是绿色，图像[：， ：， 2]是蓝色。对于来自OpenCV等库的图像，您应该将其设置为“BGR”。 |
| **output_format** *('JPEG', 'PNG', or 'auto')* output_format（“JPEG”、“PNG”或“自动”） | This parameter specifies the format to use when transferring the image data. Photos should use the JPEG format for lossy compression while diagrams should use the PNG format for lossless compression. Defaults to 'auto' which identifies the compression type based on the type and format of the image argument. 此参数指定传输图像数据时要使用的格式。照片应使用 JPEG 格式进行有损压缩，而图表应使用 PNG 格式进行无损压缩。默认为“auto”，它根据图像参数的类型和格式标识压缩类型。 |

#### Example

> ```python
> import streamlit as st
> from PIL import Image
> 
> image = Image.open('sunrise.jpg')
> 
> st.image(image, caption='Sunrise by the mountains')
> ```

![image-20230510071047887](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510071048919-95264071.png)



## st.audio

显示音频播放器。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/media.py#L43) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.audio(data, format="audio/wav", start_time=0, *, sample_rate=None) st.audio（data， format=“audio/wav”， start_time=0， *， sample_rate=None） |                                                              |
| Parameters                                                   |                                                              |
| **data** *(str, bytes, BytesIO, numpy.ndarray, or file opened with)* 数据（str、bytes、BytesIO、numpy.ndarray 或打开时使用的文件） | io.open(). Raw audio data, filename, or a URL pointing to the file to load. Raw data formats must include all necessary file headers to match the file format specified via `format`. If `data` is a numpy array, it must either be a 1D array of the waveform or a 2D array of shape `(num_channels, num_samples)` with waveforms for all channels. See the default channel order at http://msdn.microsoft.com/en-us/library/windows/hardware/dn653308(v=vs.85).aspx io.open（）.原始音频数据、文件名或指向要加载的文件的 URL。原始数据格式必须包含所有必要的文件头，以匹配通过 `format` 指定的文件格式。如果 `data` 是 numpy 数组，则它必须是波形的一维数组或形状为 `(num_channels, num_samples)` 的二维数组，其中包含所有通道的波形。在 http://msdn.microsoft.com/en-us/library/windows/hardware/dn653308(v=vs.85).aspx 处查看默认通道顺序 |
| **format** *(str)*                                           | The mime type for the audio file. Defaults to 'audio/wav'. See https://tools.ietf.org/html/rfc4281 for more info. 音频文件的 MIME 类型。默认为“音频/波形”。有关详细信息，请参阅 https://tools.ietf.org/html/rfc4281 。 |
| **start_time** *(int)*                                       | The time from which this element should start playing. 此元素应开始播放的时间。 |
| **sample_rate** *(int or None)* sample_rate（整数或无）      | The sample rate of the audio data in samples per second. Only required if `data` is a numpy array. 音频数据的采样率（以每秒采样数为单位）。仅当 `data` 是 numpy 数组时才需要。 |

#### Example

> ```python
> import streamlit as st
> import numpy as np
> 
> audio_file = open('myaudio.ogg', 'rb')
> audio_bytes = audio_file.read()
> 
> st.audio(audio_bytes, format='audio/ogg')
> 
> sample_rate = 44100  # 44100 samples per second
> seconds = 2  # Note duration of 2 seconds
> frequency_la = 440  # Our played note will be 440 Hz
> # Generate array with seconds*sample_rate steps, ranging between 0 and seconds
> t = np.linspace(0, seconds, seconds * sample_rate, False)
> # Generate a 440 Hz sine wave
> note_la = np.sin(frequency_la * t * 2 * np.pi)
> 
> st.audio(note_la, sample_rate=sample_rate)
> ```

![image-20230510071127205](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510071127234-1328495294.png)

## st.video

显示视频播放器。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/media.py#L117) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.video(data, format="video/mp4", start_time=0) st.video（data， format=“video/mp4”， start_time=0） |                                                              |
| Parameters                                                   |                                                              |
| **data** *(str, bytes, BytesIO, numpy.ndarray, or file opened with)* 数据（str、bytes、BytesIO、numpy.ndarray 或打开时使用的文件） | io.open(). Raw video data, filename, or URL pointing to a video to load. Includes support for YouTube URLs. Numpy arrays and raw data formats must include all necessary file headers to match specified file format. io.open（）.原始视频数据、文件名或指向要加载的视频的 URL。包括对 YouTube 网址的支持。Numpy 数组和原始数据格式必须包含所有必要的文件头以匹配指定的文件格式。 |
| **format** *(str)*                                           | The mime type for the video file. Defaults to 'video/mp4'. See https://tools.ietf.org/html/rfc4281 for more info. 视频文件的 MIME 类型。默认为“视频/mp4”。有关详细信息，请参阅 https://tools.ietf.org/html/rfc4281 。 |
| **start_time** *(int)*                                       | The time from which this element should start playing. 此元素应开始播放的时间。 |

#### Example

> ```python
> import streamlit as st
> 
> video_file = open('myvideo.mp4', 'rb')
> video_bytes = video_file.read()
> 
> st.video(video_bytes)
> ```

![image-20230510071211114](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510071211440-1067700913.png)



# Layouts and Containers

## Complex layouts

流光提供了多个选项，用于控制不同元素在屏幕上的布局方式。

![image-20230510071255585](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510071255767-1902395168.png)

![image-20230510071312659](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510071312468-715427956.png)



## st.sidebar

### Add widgets to sidebar

您不仅可以使用小部件为应用程序添加交互性，还可以将它们组织到侧边栏中。可以使用对象表示法和 `with` 表示法将元素传递给 `st.sidebar` 。

以下两个代码段是等效的：

```python
# Object notation
st.sidebar.[element_name]
```

```python
# "with" notation
with st.sidebar:
    st.[element_name]
```

传递给 `st.sidebar` 的每个元素都固定在左侧，使用户能够专注于应用中的内容。

**Tip：**

侧边栏可调整大小！拖放侧边栏的右边框以调整其大小！↔️

下面是如何将选择框和单选按钮添加到边栏的示例：

```python
import streamlit as st

# Using object notation
add_selectbox = st.sidebar.selectbox(
    "How would you like to be contacted?",
    ("Email", "Home phone", "Mobile phone")
)

# Using "with" notation
with st.sidebar:
    add_radio = st.radio(
        "Choose a shipping method",
        ("Standard (5-15 days)", "Express (2-5 days)")
    )
```

唯一不支持使用对象表示法的元素是 `st.echo` 和 `st.spinner` 。若要使用这些元素，必须使用 `with` 表示法。

下面是如何将 `st.echo` 和 `st.spinner` 添加到侧边栏的示例：

```python
import streamlit as st

with st.sidebar:
    with st.echo():
        st.write("This code will be printed to the sidebar.")

    with st.spinner("Loading..."):
        time.sleep(5)
    st.success("Done!")
```



## st.columns

插入并排排列的容器。

插入多个并排布局的多元素容器，并返回容器对象的列表。

若要将元素添加到返回的容器中，可以使用“with”表示法（首选）或直接在返回的对象上调用方法。

列只能放置在其他列中，最多只能放置一个嵌套级别。

列不能放置在边栏中的其他列内。这只能在应用程序的主要区域实现。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/layouts.py#L77) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.columns(spec, *, gap="small") st.columns（spec， *， gap=“small”） |                                                              |
| Parameters                                                   |                                                              |
| **spec** *(int or list of numbers)* 规范（整数或数字列表）   | If an int 如果 intSpecifies the number of columns to insert, and all columns have equal width. 指定要插入的列数，并且所有列的宽度相等。If a list of numbers 如果数字列表Creates a column for each number, and each column's width is proportional to the number provided. Numbers can be ints or floats, but they must be positive. 为每个数字创建一个列，每个列的宽度与提供的数字成正比。数字可以是整数或浮点数，但它们必须是正数。For example, st.columns([3, 1, 2]) creates 3 columns where the first column is 3 times the width of the second, and the last column is 2 times that width. 例如，st.columns（[3， 1， 2]） 创建 3 列，其中第一列的宽度是第二列的 3 倍，最后一列是该宽度的 2 倍。 |
| **gap** *(string ("small", "medium", or "large"))* 间隙（字符串（“小”、“中”或“大”）） | An optional string, which indicates the size of the gap between each column. The default is a small gap between columns. This argument can only be supplied by keyword. 一个可选字符串，指示每列之间的间距大小。默认值为列之间的小间距。此参数只能由关键字提供。 |
| Returns                                                      |                                                              |
| *(list of containers) （容器列表）*                          | A list of container objects. 容器对象的列表。                |

#### Examples

您可以使用表示法将任何元素插入到列中：

```python
import streamlit as st

col1, col2, col3 = st.columns(3)

with col1:
   st.header("A cat")
   st.image("https://static.streamlit.io/examples/cat.jpg")

with col2:
   st.header("A dog")
   st.image("https://static.streamlit.io/examples/dog.jpg")

with col3:
   st.header("An owl")
   st.image("https://static.streamlit.io/examples/owl.jpg")
```

![image-20230510071537531](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510071538826-163557985.png)

或者你可以直接在返回的对象中调用方法：

```python
import streamlit as st
import numpy as np

col1, col2 = st.columns([3, 1])
data = np.random.randn(10, 1)

col1.subheader("A wide column with a chart")
col1.line_chart(data)

col2.subheader("A narrow column with the data")
col2.write(data)
```

![image-20230510071604673](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510071604449-1341969910.png)

## st.tabs

插入分隔到选项卡中的容器。

将多个多元素容器作为选项卡插入。选项卡是一种导航元素，允许用户在相关内容组之间轻松移动。

若要将元素添加到返回的容器中，可以使用“with”表示法（首选）或直接在返回的对象上调用方法。请参阅以下示例。

**Warning**

每个选项卡的所有内容始终发送到前端并在前端呈现。目前不支持条件呈现。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/layouts.py#L208) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.tabs(tabs)                                                |                                                              |
| Parameters                                                   |                                                              |
| **tabs** *(list of strings)* 制表符（字符串列表）            | Creates a tab for each string in the list. The first tab is selected by default. The string is used as the name of the tab and can optionally contain Markdown, supporting the following elements: Bold, Italics, Strikethroughs, Inline Code, Emojis, and Links. 为列表中的每个字符串创建一个制表符。默认情况下，第一个选项卡处于选中状态。该字符串用作选项卡的名称，可以选择包含 Markdown，支持以下元素：粗体、斜体、删除线、内联代码、表情符号和链接。This also supports: 这也支持：Emoji shortcodes, such as `:+1:` and `:sunglasses:`. For a list of all supported codes, see https://share.streamlit.io/streamlit/emoji-shortcodes. 表情符号短代码，例如 `:+1:` 和 `:sunglasses:` 。有关所有支持的代码的列表，请参阅 https://share.streamlit.io/streamlit/emoji-shortcodes 。LaTeX expressions, by wrapping them in "$" or "$$" (the "$$" must be on their own lines). Supported LaTeX functions are listed at https://katex.org/docs/supported.html. LaTeX 表达式，通过将它们包装在“$”或“$$”中（“$$”必须在它们自己的行上）。支持的 LaTeX 函数列在 https://katex.org/docs/supported.html 中。Colored text, using the syntax `:color[text to be colored]`, where `color` needs to be replaced with any of the following supported colors: blue, green, orange, red, violet. 彩色文本，使用语法 `:color[text to be colored]` ，其中 `color` 需要替换为以下任何受支持的颜色：蓝色、绿色、橙色、红色、紫色。Unsupported elements are unwrapped so only their children (text contents) render. Display unsupported elements as literal characters by backslash-escaping them. E.g. `1\. Not an ordered list`. 不受支持的元素将解开包装，以便仅呈现其子元素（文本内容）。通过反斜杠转义将不支持的元素显示为文字字符。例如 `1\. Not an ordered list` . |
| Returns                                                      |                                                              |
| *(list of containers) （容器列表）*                          | A list of container objects. 容器对象的列表。                |

#### Examples

您可以使用表示法将任何元素插入到选项卡中：

```python
import streamlit as st

tab1, tab2, tab3 = st.tabs(["Cat", "Dog", "Owl"])

with tab1:
   st.header("A cat")
   st.image("https://static.streamlit.io/examples/cat.jpg", width=200)

with tab2:
   st.header("A dog")
   st.image("https://static.streamlit.io/examples/dog.jpg", width=200)

with tab3:
   st.header("An owl")
   st.image("https://static.streamlit.io/examples/owl.jpg", width=200)
```

![image-20230510071736255](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510071736247-643883205.png)

或者你可以直接在返回的对象中调用方法：

```python
import streamlit as st
import numpy as np

tab1, tab2 = st.tabs(["📈 Chart", "🗃 Data"])
data = np.random.randn(10, 1)

tab1.subheader("A tab with a chart")
tab1.line_chart(data)

tab2.subheader("A tab with the data")
tab2.write(data)
```

![image-20230510071753248](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510071753016-1740775835.png)



## st.expander

插入可以展开/折叠的多元素容器。

在应用中插入一个容器，该容器可用于保存多个元素，并且可以由用户展开或折叠。折叠时，可见的只是提供的标签。

若要将元素添加到返回的容器，可以使用“with”表示法（首选）或直接在返回的对象上调用方法。请参阅以下示例。

**Warning**

目前，您不能将扩展器放入另一个扩展器中。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/layouts.py#L320) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.expander(label, expanded=False) st.expander（label， expanded=False） |                                                              |
| Parameters                                                   |                                                              |
| **label** *(str)*                                            | A string to use as the header for the expander. The label can optionally contain Markdown and supports the following elements: Bold, Italics, Strikethroughs, Inline Code, Emojis, and Links. 用作扩展器的标头的字符串。标签可以选择包含 Markdown 并支持以下元素：粗体、斜体、删除线、内联代码、表情符号和链接。This also supports: 这也支持：Emoji shortcodes, such as `:+1:` and `:sunglasses:`. For a list of all supported codes, see https://share.streamlit.io/streamlit/emoji-shortcodes. 表情符号短代码，例如 `:+1:` 和 `:sunglasses:` 。有关所有支持的代码的列表，请参阅 https://share.streamlit.io/streamlit/emoji-shortcodes 。LaTeX expressions, by wrapping them in "$" or "$$" (the "$$" must be on their own lines). Supported LaTeX functions are listed at https://katex.org/docs/supported.html. LaTeX 表达式，通过将它们包装在“$”或“$$”中（“$$”必须在它们自己的行上）。支持的 LaTeX 函数列在 https://katex.org/docs/supported.html 中。Colored text, using the syntax `:color[text to be colored]`, where `color` needs to be replaced with any of the following supported colors: blue, green, orange, red, violet. 彩色文本，使用语法 `:color[text to be colored]` ，其中 `color` 需要替换为以下任何受支持的颜色：蓝色、绿色、橙色、红色、紫色。Unsupported elements are unwrapped so only their children (text contents) render. Display unsupported elements as literal characters by backslash-escaping them. E.g. `1\. Not an ordered list`. 不受支持的元素将解开包装，以便仅呈现其子元素（文本内容）。通过反斜杠转义将不支持的元素显示为文字字符。例如 `1\. Not an ordered list` . |
| **expanded** *(bool)*                                        | If True, initializes the expander in "expanded" state. Defaults to False (collapsed). 如果为 True，则初始化处于“已扩展”状态的扩展器。默认值为 False（折叠）。 |

#### Examples

您可以使用符号将任何元素插入到扩展器中

```python
import streamlit as st

st.bar_chart({"data": [1, 5, 2, 6, 2, 1]})

with st.expander("See explanation"):
    st.write(\"\"\"
        The chart above shows some numbers I picked for you.
        I rolled actual dice for these, so they're *guaranteed* to
        be random.
    \"\"\")
    st.image("https://static.streamlit.io/examples/dice.jpg")
```

![image-20230510071900009](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510071859721-866752829.png)

或者你可以直接在返回的对象中调用方法：

```python
import streamlit as st

st.bar_chart({"data": [1, 5, 2, 6, 2, 1]})

expander = st.expander("See explanation")
expander.write(\"\"\"
    The chart above shows some numbers I picked for you.
    I rolled actual dice for these, so they're *guaranteed* to
    be random.
\"\"\")
expander.image("https://static.streamlit.io/examples/dice.jpg")
```

![image-20230510071917021](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510071916742-952817230.png)



## st.container

插入多元素容器。

在你的应用程序中插入一个无形的容器，可以用来容纳多个元素。这允许你，例如，在你的应用程序中不按顺序插入多个元素。

若要将元素添加到返回的容器，可以使用“with”表示法（首选）或直接在返回的对象上调用方法。请参阅以下示例。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/layouts.py#L29) |
| ------------------------------------------------------------ |
| st.container()                                               |

#### Examples

```python
import streamlit as st

with st.container():
   st.write("This is inside the container")

   # You can call any Streamlit command, including custom components:
   st.bar_chart(np.random.randn(50, 3))

st.write("This is outside the container")
```

![image-20230510072050743](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510072050663-1286184806.png)

Inserting elements out of order: 

```python
import streamlit as st

container = st.container()
container.write("This is inside the container")
st.write("This is outside the container")

# Now insert some more in the container
container.write("This is inside too")
```

![image-20230510072126955](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510072126648-1471820109.png)



## st.empty

插入单元素容器。

在应用中插入可用于保存单个元素的容器。例如，这允许您随时删除元素，或一次替换多个元素（使用子多元素容器）。

若要在返回的容器上插入/替换/清除元素，可以使用“with”表示法或直接在返回的对象上调用方法。请参阅以下示例。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/empty.py#L24) |
| ------------------------------------------------------------ |
| st.empty()                                                   |

#### Examples

使用“with”表示法就地覆盖元素：

```python
import streamlit as st
import time

with st.empty():
    for seconds in range(60):
        st.write(f"⏳ {seconds} seconds have passed")
        time.sleep(1)
    st.write("✔️ 1 minute over!")
```

替换几个元素，然后清除它们：

```python
import streamlit as st

placeholder = st.empty()

# Replace the placeholder with some text:
placeholder.text("Hello")

# Replace the text with a chart:
placeholder.line_chart({"data": [1, 5, 2, 6]})

# Replace the chart with several elements:
with placeholder.container():
    st.write("This is one element")
    st.write("This is another")

# Clear all those elements:
placeholder.empty()
```





# Status elements

# Display progress and status

Streamlit 提供了一些方法，允许您向应用添加动画。这些动画包括进度条、状态消息（如警告）和庆祝气球。

![image-20230510072342908](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510072342935-636066745.png)

![image-20230510072355767](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510072355611-2062647868.png)

![image-20230510072405804](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510072405609-1425130827.png)



## st.progress

显示进度条。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/progress.py#L66) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.progress(value, text=None) st.progress（值，文本=无）     |                                                              |
| Parameters                                                   |                                                              |
| **value** *(int or float)* 值（整数或浮点数）                | 0 <= value <= 100 for int 0 <= 值 <= 100 表示 int0.0 <= value <= 1.0 for float 0.0 <= 浮点值 <= 1.0 |
| **text** *(str or None)* 文本（str 或 none）                 | A message to display above the progress bar. The text can optionally contain Markdown and supports the following elements: Bold, Italics, Strikethroughs, Inline Code, Emojis, and Links. 要在进度栏上方显示的消息。文本可以选择包含 Markdown 并支持以下元素：粗体、斜体、删除线、内联代码、表情符号和链接。This also supports: 这也支持：Emoji shortcodes, such as `:+1:` and `:sunglasses:`. For a list of all supported codes, see https://share.streamlit.io/streamlit/emoji-shortcodes. 表情符号短代码，例如 `:+1:` 和 `:sunglasses:` 。有关所有支持的代码的列表，请参阅 https://share.streamlit.io/streamlit/emoji-shortcodes 。LaTeX expressions, by wrapping them in "$" or "$$" (the "$$" must be on their own lines). Supported LaTeX functions are listed at https://katex.org/docs/supported.html. LaTeX 表达式，通过将它们包装在“$”或“$$”中（“$$”必须在它们自己的行上）。支持的 LaTeX 函数列在 https://katex.org/docs/supported.html 中。Colored text, using the syntax `:color[text to be colored]`, where `color` needs to be replaced with any of the following supported colors: blue, green, orange, red, violet. 彩色文本，使用语法 `:color[text to be colored]` ，其中 `color` 需要替换为以下任何受支持的颜色：蓝色、绿色、橙色、红色、紫色。Unsupported elements are unwrapped so only their children (text contents) render. Display unsupported elements as literal characters by backslash-escaping them. E.g. `1\. Not an ordered list`. 不受支持的元素将解开包装，以便仅呈现其子元素（文本内容）。通过反斜杠转义将不支持的元素显示为文字字符。例如 `1\. Not an ordered list` . |

#### Example

下面是进度条随时间增加的示例：

```python
import streamlit as st
import time

progress_text = "Operation in progress. Please wait."
my_bar = st.progress(0, text=progress_text)

for percent_complete in range(100):
    time.sleep(0.1)
    my_bar.progress(percent_complete + 1, text=progress_text)
```





## st.spinner

在执行代码块时临时显示消息。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/spinner.py#L23) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.spinner(text="In progress...") st.spinner（text=“进行中...”） |                                                              |
| Parameters                                                   |                                                              |
| **text** *(str)*                                             | A message to display while executing that block 执行该块时要显示的消息 |

#### Example

> ```python
> import time
> import streamlit as st
> 
> with st.spinner('Wait for it...'):
>     time.sleep(5)
> st.success('Done!')
> ```





## st.balloons

画庆祝气球。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/balloons.py#L25) |
| ------------------------------------------------------------ |
| st.balloons()                                                |

#### Example

> ```python
> import streamlit as st
> 
> st.balloons()
> ```

..然后观看您的应用程序并准备好庆祝！



## st.snow

画庆祝降雪。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/snow.py#L25) |
| ------------------------------------------------------------ |
| st.snow()                                                    |

#### Example

> ```python
> import streamlit as st
> 
> st.snow()
> ```





## st.error

显示错误消息。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/alert.py#L39) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.error(body, *, icon=None) st.error（body， *， icon=None） |                                                              |
| Parameters                                                   |                                                              |
| **body** *(str)*                                             | The error text to display. 要显示的错误文本。                |
| **icon** *(str or None)* 图标（str 或 none）                 | An optional, keyword-only argument that specifies an emoji to use as the icon for the alert. Shortcodes are not allowed, please use a single character instead. E.g. "🚨", "🔥", "🤖", etc. Defaults to None, which means no icon is displayed. 一个可选的、仅限关键字的参数，用于指定要用作警报图标的表情符号。不允许使用短代码，请改用单个字符。例如“🚨”、“”、“🔥 🤖”等。默认为“无”，表示不显示任何图标。 |

#### Example

> ```python
> import streamlit as st
> 
> st.error('This is an error', icon="🚨")
> ```



## st.warning

显示警告消息。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/alert.py#L71) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.warning(body, *, icon=None) st.warning（body， *， icon=None） |                                                              |
| Parameters                                                   |                                                              |
| **body** *(str)*                                             | The warning text to display. 要显示的警告文本。              |
| **icon** *(str or None)* 图标（str 或 none）                 | An optional, keyword-only argument that specifies an emoji to use as the icon for the alert. Shortcodes are not allowed, please use a single character instead. E.g. "🚨", "🔥", "🤖", etc. Defaults to None, which means no icon is displayed. 一个可选的、仅限关键字的参数，用于指定要用作警报图标的表情符号。不允许使用短代码，请改用单个字符。例如“🚨”、“”、“🔥 🤖”等。默认为“无”，表示不显示任何图标。 |

#### Example

> ```python
> import streamlit as st
> 
> st.warning('This is a warning', icon="⚠️")
> ```



## st.info

显示信息性消息。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/alert.py#L103) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.info(body, *, icon=None) st.info（正文、*、图标=无）      |                                                              |
| Parameters                                                   |                                                              |
| **body** *(str)*                                             | The info text to display. 要显示的信息文本。                 |
| **icon** *(str or None)* 图标（str 或 none）                 | An optional, keyword-only argument that specifies an emoji to use as the icon for the alert. Shortcodes are not allowed, please use a single character instead. E.g. "🚨", "🔥", "🤖", etc. Defaults to None, which means no icon is displayed. 一个可选的、仅限关键字的参数，用于指定要用作警报图标的表情符号。不允许使用短代码，请改用单个字符。例如“🚨”、“”、“🔥 🤖”等。默认为“无”，表示不显示任何图标。 |

#### Example

> ```python
> import streamlit as st
> 
> st.info('This is a purely informational message', icon="ℹ️")
> ```



## st.success

显示成功消息。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/alert.py#L136) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.success(body, *, icon=None) st.success（body， *， icon=None） |                                                              |
| Parameters                                                   |                                                              |
| **body** *(str)*                                             | The success text to display. 要显示的成功文本。              |
| **icon** *(str or None)* 图标（str 或 none）                 | An optional, keyword-only argument that specifies an emoji to use as the icon for the alert. Shortcodes are not allowed, please use a single character instead. E.g. "🚨", "🔥", "🤖", etc. Defaults to None, which means no icon is displayed. 一个可选的、仅限关键字的参数，用于指定要用作警报图标的表情符号。不允许使用短代码，请改用单个字符。例如“🚨”、“”、“🔥 🤖”等。默认为“无”，表示不显示任何图标。 |

#### Example

> ```python
> import streamlit as st
> 
> st.success('This is a success message!', icon="✅")
> ```



## st.exception

显示异常。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/exception.py#L50) |                                          |
| ------------------------------------------------------------ | ---------------------------------------- |
| st.exception(exception) 圣例外（例外）                       |                                          |
| Parameters                                                   |                                          |
| **exception** *(Exception)*                                  | The exception to display. 要显示的异常。 |

#### Example

> ```python
> import streamlit as st
> 
> e = RuntimeError('This is an exception of type RuntimeError')
> st.exception(e)
> ```





# Control flow

## Change execution

默认情况下，Streamlit 应用完全执行脚本，但我们允许某些功能来处理应用程序中的控制流。

![image-20230510072742111](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510072741929-1213407360.png)

## st.stop

立即停止执行。

Streamlit 不会在 st.stop（） 之后运行任何语句。我们建议呈现一条消息来解释脚本停止的原因。当在 Streamlit 外部运行时，这将引发异常。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/commands/execution_control.py#L25) |
| ------------------------------------------------------------ |
| st.stop()                                                    |

#### Example

> ```python
> import streamlit as st
> 
> name = st.text_input('Name')
> if not name:
>   st.warning('Please input a name.')
>   st.stop()
> st.success('Thank you for inputting a name.')
> ```



## st.experimental_rerun

立即重新运行脚本。

调用 st.experimental_rerun（） 时，脚本将停止 - 不再运行语句，并且脚本将排队等待从顶部重新运行。

如果在 Streamlit 外部调用此函数，它将引发异常。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/commands/execution_control.py#L46) |
| ------------------------------------------------------------ |
| st.experimental_rerun() st.experimental_rerun（）            |



## Group multiple widgets

默认情况下，每次用户与您的应用交互时，Streamlit 都会重新运行您的脚本。但是，有时等到一组相关小部件填满后再实际重新运行脚本会更好。这就是 `st.form` 的用途！

![image-20230510072911121](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230510072911041-1563902949.png)

## st.form

创建一个表单，该表单使用“提交”按钮将元素批处理在一起。

表单是一个容器，用于直观地将其他元素和小部件组合在一起，并包含一个“提交”按钮。当按下表单的“提交”按钮时，表单内的所有小部件值都将批量发送到 Streamlit。

若要向表单对象添加元素，可以使用“with”表示法（首选）或直接在表单上调用方法。请参阅以下示例。

表单有一些约束：

- 每个表单都必须包含 `st.form_submit_button` 。
- `st.button` 和 `st.download_button` 无法添加到表单中。
- 表单可以显示在 App 中的任何位置（边栏、列等），但不能嵌入到其他表单中。

有关表单的更多信息，请查看我们的博客文章。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/form.py#L118) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.form(key, clear_on_submit=False) st.form（key， clear_on_submit=False） |                                                              |
| Parameters                                                   |                                                              |
| **key** *(str)*                                              | A string that identifies the form. Each form must have its own key. (This key is not displayed to the user in the interface.) 标识窗体的字符串。每个表单都必须有自己的密钥。（此键不会在界面中向用户显示。 |
| **clear_on_submit** *(bool)*                                 | If True, all widgets inside the form will be reset to their default values after the user presses the Submit button. Defaults to False. (Note that Custom Components are unaffected by this flag, and will not be reset to their defaults on form submission.) 如果为 True，则在用户按下“提交”按钮后，表单中的所有小组件都将重置为其默认值。默认为 False。（请注意，自定义组件不受此标志的影响，并且不会在表单提交时重置为其默认值。 |

#### Examples

使用“with”表示法插入元素：

```python
import streamlit as st

with st.form("my_form"):
   st.write("Inside the form")
   slider_val = st.slider("Form slider")
   checkbox_val = st.checkbox("Form checkbox")

   # Every form must have a submit button.
   submitted = st.form_submit_button("Submit")
   if submitted:
       st.write("slider", slider_val, "checkbox", checkbox_val)

st.write("Outside the form")
```

不按顺序插入元素：

```python
import streamlit as st

form = st.form("my_form")
form.slider("Inside the form")
st.slider("Outside the form")

# Now add a submit button to the form:
form.form_submit_button("Submit")
```



## st.form_submit_button

显示表单提交按钮。

单击此按钮时，表单中的所有小部件值都将批量发送到 Streamlit。

每个表格都必须有一个form_submit_button。form_submit_button不能存在于表单之外。

有关表单的更多信息，请查看我们的博客文章。

| Function signature 函数签名[[source\]](https://github.com/streamlit/streamlit/blob/1.22.0/lib/streamlit/elements/form.py#L211) |                                                              |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| st.form_submit_button(label="Submit", help=None, on_click=None, args=None, kwargs=None, *, type="secondary", disabled=False, use_container_width=False) st.form_submit_button（label=“Submit”， help=None， on_click=None， args=None， kwargs=None， *， type=“secondary”， disabled=False， use_container_width=False） |                                                              |
| Parameters                                                   |                                                              |
| **label** *(str)*                                            | A short label explaining to the user what this button is for. Defaults to "Submit". 向用户解释此按钮用途的简短标签。默认为“提交”。 |
| **help** *(str or None)* 帮助（str 或无）                    | A tooltip that gets displayed when the button is hovered over. Defaults to None. 将鼠标悬停在按钮上时显示的工具提示。默认为“无”。 |
| **on_click** *(callable)*                                    | An optional callback invoked when this button is clicked. 单击此按钮时调用的可选回调。 |
| **args** *(tuple)*                                           | An optional tuple of args to pass to the callback. 要传递给回调的参数的可选元组。 |
| **kwargs** *(dict)*                                          | An optional dict of kwargs to pass to the callback. 要传递给回调的 kwargs 的可选字典。 |
| **type** *("secondary" or "primary")* 类型（“辅助”或“主要”） | An optional string that specifies the button type. Can be "primary" for a button with additional emphasis or "secondary" for a normal button. This argument can only be supplied by keyword. Defaults to "secondary". 指定按钮类型的可选字符串。对于具有附加强调的按钮，可以是“主要”，对于普通按钮，可以是“次要”。此参数只能由关键字提供。默认为“辅助”。 |
| **disabled** *(bool)*                                        | An optional boolean, which disables the button if set to True. The default is False. This argument can only be supplied by keyword. 一个可选的布尔值，如果设置为 True，则禁用该按钮。默认值为 False。此参数只能由关键字提供。 |
| **use_container_width** *(bool)* use_container_width（布尔值） | An optional boolean, which makes the button stretch its width to match the parent container. 可选的布尔值，它使按钮拉伸其宽度以匹配父容器。 |
| Returns                                                      |                                                              |
| *(bool)*                                                     | True if the button was clicked.                              |



# Utilities

## Placeholders, help, and options

有一些方法可用于在应用中创建占位符、使用 doc 字符串提供帮助、获取和修改配置选项以及查询参数。