[toc]



随着应用程序变得越来越大，将它们组织成多个页面变得很有用。这使得应用程序更容易作为开发人员进行管理，并且更易于作为用户进行导航。 Streamlit 提供了一种创建多页应用程序的顺畅方式。页面会自动显示在应用侧边栏内的一个漂亮的导航小部件中，单击页面将导航到该页面而无需重新加载前端 - 使应用浏览速度非常快！

在上一页中，我们创建了一个“单页应用程序”来探索纽约市接送服务的公共优步数据集。在本指南中，让我们学习如何创建多页应用程序。一旦我们对创建多页应用程序有了坚实的基础，让我们在下一节中为自己构建一个！



# Structuring multipage apps

*Structuring：构建*

让我们了解创建多页应用程序需要什么——包括如何定义页面、构造和运行多页应用程序，以及在用户界面中的页面之间导航。



# Run a multipage app

运行多页应用程序与运行单页应用程序相同。运行多页应用程序的命令是：

```python
streamlit run [entrypoint file]
```

“入口点文件”是应用程序将显示给用户的第一个页面。将页面添加到应用程序后，入口点文件将显示为侧边栏中的最顶层页面。您可以将入口点文件视为应用程序的“主页”。例如，假设您的入口点文件是 `Home.py` 。然后，要运行您的应用程序，您可以运行 `streamlit run Home.py` 。这将启动您的应用程序并执行 `Home.py` 中的代码。



# Adding pages

创建入口点文件后，您可以通过在与入口点文件相关的 `pages/` 目录中创建 `.py` 文件来添加页面。例如，如果您的入口点文件是 `Home.py` ，那么您可以创建一个 `pages/About.py` 文件来定义“关于”页面。这是多页应用程序的有效目录结构：

```
Home.py # This is the file you run with "streamlit run"
└─── pages/
  └─── About.py # This is a page
  └─── 2_Page_two.py # This is another page
  └─── 3_😎_three.py # So is this
```

将表情符号添加到文件名时，最好包含一个数字前缀，以便在终端中更轻松地自动完成。终端自动完成可能会被 unicode（表情符号的表示方式）弄糊涂。

页面被定义为 `pages/` 目录中的 `.py` 文件。页面的文件名根据以下部分中的规则转换为侧边栏中的页面名称。例如， `About.py` 文件在侧边栏中显示为“关于”， `2_Page_two.py` 显示为“第二页”， `3_😎_three.py` 显示为“😎三”：

![Directory structure](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509222717749-841569450.png)

只有 `pages/` 目录中的 `.py` 文件将作为页面加载。 Streamlit 忽略 `pages/` 目录和子目录中的所有其他文件。



# How pages are labeled and sorted in the UI

侧边栏 UI 中的页面标签是从文件名生成的。它们可能与 `st.set_page_config` 中设置的页面标题不同。让我们了解什么构成页面的有效文件名、页面如何显示在边栏中以及页面如何排序。



## Valid filenames for pages

*Valid ：有效的*

文件名由四个不同的部分组成：

1. A `number` — 如果文件以数字为前缀。
2. 分隔符 — 可以是 `_` 、 `-` 、空格或其任意组合。
3. `label` — 这是 `.py` 之前的所有内容，但不包括 `.py` 。
4. 扩展名——总是 `.py` 。



## How pages are displayed in the sidebar

侧边栏中显示的是文件名的 `label` 部分：

- 如果没有 `label` ，Streamlit 使用 `number` 作为标签。
- 在 UI 中，Streamlit 通过将 `_` 替换为空格来美化 `label` 。



## How pages are sorted in the sidebar

排序将文件名中的数字视为实际数字（整数）：

- 带有 `number` 的文件出现在没有 `number` 的文件之前。
- 文件根据 `number` （如果有）排序，然后是 `title` （如果有）
- 对文件进行排序时，Streamlit 将 `number` 视为实际数字而不是字符串。所以 `03` 与 `3` 相同。

此表显示文件名及其相应标签的示例，按它们在侧边栏中出现的顺序排序。

**Examples**:

| **Filename**              | **Rendered label**              |
| ------------------------- | ------------------------------- |
| `1 - first page.py`       | first page                      |
| `12 monkeys.py`           | monkeys                         |
| `123.py`                  | 123                             |
| `123_hello_dear_world.py` | hello dear world 你好亲爱的世界 |
| `_12 monkeys.py`          | 12 monkeys                      |

表情符号可用于使您的页面名称更有趣！例如，名为 `🏠_Home.py` 的文件将在侧边栏中创建一个标题为“🏠 Home”的页面。



## Navigating between pages 

*Navigating：导航*

页面会自动显示在应用程序侧边栏内漂亮的导航 UI 中。当您单击侧边栏 UI 中的页面时，Streamlit 会导航到该页面而无需重新加载整个前端——使应用程序浏览速度非常快！

您还可以使用 URL 在页面之间导航。页面有自己的 URL，由文件的 `label` 定义。当多个文件具有相同的 `label` 时，Streamlit 会选择第一个（基于上述顺序）。用户可以通过访问页面的 URL 来查看特定页面。

如果用户尝试访问不存在的页面的 URL，他们将看到如下所示的模式，表示用户请求的页面在应用程序的 pages/ 目录中找不到。

![img](https://img2023.cnblogs.com/blog/2056203/202305/2056203-20230509223316461-1556302736.png)



## Notes

- 页面支持魔术命令。

- 页面支持保存时运行。此外，当您保存页面时，这会导致当前正在查看该页面的用户重新运行。

- 添加或删除页面会导致 UI 立即更新。

- 更新侧边栏中的页面不会重新运行脚本。

- `st.set_page_config` 在页面级别工作。当您使用 st.set_page_config 设置标题或图标时，这仅适用于当前页面。

- 页面在全局范围内共享相同的 Python 模块：

  ```python
  # page1.py
  import foo
  foo.hello = 123
  
  # page2.py
  import foo
  st.write(foo.hello)  # If page1 already executed, this should write 123
  ```

- 页面共享相同的 st.session_state ：

  ```python
  # page1.py
  import streamlit as st
  if "shared" not in st.session_state:
     st.session_state["shared"] = True
  
  # page2.py
  import streamlit as st
  st.write(st.session_state["shared"])
  # If page1 already executed, this should write True
  ```

  

您现在对多页应用程序有了深入的了解。您已经学习了如何构建应用程序、定义页面以及在用户界面中的页面之间导航。是时候创建您的第一个多页面应用程序了！ 🥳