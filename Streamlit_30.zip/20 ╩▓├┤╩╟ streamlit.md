# Tech Twitter Space：什么是 Streamlit？

## （由 Francesco Ciulla 主持）

和主持人 [Francesco Ciulla](https://twitter.com/FrancescoCiull4) 一道讨论什么是 Streamlit。

👉 链接：https://twitter.com/i/spaces/1dRJZlbglXMKB