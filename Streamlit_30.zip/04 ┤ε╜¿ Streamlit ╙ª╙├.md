# 🗓️ 天 4

# 和 Ken Jee 一起搭建 Streamlit 应用

## 观看 Ken 的视频

让我们看看 [Ken Jee](https://www.youtube.com/c/KenJee1) 的视频，跟着他一起搭建一个 Streamlit 应用：

[![Data Science Portfolio Project from Scratch](https://i.ytimg.com/vi/Yk-unX4KnV4/hqdefault.jpg)](https://www.youtube.com/watch?v=Yk-unX4KnV4)